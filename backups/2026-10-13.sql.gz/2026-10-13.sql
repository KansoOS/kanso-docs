--
-- PostgreSQL database dump
--

\restrict Ld9QI0th2hPofxCPfHEgbkATqwLT00wD4jJOsWsYKsk5Hbd8RZgkV2osb8yqjd4

-- Dumped from database version 18.6 (Debian 18.6-1.pgdg13+2)
-- Dumped by pg_dump version 18.6 (Debian 18.6-1.pgdg13+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


--
-- Name: unaccent; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS unaccent WITH SCHEMA public;


--
-- Name: EXTENSION unaccent; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION unaccent IS 'text search dictionary that removes accents';


--
-- Name: ai_chat_messages_tsvector_trigger(); Type: FUNCTION; Schema: public; Owner: docmost
--

CREATE FUNCTION public.ai_chat_messages_tsvector_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
    BEGIN
      NEW.tsv := to_tsvector('english', f_unaccent(substring(coalesce(NEW.content, ''), 1, 100000)));
      RETURN NEW;
    END;
    $$;


ALTER FUNCTION public.ai_chat_messages_tsvector_trigger() OWNER TO docmost;

--
-- Name: base_cell_array(jsonb, text); Type: FUNCTION; Schema: public; Owner: docmost
--

CREATE FUNCTION public.base_cell_array(cells jsonb, prop text) RETURNS jsonb
    LANGUAGE sql IMMUTABLE STRICT PARALLEL SAFE
    AS $$ SELECT cells->prop::text $$;


ALTER FUNCTION public.base_cell_array(cells jsonb, prop text) OWNER TO docmost;

--
-- Name: base_cell_bool(jsonb, text); Type: FUNCTION; Schema: public; Owner: docmost
--

CREATE FUNCTION public.base_cell_bool(cells jsonb, prop text) RETURNS boolean
    LANGUAGE sql IMMUTABLE STRICT PARALLEL SAFE
    AS $$
      SELECT CASE jsonb_typeof(cells->prop::text)
        WHEN 'boolean' THEN (cells->>prop::text)::boolean
        WHEN 'string' THEN
          CASE
            WHEN lower(btrim(cells->>prop::text)) IN
              ('true','t','yes','y','on','1','false','f','no','n','off','0')
            THEN (cells->>prop::text)::boolean
          END
      END
    $$;


ALTER FUNCTION public.base_cell_bool(cells jsonb, prop text) OWNER TO docmost;

--
-- Name: base_cell_numeric(jsonb, text); Type: FUNCTION; Schema: public; Owner: docmost
--

CREATE FUNCTION public.base_cell_numeric(cells jsonb, prop text) RETURNS numeric
    LANGUAGE sql IMMUTABLE STRICT PARALLEL SAFE
    AS $_$
      SELECT CASE jsonb_typeof(cells->prop::text)
        WHEN 'number' THEN (cells->>prop::text)::numeric
        WHEN 'string' THEN
          CASE
            WHEN (cells->>prop::text) ~
              '^[[:space:]]*[+-]?([0-9]+([.][0-9]*)?|[.][0-9]+)([eE][+-]?[0-9]+)?[[:space:]]*$'
            THEN (cells->>prop::text)::numeric
          END
      END
    $_$;


ALTER FUNCTION public.base_cell_numeric(cells jsonb, prop text) OWNER TO docmost;

--
-- Name: base_cell_text(jsonb, text); Type: FUNCTION; Schema: public; Owner: docmost
--

CREATE FUNCTION public.base_cell_text(cells jsonb, prop text) RETURNS text
    LANGUAGE sql IMMUTABLE STRICT PARALLEL SAFE
    AS $$ SELECT cells->>prop::text $$;


ALTER FUNCTION public.base_cell_text(cells jsonb, prop text) OWNER TO docmost;

--
-- Name: base_cell_timestamptz(jsonb, text); Type: FUNCTION; Schema: public; Owner: docmost
--

CREATE FUNCTION public.base_cell_timestamptz(cells jsonb, prop text) RETURNS timestamp with time zone
    LANGUAGE plpgsql IMMUTABLE STRICT PARALLEL SAFE
    AS $$
      BEGIN RETURN (cells->>prop::text)::timestamptz;
      EXCEPTION WHEN others THEN RETURN NULL; END;
    $$;


ALTER FUNCTION public.base_cell_timestamptz(cells jsonb, prop text) OWNER TO docmost;

--
-- Name: f_unaccent(text); Type: FUNCTION; Schema: public; Owner: docmost
--

CREATE FUNCTION public.f_unaccent(text) RETURNS text
    LANGUAGE sql IMMUTABLE STRICT PARALLEL SAFE
    AS $_$
      SELECT unaccent('unaccent', $1);
    $_$;


ALTER FUNCTION public.f_unaccent(text) OWNER TO docmost;

--
-- Name: gen_uuid_v7(); Type: FUNCTION; Schema: public; Owner: docmost
--

CREATE FUNCTION public.gen_uuid_v7() RETURNS uuid
    LANGUAGE plpgsql
    AS $$
        declare
              v_time numeric := null;
      
              v_unix_t numeric := null;
              v_rand_a numeric := null;
              v_rand_b numeric := null;
      
              v_unix_t_hex varchar := null;
              v_rand_a_hex varchar := null;
              v_rand_b_hex varchar := null;
      
              v_output_bytes bytea := null;
              
              c_milli_factor numeric := 10^3::numeric;  -- 1000
              c_micro_factor numeric := 10^6::numeric;  -- 1000000
              c_scale_factor numeric := 4.096::numeric; -- 4.0 * (1024 / 1000)
              
              c_version bit(64) := x'0000000000007000'; -- RFC-4122 version: b'0111...'
              c_variant bit(64) := x'8000000000000000'; -- RFC-4122 variant: b'10xx...'

        begin
              v_time := extract(epoch from clock_timestamp());
              
              v_unix_t := trunc(v_time * c_milli_factor);
              v_rand_a := ((v_time * c_micro_factor) - (v_unix_t * c_milli_factor)) * c_scale_factor;
              v_rand_b := random()::numeric * 2^62::numeric;
              
              v_unix_t_hex := lpad(to_hex(v_unix_t::bigint), 12, '0');
              v_rand_a_hex := lpad(to_hex((v_rand_a::bigint::bit(64) | c_version)::bigint), 4, '0');
              v_rand_b_hex := lpad(to_hex((v_rand_b::bigint::bit(64) | c_variant)::bigint), 16, '0');
              
              v_output_bytes := decode(v_unix_t_hex || v_rand_a_hex || v_rand_b_hex, 'hex');
    
              return encode(v_output_bytes, 'hex')::uuid;
              
              v_output_bytes := decode(v_unix_t_hex || v_rand_a_hex || v_rand_b_hex, 'hex');
    
              return encode(v_output_bytes, 'hex')::uuid;
     end $$;


ALTER FUNCTION public.gen_uuid_v7() OWNER TO docmost;

--
-- Name: jsonb_set_many(jsonb, jsonb); Type: FUNCTION; Schema: public; Owner: docmost
--

CREATE FUNCTION public.jsonb_set_many(target jsonb, patches jsonb) RETURNS jsonb
    LANGUAGE plpgsql IMMUTABLE PARALLEL SAFE
    AS $$
      DECLARE k text; v jsonb; result jsonb := coalesce(target, '{}'::jsonb);
      BEGIN
        IF patches IS NULL OR jsonb_typeof(patches) <> 'object' THEN
          RETURN result;
        END IF;
        FOR k, v IN SELECT * FROM jsonb_each(patches) LOOP
          IF v = 'null'::jsonb THEN
            result := result - k;
          ELSE
            result := jsonb_set(result, ARRAY[k], v, true);
          END IF;
        END LOOP;
        RETURN result;
      END;
    $$;


ALTER FUNCTION public.jsonb_set_many(target jsonb, patches jsonb) OWNER TO docmost;

--
-- Name: pages_tsvector_trigger(); Type: FUNCTION; Schema: public; Owner: docmost
--

CREATE FUNCTION public.pages_tsvector_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
    begin
        new.tsv :=
                  setweight(to_tsvector('english', f_unaccent(coalesce(new.title, ''))), 'A') ||
                  setweight(to_tsvector('english', f_unaccent(substring(coalesce(new.text_content, ''), 1, 1000000))), 'B');
        return new;
    end;
    $$;


ALTER FUNCTION public.pages_tsvector_trigger() OWNER TO docmost;

--
-- Name: templates_tsvector_trigger(); Type: FUNCTION; Schema: public; Owner: docmost
--

CREATE FUNCTION public.templates_tsvector_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
    begin
        new.tsv :=
                  setweight(to_tsvector('english', f_unaccent(coalesce(new.title, ''))), 'A') ||
                  setweight(to_tsvector('english', f_unaccent(substring(coalesce(new.text_content, ''), 1, 1000000))), 'B');
        return new;
    end;
    $$;


ALTER FUNCTION public.templates_tsvector_trigger() OWNER TO docmost;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ai_chat_messages; Type: TABLE; Schema: public; Owner: docmost
--

CREATE TABLE public.ai_chat_messages (
    id uuid DEFAULT public.gen_uuid_v7() NOT NULL,
    chat_id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    user_id uuid,
    role character varying NOT NULL,
    content text,
    tool_calls jsonb,
    metadata jsonb,
    tsv tsvector,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.ai_chat_messages OWNER TO docmost;

--
-- Name: ai_chats; Type: TABLE; Schema: public; Owner: docmost
--

CREATE TABLE public.ai_chats (
    id uuid DEFAULT public.gen_uuid_v7() NOT NULL,
    workspace_id uuid NOT NULL,
    creator_id uuid NOT NULL,
    title character varying,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.ai_chats OWNER TO docmost;

--
-- Name: api_keys; Type: TABLE; Schema: public; Owner: docmost
--

CREATE TABLE public.api_keys (
    id uuid DEFAULT public.gen_uuid_v7() NOT NULL,
    name text,
    creator_id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    expires_at timestamp with time zone,
    last_used_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.api_keys OWNER TO docmost;

--
-- Name: attachments; Type: TABLE; Schema: public; Owner: docmost
--

CREATE TABLE public.attachments (
    id uuid DEFAULT public.gen_uuid_v7() NOT NULL,
    file_name character varying NOT NULL,
    file_path character varying NOT NULL,
    file_size bigint,
    file_ext character varying NOT NULL,
    mime_type character varying,
    type character varying,
    creator_id uuid NOT NULL,
    page_id uuid,
    space_id uuid,
    workspace_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    text_content text,
    tsv tsvector,
    ai_chat_id uuid
);


ALTER TABLE public.attachments OWNER TO docmost;

--
-- Name: audit; Type: TABLE; Schema: public; Owner: docmost
--

CREATE TABLE public.audit (
    id uuid DEFAULT public.gen_uuid_v7() NOT NULL,
    workspace_id uuid NOT NULL,
    actor_id uuid,
    actor_type character varying DEFAULT 'user'::character varying NOT NULL,
    event character varying NOT NULL,
    resource_type character varying NOT NULL,
    resource_id uuid,
    space_id uuid,
    changes jsonb,
    metadata jsonb,
    ip_address inet,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    user_agent text
);


ALTER TABLE public.audit OWNER TO docmost;

--
-- Name: auth_accounts; Type: TABLE; Schema: public; Owner: docmost
--

CREATE TABLE public.auth_accounts (
    id uuid DEFAULT public.gen_uuid_v7() NOT NULL,
    user_id uuid NOT NULL,
    provider_user_id character varying NOT NULL,
    auth_provider_id uuid,
    workspace_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.auth_accounts OWNER TO docmost;

--
-- Name: auth_providers; Type: TABLE; Schema: public; Owner: docmost
--

CREATE TABLE public.auth_providers (
    id uuid DEFAULT public.gen_uuid_v7() NOT NULL,
    name character varying NOT NULL,
    type text NOT NULL,
    saml_url character varying,
    saml_certificate character varying,
    oidc_issuer character varying,
    oidc_client_id character varying,
    oidc_client_secret character varying,
    allow_signup boolean DEFAULT false NOT NULL,
    is_enabled boolean DEFAULT false NOT NULL,
    creator_id uuid,
    workspace_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    group_sync boolean DEFAULT false NOT NULL,
    ldap_url character varying,
    ldap_bind_dn character varying,
    ldap_bind_password character varying,
    ldap_base_dn character varying,
    ldap_user_search_filter character varying,
    ldap_user_attributes jsonb DEFAULT '{}'::jsonb,
    ldap_tls_enabled boolean DEFAULT false,
    ldap_tls_ca_cert text,
    ldap_config jsonb DEFAULT '{}'::jsonb,
    settings jsonb DEFAULT '{}'::jsonb
);


ALTER TABLE public.auth_providers OWNER TO docmost;

--
-- Name: backlinks; Type: TABLE; Schema: public; Owner: docmost
--

CREATE TABLE public.backlinks (
    id uuid DEFAULT public.gen_uuid_v7() NOT NULL,
    source_page_id uuid NOT NULL,
    target_page_id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.backlinks OWNER TO docmost;

--
-- Name: base_properties; Type: TABLE; Schema: public; Owner: docmost
--

CREATE TABLE public.base_properties (
    id character varying NOT NULL,
    page_id uuid NOT NULL,
    name character varying NOT NULL,
    type character varying NOT NULL,
    "position" character varying NOT NULL,
    type_options jsonb,
    pending_type character varying,
    pending_type_options jsonb,
    pending_token uuid,
    is_primary boolean DEFAULT false NOT NULL,
    schema_version integer DEFAULT 1 NOT NULL,
    workspace_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.base_properties OWNER TO docmost;

--
-- Name: base_rows; Type: TABLE; Schema: public; Owner: docmost
--

CREATE TABLE public.base_rows (
    id uuid DEFAULT public.gen_uuid_v7() NOT NULL,
    page_id uuid NOT NULL,
    cells jsonb DEFAULT '{}'::jsonb NOT NULL,
    "position" character varying NOT NULL,
    creator_id uuid,
    last_updated_by_id uuid,
    workspace_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.base_rows OWNER TO docmost;

--
-- Name: base_views; Type: TABLE; Schema: public; Owner: docmost
--

CREATE TABLE public.base_views (
    id uuid DEFAULT public.gen_uuid_v7() NOT NULL,
    page_id uuid NOT NULL,
    name character varying NOT NULL,
    type character varying DEFAULT 'table'::character varying NOT NULL,
    "position" character varying NOT NULL,
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    workspace_id uuid NOT NULL,
    creator_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.base_views OWNER TO docmost;

--
-- Name: billing; Type: TABLE; Schema: public; Owner: docmost
--

CREATE TABLE public.billing (
    id uuid DEFAULT public.gen_uuid_v7() NOT NULL,
    stripe_subscription_id character varying NOT NULL,
    stripe_customer_id character varying,
    status character varying NOT NULL,
    quantity bigint,
    amount bigint,
    "interval" character varying,
    currency character varying,
    metadata jsonb,
    stripe_price_id character varying,
    stripe_item_id character varying,
    stripe_product_id character varying,
    period_start_at timestamp with time zone NOT NULL,
    period_end_at timestamp with time zone,
    cancel_at_period_end boolean,
    cancel_at timestamp with time zone,
    canceled_at timestamp with time zone,
    ended_at timestamp with time zone,
    workspace_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    billing_scheme character varying,
    tiered_up_to character varying,
    tiered_flat_amount bigint,
    tiered_unit_amount bigint,
    plan_name character varying
);


ALTER TABLE public.billing OWNER TO docmost;

--
-- Name: comments; Type: TABLE; Schema: public; Owner: docmost
--

CREATE TABLE public.comments (
    id uuid DEFAULT public.gen_uuid_v7() NOT NULL,
    content jsonb,
    selection character varying,
    type character varying,
    creator_id uuid,
    page_id uuid NOT NULL,
    parent_comment_id uuid,
    workspace_id uuid NOT NULL,
    resolved_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    edited_at timestamp with time zone,
    deleted_at timestamp with time zone,
    last_edited_by_id uuid,
    resolved_by_id uuid,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    space_id uuid NOT NULL
);


ALTER TABLE public.comments OWNER TO docmost;

--
-- Name: favorites; Type: TABLE; Schema: public; Owner: docmost
--

CREATE TABLE public.favorites (
    id uuid DEFAULT public.gen_uuid_v7() NOT NULL,
    user_id uuid NOT NULL,
    page_id uuid,
    space_id uuid,
    template_id uuid,
    type character varying NOT NULL,
    workspace_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.favorites OWNER TO docmost;

--
-- Name: file_tasks; Type: TABLE; Schema: public; Owner: docmost
--

CREATE TABLE public.file_tasks (
    id uuid DEFAULT public.gen_uuid_v7() NOT NULL,
    type character varying,
    source character varying,
    status character varying,
    file_name character varying NOT NULL,
    file_path character varying NOT NULL,
    file_size bigint,
    file_ext character varying,
    error_message character varying,
    creator_id uuid,
    space_id uuid,
    workspace_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    page_id uuid,
    metadata jsonb
);


ALTER TABLE public.file_tasks OWNER TO docmost;

--
-- Name: group_users; Type: TABLE; Schema: public; Owner: docmost
--

CREATE TABLE public.group_users (
    id uuid DEFAULT public.gen_uuid_v7() NOT NULL,
    user_id uuid NOT NULL,
    group_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.group_users OWNER TO docmost;

--
-- Name: groups; Type: TABLE; Schema: public; Owner: docmost
--

CREATE TABLE public.groups (
    id uuid DEFAULT public.gen_uuid_v7() NOT NULL,
    name character varying NOT NULL,
    description text,
    is_default boolean NOT NULL,
    workspace_id uuid NOT NULL,
    creator_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    scim_external_id text,
    is_external boolean DEFAULT false NOT NULL
);


ALTER TABLE public.groups OWNER TO docmost;

--
-- Name: kysely_migration; Type: TABLE; Schema: public; Owner: docmost
--

CREATE TABLE public.kysely_migration (
    name character varying(255) NOT NULL,
    "timestamp" character varying(255) NOT NULL
);


ALTER TABLE public.kysely_migration OWNER TO docmost;

--
-- Name: kysely_migration_lock; Type: TABLE; Schema: public; Owner: docmost
--

CREATE TABLE public.kysely_migration_lock (
    id character varying(255) NOT NULL,
    is_locked integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.kysely_migration_lock OWNER TO docmost;

--
-- Name: labels; Type: TABLE; Schema: public; Owner: docmost
--

CREATE TABLE public.labels (
    id uuid DEFAULT public.gen_uuid_v7() NOT NULL,
    name character varying NOT NULL,
    type character varying DEFAULT 'page'::character varying NOT NULL,
    workspace_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.labels OWNER TO docmost;

--
-- Name: notifications; Type: TABLE; Schema: public; Owner: docmost
--

CREATE TABLE public.notifications (
    id uuid DEFAULT public.gen_uuid_v7() NOT NULL,
    user_id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    type text NOT NULL,
    actor_id uuid,
    page_id uuid,
    space_id uuid,
    comment_id uuid,
    data jsonb,
    read_at timestamp with time zone,
    emailed_at timestamp with time zone,
    archived_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    page_verification_id uuid
);


ALTER TABLE public.notifications OWNER TO docmost;

--
-- Name: oauth_authorization_codes; Type: TABLE; Schema: public; Owner: docmost
--

CREATE TABLE public.oauth_authorization_codes (
    id uuid DEFAULT public.gen_uuid_v7() NOT NULL,
    code_hash text NOT NULL,
    client_id uuid NOT NULL,
    user_id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    scopes jsonb NOT NULL,
    redirect_uri text NOT NULL,
    code_challenge text,
    code_challenge_method text,
    expires_at timestamp with time zone NOT NULL,
    consumed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.oauth_authorization_codes OWNER TO docmost;

--
-- Name: oauth_clients; Type: TABLE; Schema: public; Owner: docmost
--

CREATE TABLE public.oauth_clients (
    id uuid DEFAULT public.gen_uuid_v7() NOT NULL,
    name text NOT NULL,
    redirect_uris jsonb NOT NULL,
    client_uri text,
    logo_uri text,
    grant_types jsonb NOT NULL,
    scopes jsonb NOT NULL,
    token_endpoint_auth_method text DEFAULT 'none'::text NOT NULL,
    secret_hash text,
    is_dynamic boolean DEFAULT true NOT NULL,
    workspace_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.oauth_clients OWNER TO docmost;

--
-- Name: oauth_grants; Type: TABLE; Schema: public; Owner: docmost
--

CREATE TABLE public.oauth_grants (
    id uuid DEFAULT public.gen_uuid_v7() NOT NULL,
    user_id uuid NOT NULL,
    client_id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    scopes jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    last_used_at timestamp with time zone,
    revoked_at timestamp with time zone
);


ALTER TABLE public.oauth_grants OWNER TO docmost;

--
-- Name: oauth_tokens; Type: TABLE; Schema: public; Owner: docmost
--

CREATE TABLE public.oauth_tokens (
    id uuid DEFAULT public.gen_uuid_v7() NOT NULL,
    grant_id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    access_token_jti text NOT NULL,
    refresh_token_hash text,
    scopes jsonb NOT NULL,
    access_expires_at timestamp with time zone NOT NULL,
    refresh_expires_at timestamp with time zone,
    revoked_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.oauth_tokens OWNER TO docmost;

--
-- Name: page_access; Type: TABLE; Schema: public; Owner: docmost
--

CREATE TABLE public.page_access (
    id uuid DEFAULT public.gen_uuid_v7() NOT NULL,
    page_id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    space_id uuid NOT NULL,
    access_level character varying NOT NULL,
    creator_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.page_access OWNER TO docmost;

--
-- Name: page_history; Type: TABLE; Schema: public; Owner: docmost
--

CREATE TABLE public.page_history (
    id uuid DEFAULT public.gen_uuid_v7() NOT NULL,
    page_id uuid NOT NULL,
    slug_id character varying,
    title character varying,
    content jsonb,
    slug character varying,
    icon character varying,
    cover_photo character varying,
    version integer,
    last_updated_by_id uuid,
    space_id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    contributor_ids uuid[] DEFAULT '{}'::uuid[]
);


ALTER TABLE public.page_history OWNER TO docmost;

--
-- Name: page_labels; Type: TABLE; Schema: public; Owner: docmost
--

CREATE TABLE public.page_labels (
    id uuid DEFAULT public.gen_uuid_v7() NOT NULL,
    page_id uuid NOT NULL,
    label_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.page_labels OWNER TO docmost;

--
-- Name: page_permissions; Type: TABLE; Schema: public; Owner: docmost
--

CREATE TABLE public.page_permissions (
    id uuid DEFAULT public.gen_uuid_v7() NOT NULL,
    page_access_id uuid NOT NULL,
    user_id uuid,
    group_id uuid,
    role character varying NOT NULL,
    added_by_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT allow_either_user_id_or_group_id_check CHECK ((((user_id IS NOT NULL) AND (group_id IS NULL)) OR ((user_id IS NULL) AND (group_id IS NOT NULL))))
);


ALTER TABLE public.page_permissions OWNER TO docmost;

--
-- Name: page_transclusion_references; Type: TABLE; Schema: public; Owner: docmost
--

CREATE TABLE public.page_transclusion_references (
    id uuid DEFAULT public.gen_uuid_v7() NOT NULL,
    workspace_id uuid NOT NULL,
    reference_page_id uuid NOT NULL,
    source_page_id uuid NOT NULL,
    transclusion_id character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.page_transclusion_references OWNER TO docmost;

--
-- Name: page_transclusions; Type: TABLE; Schema: public; Owner: docmost
--

CREATE TABLE public.page_transclusions (
    id uuid DEFAULT public.gen_uuid_v7() NOT NULL,
    workspace_id uuid NOT NULL,
    page_id uuid NOT NULL,
    transclusion_id character varying NOT NULL,
    content jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.page_transclusions OWNER TO docmost;

--
-- Name: page_verifications; Type: TABLE; Schema: public; Owner: docmost
--

CREATE TABLE public.page_verifications (
    id uuid DEFAULT public.gen_uuid_v7() NOT NULL,
    page_id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    space_id uuid NOT NULL,
    type character varying DEFAULT 'expiring'::character varying NOT NULL,
    status character varying,
    mode character varying,
    period_amount integer,
    period_unit character varying,
    verified_at timestamp with time zone,
    verified_by_id uuid,
    expires_at timestamp with time zone,
    requested_at timestamp with time zone,
    requested_by_id uuid,
    rejected_at timestamp with time zone,
    rejected_by_id uuid,
    rejection_comment text,
    data jsonb,
    creator_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.page_verifications OWNER TO docmost;

--
-- Name: page_verifiers; Type: TABLE; Schema: public; Owner: docmost
--

CREATE TABLE public.page_verifiers (
    id uuid DEFAULT public.gen_uuid_v7() NOT NULL,
    page_verification_id uuid NOT NULL,
    user_id uuid NOT NULL,
    is_primary boolean DEFAULT false NOT NULL,
    added_by_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.page_verifiers OWNER TO docmost;

--
-- Name: pages; Type: TABLE; Schema: public; Owner: docmost
--

CREATE TABLE public.pages (
    id uuid DEFAULT public.gen_uuid_v7() NOT NULL,
    slug_id character varying NOT NULL,
    title character varying,
    icon character varying,
    cover_photo character varying,
    "position" character varying,
    content jsonb,
    ydoc bytea,
    text_content text,
    tsv tsvector,
    parent_page_id uuid,
    creator_id uuid,
    last_updated_by_id uuid,
    deleted_by_id uuid,
    space_id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    is_locked boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    contributor_ids uuid[] DEFAULT '{}'::uuid[],
    is_base boolean DEFAULT false NOT NULL,
    base_schema_version integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.pages OWNER TO docmost;

--
-- Name: public_spaces; Type: TABLE; Schema: public; Owner: docmost
--

CREATE TABLE public.public_spaces (
    id uuid DEFAULT public.gen_uuid_v7() NOT NULL,
    space_id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    search_indexing boolean DEFAULT false NOT NULL,
    settings jsonb,
    creator_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.public_spaces OWNER TO docmost;

--
-- Name: scim_tokens; Type: TABLE; Schema: public; Owner: docmost
--

CREATE TABLE public.scim_tokens (
    id uuid DEFAULT public.gen_uuid_v7() NOT NULL,
    name character varying NOT NULL,
    token_hash character varying NOT NULL,
    token_last_four character varying(4) NOT NULL,
    last_used_at timestamp with time zone,
    is_enabled boolean DEFAULT true NOT NULL,
    creator_id uuid,
    workspace_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.scim_tokens OWNER TO docmost;

--
-- Name: shares; Type: TABLE; Schema: public; Owner: docmost
--

CREATE TABLE public.shares (
    id uuid DEFAULT public.gen_uuid_v7() NOT NULL,
    key character varying NOT NULL,
    page_id uuid,
    include_sub_pages boolean DEFAULT false,
    search_indexing boolean DEFAULT false,
    creator_id uuid,
    space_id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.shares OWNER TO docmost;

--
-- Name: siem_destinations; Type: TABLE; Schema: public; Owner: docmost
--

CREATE TABLE public.siem_destinations (
    id uuid DEFAULT public.gen_uuid_v7() NOT NULL,
    workspace_id uuid NOT NULL,
    name character varying NOT NULL,
    type character varying NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    config jsonb NOT NULL,
    secrets text NOT NULL,
    cursor_created_at timestamp with time zone DEFAULT now() NOT NULL,
    cursor_id uuid DEFAULT public.gen_uuid_v7() NOT NULL,
    cursor_snapshot text,
    version integer DEFAULT 0 NOT NULL,
    status character varying DEFAULT 'healthy'::character varying NOT NULL,
    consecutive_failures integer DEFAULT 0 NOT NULL,
    next_attempt_at timestamp with time zone,
    last_delivered_at timestamp with time zone,
    last_error text,
    last_error_at timestamp with time zone,
    failing_since timestamp with time zone,
    creator_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.siem_destinations OWNER TO docmost;

--
-- Name: space_members; Type: TABLE; Schema: public; Owner: docmost
--

CREATE TABLE public.space_members (
    id uuid DEFAULT public.gen_uuid_v7() NOT NULL,
    user_id uuid,
    group_id uuid,
    space_id uuid NOT NULL,
    role character varying NOT NULL,
    added_by_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    CONSTRAINT allow_either_user_id_or_group_id_check CHECK ((((user_id IS NOT NULL) AND (group_id IS NULL)) OR ((user_id IS NULL) AND (group_id IS NOT NULL))))
);


ALTER TABLE public.space_members OWNER TO docmost;

--
-- Name: spaces; Type: TABLE; Schema: public; Owner: docmost
--

CREATE TABLE public.spaces (
    id uuid DEFAULT public.gen_uuid_v7() NOT NULL,
    name character varying,
    description text,
    slug character varying NOT NULL,
    logo character varying,
    visibility character varying DEFAULT 'private'::character varying NOT NULL,
    default_role character varying DEFAULT 'writer'::character varying NOT NULL,
    creator_id uuid,
    workspace_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    settings jsonb,
    is_personal boolean DEFAULT false NOT NULL
);


ALTER TABLE public.spaces OWNER TO docmost;

--
-- Name: templates; Type: TABLE; Schema: public; Owner: docmost
--

CREATE TABLE public.templates (
    id uuid DEFAULT public.gen_uuid_v7() NOT NULL,
    title character varying,
    description text,
    content jsonb,
    ydoc bytea,
    icon character varying,
    space_id uuid,
    workspace_id uuid NOT NULL,
    creator_id uuid,
    last_updated_by_id uuid,
    collaborator_ids uuid[],
    text_content text,
    tsv tsvector,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.templates OWNER TO docmost;

--
-- Name: user_mfa; Type: TABLE; Schema: public; Owner: docmost
--

CREATE TABLE public.user_mfa (
    id uuid DEFAULT public.gen_uuid_v7() NOT NULL,
    user_id uuid NOT NULL,
    method character varying DEFAULT 'totp'::character varying NOT NULL,
    secret text,
    is_enabled boolean DEFAULT false,
    backup_codes text[],
    workspace_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.user_mfa OWNER TO docmost;

--
-- Name: user_sessions; Type: TABLE; Schema: public; Owner: docmost
--

CREATE TABLE public.user_sessions (
    id uuid DEFAULT public.gen_uuid_v7() NOT NULL,
    user_id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    device_name character varying,
    user_agent text,
    ip_address inet,
    geo_location character varying,
    last_active_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    metadata jsonb,
    revoked_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.user_sessions OWNER TO docmost;

--
-- Name: user_tokens; Type: TABLE; Schema: public; Owner: docmost
--

CREATE TABLE public.user_tokens (
    id uuid DEFAULT public.gen_uuid_v7() NOT NULL,
    token character varying NOT NULL,
    type character varying NOT NULL,
    user_id uuid NOT NULL,
    workspace_id uuid,
    expires_at timestamp with time zone,
    used_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.user_tokens OWNER TO docmost;

--
-- Name: users; Type: TABLE; Schema: public; Owner: docmost
--

CREATE TABLE public.users (
    id uuid DEFAULT public.gen_uuid_v7() NOT NULL,
    name character varying,
    email character varying NOT NULL,
    email_verified_at timestamp with time zone,
    password character varying,
    avatar_url character varying,
    role character varying,
    invited_by_id uuid,
    workspace_id uuid,
    locale character varying,
    timezone character varying,
    settings jsonb,
    last_active_at timestamp with time zone,
    last_login_at timestamp with time zone,
    deactivated_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    has_generated_password boolean DEFAULT false NOT NULL,
    scim_external_id text
);


ALTER TABLE public.users OWNER TO docmost;

--
-- Name: watchers; Type: TABLE; Schema: public; Owner: docmost
--

CREATE TABLE public.watchers (
    id uuid DEFAULT public.gen_uuid_v7() NOT NULL,
    user_id uuid NOT NULL,
    page_id uuid,
    space_id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    type text NOT NULL,
    added_by_id uuid,
    muted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.watchers OWNER TO docmost;

--
-- Name: workspace_invitations; Type: TABLE; Schema: public; Owner: docmost
--

CREATE TABLE public.workspace_invitations (
    id uuid DEFAULT public.gen_uuid_v7() NOT NULL,
    email character varying,
    role character varying NOT NULL,
    token character varying NOT NULL,
    group_ids uuid[],
    invited_by_id uuid,
    workspace_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.workspace_invitations OWNER TO docmost;

--
-- Name: workspaces; Type: TABLE; Schema: public; Owner: docmost
--

CREATE TABLE public.workspaces (
    id uuid DEFAULT public.gen_uuid_v7() NOT NULL,
    name character varying,
    description character varying,
    logo character varying,
    hostname character varying,
    custom_domain character varying,
    settings jsonb,
    default_role character varying DEFAULT 'member'::character varying NOT NULL,
    email_domains character varying[] DEFAULT '{}'::character varying[],
    default_space_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    stripe_customer_id character varying,
    status character varying,
    plan character varying,
    billing_email character varying,
    trial_end_at timestamp with time zone,
    enforce_sso boolean DEFAULT false NOT NULL,
    license_key character varying,
    enforce_mfa boolean DEFAULT false,
    audit_retention_days bigint,
    trash_retention_days bigint,
    is_scim_enabled boolean DEFAULT false NOT NULL
);


ALTER TABLE public.workspaces OWNER TO docmost;

--
-- Data for Name: ai_chat_messages; Type: TABLE DATA; Schema: public; Owner: docmost
--

COPY public.ai_chat_messages (id, chat_id, workspace_id, user_id, role, content, tool_calls, metadata, tsv, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: ai_chats; Type: TABLE DATA; Schema: public; Owner: docmost
--

COPY public.ai_chats (id, workspace_id, creator_id, title, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: api_keys; Type: TABLE DATA; Schema: public; Owner: docmost
--

COPY public.api_keys (id, name, creator_id, workspace_id, expires_at, last_used_at, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: attachments; Type: TABLE DATA; Schema: public; Owner: docmost
--

COPY public.attachments (id, file_name, file_path, file_size, file_ext, mime_type, type, creator_id, page_id, space_id, workspace_id, created_at, updated_at, deleted_at, text_content, tsv, ai_chat_id) FROM stdin;
01a12cf6-61dd-74d5-a062-b921cb2f9ba8	bcae10a6-af97-4afd-bf94-8d8798c267cf.png	01a12cf1-0bd3-7a42-96f8-8cedaf38cf22/workspace-logos/bcae10a6-af97-4afd-bf94-8d8798c267cf.png	44463	.png	image/png	workspace-icon	01a12cf1-0bd0-70e9-87f3-436c4e3a4023	\N	\N	01a12cf1-0bd3-7a42-96f8-8cedaf38cf22	2026-10-11 21:55:06.8411+00	2026-10-11 21:55:06.8411+00	\N	\N	\N	\N
01a12d0f-a3a5-7cee-b61f-bdf4ad6c86f9	ef5bb71d-1146-4a56-b22b-82d01b9b1014.png	01a12cf1-0bd3-7a42-96f8-8cedaf38cf22/space-logos/ef5bb71d-1146-4a56-b22b-82d01b9b1014.png	21989	.png	image/png	space-icon	01a12cf1-0bd0-70e9-87f3-436c4e3a4023	\N	\N	01a12cf1-0bd3-7a42-96f8-8cedaf38cf22	2026-10-11 22:22:42.083538+00	2026-10-11 22:22:42.083538+00	\N	\N	\N	\N
01a12d14-ec28-7702-9113-d249cb526759	f749a1ee-5be2-499e-a223-2a3c0285f69d.png	01a12cf1-0bd3-7a42-96f8-8cedaf38cf22/space-logos/f749a1ee-5be2-499e-a223-2a3c0285f69d.png	44463	.png	image/png	space-icon	01a12cf1-0bd0-70e9-87f3-436c4e3a4023	\N	\N	01a12cf1-0bd3-7a42-96f8-8cedaf38cf22	2026-10-11 22:28:28.326986+00	2026-10-11 22:28:28.326986+00	\N	\N	\N	\N
01a12d28-f151-7625-81d7-164d2075b842	de7738bb-ecd0-4ac6-9864-eda67a2bcd64.png	01a12cf1-0bd3-7a42-96f8-8cedaf38cf22/space-logos/de7738bb-ecd0-4ac6-9864-eda67a2bcd64.png	7436	.png	image/png	space-icon	01a12cf1-0bd0-70e9-87f3-436c4e3a4023	\N	\N	01a12cf1-0bd3-7a42-96f8-8cedaf38cf22	2026-10-11 22:50:20.367427+00	2026-10-11 22:50:20.367427+00	\N	\N	\N	\N
01a12d29-7e2e-715c-8d18-4557c52cb24f	98ed8e59-4d69-4ab7-80a4-d22bf714d631.png	01a12cf1-0bd3-7a42-96f8-8cedaf38cf22/space-logos/98ed8e59-4d69-4ab7-80a4-d22bf714d631.png	80972	.png	image/png	space-icon	01a12cf1-0bd0-70e9-87f3-436c4e3a4023	\N	\N	01a12cf1-0bd3-7a42-96f8-8cedaf38cf22	2026-10-11 22:50:56.4289+00	2026-10-11 22:50:56.4289+00	\N	\N	\N	\N
\.


--
-- Data for Name: audit; Type: TABLE DATA; Schema: public; Owner: docmost
--

COPY public.audit (id, workspace_id, actor_id, actor_type, event, resource_type, resource_id, space_id, changes, metadata, ip_address, created_at, user_agent) FROM stdin;
\.


--
-- Data for Name: auth_accounts; Type: TABLE DATA; Schema: public; Owner: docmost
--

COPY public.auth_accounts (id, user_id, provider_user_id, auth_provider_id, workspace_id, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: auth_providers; Type: TABLE DATA; Schema: public; Owner: docmost
--

COPY public.auth_providers (id, name, type, saml_url, saml_certificate, oidc_issuer, oidc_client_id, oidc_client_secret, allow_signup, is_enabled, creator_id, workspace_id, created_at, updated_at, deleted_at, group_sync, ldap_url, ldap_bind_dn, ldap_bind_password, ldap_base_dn, ldap_user_search_filter, ldap_user_attributes, ldap_tls_enabled, ldap_tls_ca_cert, ldap_config, settings) FROM stdin;
\.


--
-- Data for Name: backlinks; Type: TABLE DATA; Schema: public; Owner: docmost
--

COPY public.backlinks (id, source_page_id, target_page_id, workspace_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: base_properties; Type: TABLE DATA; Schema: public; Owner: docmost
--

COPY public.base_properties (id, page_id, name, type, "position", type_options, pending_type, pending_type_options, pending_token, is_primary, schema_version, workspace_id, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: base_rows; Type: TABLE DATA; Schema: public; Owner: docmost
--

COPY public.base_rows (id, page_id, cells, "position", creator_id, last_updated_by_id, workspace_id, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: base_views; Type: TABLE DATA; Schema: public; Owner: docmost
--

COPY public.base_views (id, page_id, name, type, "position", config, workspace_id, creator_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: billing; Type: TABLE DATA; Schema: public; Owner: docmost
--

COPY public.billing (id, stripe_subscription_id, stripe_customer_id, status, quantity, amount, "interval", currency, metadata, stripe_price_id, stripe_item_id, stripe_product_id, period_start_at, period_end_at, cancel_at_period_end, cancel_at, canceled_at, ended_at, workspace_id, created_at, updated_at, deleted_at, billing_scheme, tiered_up_to, tiered_flat_amount, tiered_unit_amount, plan_name) FROM stdin;
\.


--
-- Data for Name: comments; Type: TABLE DATA; Schema: public; Owner: docmost
--

COPY public.comments (id, content, selection, type, creator_id, page_id, parent_comment_id, workspace_id, resolved_at, created_at, edited_at, deleted_at, last_edited_by_id, resolved_by_id, updated_at, space_id) FROM stdin;
\.


--
-- Data for Name: favorites; Type: TABLE DATA; Schema: public; Owner: docmost
--

COPY public.favorites (id, user_id, page_id, space_id, template_id, type, workspace_id, created_at) FROM stdin;
\.


--
-- Data for Name: file_tasks; Type: TABLE DATA; Schema: public; Owner: docmost
--

COPY public.file_tasks (id, type, source, status, file_name, file_path, file_size, file_ext, error_message, creator_id, space_id, workspace_id, created_at, updated_at, deleted_at, page_id, metadata) FROM stdin;
\.


--
-- Data for Name: group_users; Type: TABLE DATA; Schema: public; Owner: docmost
--

COPY public.group_users (id, user_id, group_id, created_at, updated_at) FROM stdin;
01a12cf1-0bd9-7c6a-9e98-9dd501338ed7	01a12cf1-0bd0-70e9-87f3-436c4e3a4023	01a12cf1-0bd6-70e1-9230-cec6bb016d1b	2026-10-11 21:49:16.853587+00	2026-10-11 21:49:16.853587+00
\.


--
-- Data for Name: groups; Type: TABLE DATA; Schema: public; Owner: docmost
--

COPY public.groups (id, name, description, is_default, workspace_id, creator_id, created_at, updated_at, deleted_at, scim_external_id, is_external) FROM stdin;
01a12cf1-0bd6-70e1-9230-cec6bb016d1b	Everyone	\N	t	01a12cf1-0bd3-7a42-96f8-8cedaf38cf22	01a12cf1-0bd0-70e9-87f3-436c4e3a4023	2026-10-11 21:49:16.853587+00	2026-10-11 21:49:16.853587+00	\N	\N	f
01a12cf3-c1db-748f-9dc6-0218709264ca	KansOS Team		f	01a12cf1-0bd3-7a42-96f8-8cedaf38cf22	01a12cf1-0bd0-70e9-87f3-436c4e3a4023	2026-10-11 21:52:14.810721+00	2026-10-11 21:52:14.810721+00	\N	\N	f
\.


--
-- Data for Name: kysely_migration; Type: TABLE DATA; Schema: public; Owner: docmost
--

COPY public.kysely_migration (name, "timestamp") FROM stdin;
20240324T085400-uuid_v7_fn	2026-10-11T21:48:44.959Z
20240324T085500-workspaces	2026-10-11T21:48:44.965Z
20240324T085600-users	2026-10-11T21:48:44.971Z
20240324T085700-groups	2026-10-11T21:48:44.978Z
20240324T085900-spaces	2026-10-11T21:48:44.990Z
20240324T086100-add-workspace-fk	2026-10-11T21:48:44.994Z
20240324T086200-workspace_invitations	2026-10-11T21:48:44.999Z
20240324T086300-pages	2026-10-11T21:48:45.008Z
20240324T086400-page_history	2026-10-11T21:48:45.013Z
20240324T086600-comments	2026-10-11T21:48:45.018Z
20240324T086700-attachments	2026-10-11T21:48:45.023Z
20240324T086800-pages-tsvector-trigger	2026-10-11T21:48:45.024Z
20240707T145623-drop-redundant-pages-slug_id-index	2026-10-11T21:48:45.026Z
20240903T124647-user-tokens	2026-10-11T21:48:45.031Z
20241218T223249-backlinks	2026-10-11T21:48:45.036Z
20250106T195516-billing	2026-10-11T21:48:45.044Z
20250118T194658-sso-auth	2026-10-11T21:48:45.055Z
20250222T114520-add_license_key_to_workspace	2026-10-11T21:48:45.056Z
20250327T145832-add-contributorIds-to-pages	2026-10-11T21:48:45.058Z
20250408T191830-shares	2026-10-11T21:48:45.064Z
20250521T154949-file_tasks	2026-10-11T21:48:45.069Z
20250623T215045-more-billing-columns	2026-10-11T21:48:45.070Z
20250715T070817-mfa	2026-10-11T21:48:45.076Z
20250725T052004-add-new-comments-columns	2026-10-11T21:48:45.084Z
20250729T213756-add-unaccent-pg_trm-update-tsvector.	2026-10-11T21:48:45.098Z
20250831T191600-add-group-sync-to-auth-providers	2026-10-11T21:48:45.102Z
20250831T202306-ldap-auth	2026-10-11T21:48:45.112Z
20250901T184612-attachments-search	2026-10-11T21:48:45.114Z
20250912T101500-api-keys	2026-10-11T21:48:45.120Z
20260205T214213-add-settings-to-spaces	2026-10-11T21:48:45.121Z
20260209T120000-add-contributor_ids-to-page-history	2026-10-11T21:48:45.123Z
20260213T085259-notifications	2026-10-11T21:48:45.133Z
20260213T085320-watchers	2026-10-11T21:48:45.145Z
20260213T085337-backfill-watchers	2026-10-11T21:48:45.147Z
20260224T233803-page-permissions	2026-10-11T21:48:45.169Z
20260228T223532-audit	2026-10-11T21:48:45.177Z
20260326T121350-user-sessions	2026-10-11T21:48:45.182Z
20260329T163516-add-new-indexes	2026-10-11T21:48:45.209Z
20260409T132415-ai-chat	2026-10-11T21:48:45.222Z
20260412T135891-templates	2026-10-11T21:48:45.231Z
20260412T162318-favorites	2026-10-11T21:48:45.241Z
20260413T121647-page-verifications	2026-10-11T21:48:45.258Z
20260414T124451-update-file_tasks	2026-10-11T21:48:45.263Z
20260501T092214-scim	2026-10-11T21:48:45.277Z
20260501T202258-page-transclusions	2026-10-11T21:48:45.294Z
20260509T121236-labels	2026-10-11T21:48:45.303Z
20260529T125146-bases	2026-10-11T21:48:45.330Z
20260620T010047-personal-spaces	2026-10-11T21:48:45.333Z
20260824T211732-page-title-trgm-index	2026-10-11T21:48:45.335Z
20260825T022612-oauth	2026-10-11T21:48:45.363Z
20260902T121326-siem-destinations	2026-10-11T21:48:45.370Z
20260904T171920-public-spaces	2026-10-11T21:48:45.377Z
\.


--
-- Data for Name: kysely_migration_lock; Type: TABLE DATA; Schema: public; Owner: docmost
--

COPY public.kysely_migration_lock (id, is_locked) FROM stdin;
migration_lock	0
\.


--
-- Data for Name: labels; Type: TABLE DATA; Schema: public; Owner: docmost
--

COPY public.labels (id, name, type, workspace_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: docmost
--

COPY public.notifications (id, user_id, workspace_id, type, actor_id, page_id, space_id, comment_id, data, read_at, emailed_at, archived_at, created_at, page_verification_id) FROM stdin;
\.


--
-- Data for Name: oauth_authorization_codes; Type: TABLE DATA; Schema: public; Owner: docmost
--

COPY public.oauth_authorization_codes (id, code_hash, client_id, user_id, workspace_id, scopes, redirect_uri, code_challenge, code_challenge_method, expires_at, consumed_at, created_at) FROM stdin;
\.


--
-- Data for Name: oauth_clients; Type: TABLE DATA; Schema: public; Owner: docmost
--

COPY public.oauth_clients (id, name, redirect_uris, client_uri, logo_uri, grant_types, scopes, token_endpoint_auth_method, secret_hash, is_dynamic, workspace_id, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: oauth_grants; Type: TABLE DATA; Schema: public; Owner: docmost
--

COPY public.oauth_grants (id, user_id, client_id, workspace_id, scopes, created_at, updated_at, last_used_at, revoked_at) FROM stdin;
\.


--
-- Data for Name: oauth_tokens; Type: TABLE DATA; Schema: public; Owner: docmost
--

COPY public.oauth_tokens (id, grant_id, workspace_id, access_token_jti, refresh_token_hash, scopes, access_expires_at, refresh_expires_at, revoked_at, created_at) FROM stdin;
\.


--
-- Data for Name: page_access; Type: TABLE DATA; Schema: public; Owner: docmost
--

COPY public.page_access (id, page_id, workspace_id, space_id, access_level, creator_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: page_history; Type: TABLE DATA; Schema: public; Owner: docmost
--

COPY public.page_history (id, page_id, slug_id, title, content, slug, icon, cover_photo, version, last_updated_by_id, space_id, workspace_id, created_at, updated_at, contributor_ids) FROM stdin;
01a12d11-f812-7a73-af31-ae41ba9ef516	01a12d10-e301-772b-b847-6b22997917de	c1bzfey8PO	Pitchs introduction	{"type": "doc", "content": [{"type": "codeBlock", "attrs": {"dir": "auto"}, "content": [{"text": "KansOS part d’un constat simple. Quand quelqu’un n’arrive pas à faire une démarche en ligne, on pense tout de suite qu’il lui manque des compétences numériques. En fait, quand on regarde les chiffres, les gens disent surtout qu’ils ont peur de se tromper, que le site est mal fait, ou qu’ils ne comprennent pas le langage administratif. Le problème vient des interfaces, pas des personnes. Donc nous, on ne cherche pas à former les gens, on adapte le téléphone. KansOS c’est un launcher Android simplifié, qu’un proche ou un éducateur configure depuis une interface web. On réduit ce qui est affiché, on encadre les contacts, on guide pas à pas dans les démarches. Et surtout, on retire ces adaptations au fur et à mesure que la personne devient autonome. Le but, c’est qu’elle finisse par ne plus avoir besoin de nous.", "type": "text"}]}, {"type": "codeBlock", "attrs": {"dir": "auto"}, "content": [{"text": "KansOS, je vous donne un exemple. Imaginez un adulte qui vit seul, accompagné quelques heures par semaine par un éducateur. Il doit prendre un rendez-vous médical en ligne. Il ouvre le site, il y a quinze boutons, il ne sait pas où cliquer, il a peur de se tromper, donc il attend le passage de l’éducateur. Résultat : il n’est pas autonome, et l’éducateur passe son temps à faire des choses à sa place. KansOS, c’est un téléphone Android adapté qui lui montre étape par étape où appuyer — sans le faire à sa place, parce que faire à sa place n’apprend rien. L’éducateur configure tout ça à distance depuis une interface web, et il peut réduire l’assistance quand il voit que ça passe. L’objectif c’est que la personne fasse seule ce qu’elle ne pouvait pas faire seule.", "type": "text"}]}, {"type": "codeBlock", "attrs": {"dir": "auto"}, "content": [{"text": "KansOS c’est un système en trois parties. D’abord un launcher Android : c’est l’écran d’accueil du téléphone, il n’affiche que ce qui est autorisé au niveau où en est la personne, avec de grandes cibles et des libellés simples. Ensuite un back-end, qui est le cœur du système : il traduit les intentions de l’aidant — un niveau d’autonomie par domaine, des contacts validés — en règles concrètes, versionnées et datées, que l’appareil télécharge et applique. Et un dashboard web, où l’aidant règle tout ça et répond aux demandes de la personne. La difficulté technique n’est pas dans le back-end, qui reste un CRUD avec un calcul de configuration. Elle est sur l’appareil : guider quelqu’un dans une application qu’on ne contrôle pas, en lisant l’arbre d’accessibilité qu’elle expose. C’est là qu’est notre point dur.", "type": "text"}]}, {"type": "codeBlock", "attrs": {"dir": "auto"}, "content": [{"text": "KansOS ressemble beaucoup à un contrôle parental, et c’est la première objection qu’on nous fait. La différence tient à trois mécanismes. Premier : la personne voit tout ce qui est configuré sur elle, et elle voit ce que son aidant voit. Ce n’est pas désactivable. Un contrôle parental marche justement parce que l’enfant ne voit pas la console ; nous c’est l’inverse. Deuxième : chaque règle a une date de fin. Si personne ne la reconduit, elle disparaît. Normalement l’inertie va vers le verrouillage — on restreint un jour par précaution et ça reste dix ans. Là le système desserre tout seul. Troisième : la personne peut faire des demandes — ajouter un contact, accéder à une application, passer un niveau. C’est le seul endroit où l’initiative vient d’elle. Sans ça, on ferait juste une télécommande.", "type": "text"}]}, {"type": "codeBlock", "attrs": {"dir": "auto"}, "content": [{"text": "KansOS c’est un téléphone Android qui accompagne vers l’autonomie des personnes qui ont besoin d’un tiers pour s’en servir. Mais l’intérêt technique du projet, il est sur un point précis. Quand la personne est bloquée dans une démarche, on veut lui montrer sur quel bouton appuyer, dans une application qu’on ne contrôle pas : Ameli, sa banque, France Identité. Pour ça on lit l’arbre d’accessibilité que l’application expose au système. Le problème, c’est que cet arbre est très inégalement rempli. En Jetpack Compose il n’y a pas d’identifiant stable, sauf si le développeur l’a activé. En Flutter il n’y en a aucun. Sur une interface dessinée en canvas, il n’y a rien du tout. Donc notre produit dépend d’une donnée produite par des tiers qui ne nous doivent rien. Savoir quelle proportion du parc applicatif est réellement guidable, c’est ce qui décide si le produit existe.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "guizqosfijjz", "dir": "auto", "indent": 0}, "content": []}]}	\N	\N	\N	\N	01a12cf1-0bd0-70e9-87f3-436c4e3a4023	01a12cf1-0bdd-72b8-9465-6c1e33f4a9c9	01a12cf1-0bd3-7a42-96f8-8cedaf38cf22	2026-10-11 22:25:14.769993+00	2026-10-11 22:25:14.769993+00	{01a12cf1-0bd0-70e9-87f3-436c4e3a4023}
01a12d26-b5ba-7662-b2d7-d619d389cee5	01a12d25-a137-7221-8b5a-68b64c236dad	LCtyLDvbWy	Structure - Organisation des fichiers	{"type": "doc", "content": [{"type": "table", "attrs": {"dir": "auto"}, "content": [{"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableHeader", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "zmbscurmupcd", "dir": "auto", "indent": 0}, "content": [{"text": "Quoi", "type": "text"}]}]}, {"type": "tableHeader", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "xzxqexdkbnxq", "dir": "auto", "indent": 0}, "content": [{"text": "Où", "type": "text"}]}]}]}, {"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "prfpvdpubnbt", "dir": "auto", "indent": 0}, "content": [{"text": "Notes du track (point dur, veille, état de l’art, décisions)", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "fkutidchhhrg", "dir": "auto", "indent": 0}, "content": [{"text": "Docmost", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}]}]}]}, {"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "dgkteoajmwzq", "dir": "auto", "indent": 0}, "content": [{"text": "Comptes rendus de réunion, transcriptions", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "lobjjselfpnr", "dir": "auto", "indent": 0}, "content": [{"text": "Docmost", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}]}]}]}, {"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "exsdsjttoikm", "dir": "auto", "indent": 0}, "content": [{"text": "Journal de veille, notes de lecture, lexique", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "nbesiwzubiwn", "dir": "auto", "indent": 0}, "content": [{"text": "Docmost", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}]}]}]}, {"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "xrffgrqascmm", "dir": "auto", "indent": 0}, "content": [{"text": "Schémas, diagrammes, brainstorms", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "shlkzotgakhc", "dir": "auto", "indent": 0}, "content": [{"text": "Docmost", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}]}]}]}, {"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "wkvriwdbvjpp", "dir": "auto", "indent": 0}, "content": [{"text": "README, documentation d’API, documentation d’exploitation", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "crvgnlifmpfk", "dir": "auto", "indent": 0}, "content": [{"text": "Git", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}]}]}]}, {"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "bolaxswsskjt", "dir": "auto", "indent": 0}, "content": [{"text": "ADR (décisions d’architecture)", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "cazgtjqpbdhu", "dir": "auto", "indent": 0}, "content": [{"text": "Git", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}]}]}]}, {"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "hwghccsfotch", "dir": "auto", "indent": 0}, "content": [{"text": "Protocoles de mesure, scripts, fixtures", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "anawgkpxphcz", "dir": "auto", "indent": 0}, "content": [{"text": "Git", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}]}]}]}, {"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "lnqznyhouxoz", "dir": "auto", "indent": 0}, "content": [{"text": "Code", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "kpfszpsisupv", "dir": "auto", "indent": 0}, "content": [{"text": "Git", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}]}]}]}, {"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "beczdrmdkxfr", "dir": "auto", "indent": 0}, "content": [{"text": "Tâches", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "rfchzbufwnbj", "dir": "auto", "indent": 0}, "content": [{"text": "Jira", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}]}]}]}, {"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "zdgzknyyzdck", "dir": "auto", "indent": 0}, "content": [{"text": "Discussion", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "kfrhfqzpnvgr", "dir": "auto", "indent": 0}, "content": [{"text": "Discord", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}]}]}]}]}, {"type": "paragraph", "attrs": {"id": "igtthhgsebxd", "dir": "auto", "indent": 0}, "content": []}]}	\N	\N	\N	\N	01a12cf1-0bd0-70e9-87f3-436c4e3a4023	01a12d14-ccca-79ae-806d-a787dc9cf7f8	01a12cf1-0bd3-7a42-96f8-8cedaf38cf22	2026-10-11 22:47:54.041495+00	2026-10-11 22:47:54.041495+00	{01a12cf1-0bd0-70e9-87f3-436c4e3a4023}
01a12d28-0874-79ec-970c-08b29e9f552e	01a12d25-a137-7221-8b5a-68b64c236dad	LCtyLDvbWy	Organisation en fonction du type de donnée	{"type": "doc", "content": [{"type": "heading", "attrs": {"id": "igtthhgsebxd", "dir": "auto", "level": 3, "indent": 0}, "content": [{"text": "Organisation en fonction du type de data", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "scbpvuekehkq", "dir": "auto", "indent": 0}, "content": [{"text": "Plus d’utilisation de Miro ou Notion", "type": "text", "marks": [{"type": "underline", "attrs": {}}]}]}, {"type": "table", "attrs": {"dir": "auto"}, "content": [{"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableHeader", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "zmbscurmupcd", "dir": "auto", "indent": 0}, "content": [{"text": "Quoi", "type": "text"}]}]}, {"type": "tableHeader", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "xzxqexdkbnxq", "dir": "auto", "indent": 0}, "content": [{"text": "Où", "type": "text"}]}]}]}, {"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "prfpvdpubnbt", "dir": "auto", "indent": 0}, "content": [{"text": "Notes du track (point dur, veille, état de l’art, décisions)", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "fkutidchhhrg", "dir": "auto", "indent": 0}, "content": [{"text": "Docmost", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}]}]}]}, {"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "dgkteoajmwzq", "dir": "auto", "indent": 0}, "content": [{"text": "Comptes rendus de réunion, transcriptions", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "lobjjselfpnr", "dir": "auto", "indent": 0}, "content": [{"text": "Docmost", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}]}]}]}, {"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "exsdsjttoikm", "dir": "auto", "indent": 0}, "content": [{"text": "Journal de veille, notes de lecture, lexique", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "nbesiwzubiwn", "dir": "auto", "indent": 0}, "content": [{"text": "Docmost", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}]}]}]}, {"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "xrffgrqascmm", "dir": "auto", "indent": 0}, "content": [{"text": "Schémas, diagrammes, brainstorms", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "shlkzotgakhc", "dir": "auto", "indent": 0}, "content": [{"text": "Docmost", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}]}]}]}, {"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "wkvriwdbvjpp", "dir": "auto", "indent": 0}, "content": [{"text": "README, documentation d’API, documentation d’exploitation", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "crvgnlifmpfk", "dir": "auto", "indent": 0}, "content": [{"text": "Git", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}]}]}]}, {"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "bolaxswsskjt", "dir": "auto", "indent": 0}, "content": [{"text": "ADR (décisions d’architecture)", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "cazgtjqpbdhu", "dir": "auto", "indent": 0}, "content": [{"text": "Git", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}]}]}]}, {"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "hwghccsfotch", "dir": "auto", "indent": 0}, "content": [{"text": "Protocoles de mesure, scripts, fixtures", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "anawgkpxphcz", "dir": "auto", "indent": 0}, "content": [{"text": "Git", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}]}]}]}, {"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "lnqznyhouxoz", "dir": "auto", "indent": 0}, "content": [{"text": "Code", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "kpfszpsisupv", "dir": "auto", "indent": 0}, "content": [{"text": "Git", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}]}]}]}, {"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "beczdrmdkxfr", "dir": "auto", "indent": 0}, "content": [{"text": "Tâches", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "rfchzbufwnbj", "dir": "auto", "indent": 0}, "content": [{"text": "Jira", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}]}]}]}, {"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "zdgzknyyzdck", "dir": "auto", "indent": 0}, "content": [{"text": "Discussion", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "kfrhfqzpnvgr", "dir": "auto", "indent": 0}, "content": [{"text": "Discord", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}]}]}]}]}, {"type": "paragraph", "attrs": {"id": "zwwwpmacyudm", "dir": "auto", "indent": 0}, "content": []}]}	\N	\N	\N	\N	01a12cf1-0bd0-70e9-87f3-436c4e3a4023	01a12d14-ccca-79ae-806d-a787dc9cf7f8	01a12cf1-0bd3-7a42-96f8-8cedaf38cf22	2026-10-11 22:49:20.753813+00	2026-10-11 22:49:20.753813+00	{01a12cf1-0bd0-70e9-87f3-436c4e3a4023}
01a12d29-56d5-7375-8637-dc3c2310d73a	01a12d25-a137-7221-8b5a-68b64c236dad	LCtyLDvbWy	Organisation en fonction du type de donnée	{"type": "doc", "content": [{"type": "heading", "attrs": {"id": "igtthhgsebxd", "dir": "auto", "level": 3, "indent": 0}, "content": [{"text": "Plus d’utilisation de Miro ou Notion", "type": "text", "marks": [{"type": "underline", "attrs": {}}]}]}, {"type": "table", "attrs": {"dir": "auto"}, "content": [{"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableHeader", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "zmbscurmupcd", "dir": "auto", "indent": 0}, "content": [{"text": "Quoi", "type": "text"}]}]}, {"type": "tableHeader", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "xzxqexdkbnxq", "dir": "auto", "indent": 0}, "content": [{"text": "Où", "type": "text"}]}]}]}, {"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "prfpvdpubnbt", "dir": "auto", "indent": 0}, "content": [{"text": "Notes du track (point dur, veille, état de l’art, décisions)", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "fkutidchhhrg", "dir": "auto", "indent": 0}, "content": [{"text": "Docmost", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}]}]}]}, {"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "dgkteoajmwzq", "dir": "auto", "indent": 0}, "content": [{"text": "Comptes rendus de réunion, transcriptions", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "lobjjselfpnr", "dir": "auto", "indent": 0}, "content": [{"text": "Docmost", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}]}]}]}, {"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "exsdsjttoikm", "dir": "auto", "indent": 0}, "content": [{"text": "Journal de veille, notes de lecture, lexique", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "nbesiwzubiwn", "dir": "auto", "indent": 0}, "content": [{"text": "Docmost", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}]}]}]}, {"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "xrffgrqascmm", "dir": "auto", "indent": 0}, "content": [{"text": "Schémas, diagrammes, brainstorms", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "shlkzotgakhc", "dir": "auto", "indent": 0}, "content": [{"text": "Docmost", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}]}]}]}, {"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "wkvriwdbvjpp", "dir": "auto", "indent": 0}, "content": [{"text": "README, documentation d’API, documentation d’exploitation", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "crvgnlifmpfk", "dir": "auto", "indent": 0}, "content": [{"text": "Git", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}]}]}]}, {"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "bolaxswsskjt", "dir": "auto", "indent": 0}, "content": [{"text": "ADR (décisions d’architecture)", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "cazgtjqpbdhu", "dir": "auto", "indent": 0}, "content": [{"text": "Git", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}]}]}]}, {"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "hwghccsfotch", "dir": "auto", "indent": 0}, "content": [{"text": "Protocoles de mesure, scripts, fixtures", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "anawgkpxphcz", "dir": "auto", "indent": 0}, "content": [{"text": "Git", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}]}]}]}, {"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "lnqznyhouxoz", "dir": "auto", "indent": 0}, "content": [{"text": "Code", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "kpfszpsisupv", "dir": "auto", "indent": 0}, "content": [{"text": "Git", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}]}]}]}, {"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "beczdrmdkxfr", "dir": "auto", "indent": 0}, "content": [{"text": "Tâches", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "rfchzbufwnbj", "dir": "auto", "indent": 0}, "content": [{"text": "Jira", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}]}]}]}, {"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "zdgzknyyzdck", "dir": "auto", "indent": 0}, "content": [{"text": "Discussion", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "kfrhfqzpnvgr", "dir": "auto", "indent": 0}, "content": [{"text": "Discord", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}]}]}]}]}, {"type": "blockquote", "attrs": {"dir": "ltr"}, "content": [{"type": "paragraph", "attrs": {"id": "ctryvbqnbclh", "dir": "ltr", "indent": 0}, "content": [{"text": "Si ça vit à côté du code, c’est dans Git. Si c’est rédigé et relu par des humains, c’est dans Docmost.", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}]}]}, {"type": "paragraph", "attrs": {"id": "sbbxsrkqpspy", "dir": "auto", "indent": 0}, "content": []}]}	\N	\N	\N	\N	01a12cf1-0bd0-70e9-87f3-436c4e3a4023	01a12d14-ccca-79ae-806d-a787dc9cf7f8	01a12cf1-0bd3-7a42-96f8-8cedaf38cf22	2026-10-11 22:50:46.356017+00	2026-10-11 22:50:46.356017+00	{01a12cf1-0bd0-70e9-87f3-436c4e3a4023}
01a12d2b-da0a-7cc1-8717-48ec115a3e5c	01a12d29-b33c-7771-a510-a4f4d1590e6d	I7zExxA6XC	Compte rendu - Octobre 2, 2026	{"type": "doc", "content": [{"type": "heading", "attrs": {"id": "nsaavdvqubfn", "dir": "auto", "level": 1, "indent": 0}, "content": [{"text": "Summary", "type": "text"}]}, {"type": "heading", "attrs": {"id": "cbpmpksgwkvb", "dir": "auto", "level": 3, "indent": 0}, "content": [{"text": "Action Items", "type": "text"}]}, {"type": "taskList", "attrs": {"dir": "auto"}, "content": [{"type": "taskItem", "attrs": {"dir": "auto", "checked": false}, "content": [{"type": "paragraph", "attrs": {"id": "ceyxjrufsfzy", "dir": "auto", "indent": 0}, "content": [{"text": " Team to read the Student Guide objectives carefully and know them precisely before the next meeting", "type": "text"}]}]}, {"type": "taskItem", "attrs": {"dir": "auto", "checked": false}, "content": [{"type": "paragraph", "attrs": {"id": "uudlesffojyr", "dir": "auto", "indent": 0}, "content": [{"text": " Team to prepare a clear action plan on each TRAC objective (what, how, when) for the next meeting", "type": "text"}]}]}, {"type": "taskItem", "attrs": {"dir": "auto", "checked": false}, "content": [{"type": "paragraph", "attrs": {"id": "jglenzjcqjko", "dir": "auto", "indent": 0}, "content": [{"text": " Team to prepare a more detailed work schedule/organization overview for the next meeting", "type": "text"}]}]}, {"type": "taskItem", "attrs": {"dir": "auto", "checked": false}, "content": [{"type": "paragraph", "attrs": {"id": "ndjstajctjhb", "dir": "auto", "indent": 0}, "content": [{"text": " Team to organize Veille Techno: dedicate ~1 hour/week per person to research, test tracks via POC, and document results", "type": "text"}]}]}, {"type": "taskItem", "attrs": {"dir": "auto", "checked": false}, "content": [{"type": "paragraph", "attrs": {"id": "lcupjqpiifyg", "dir": "auto", "indent": 0}, "content": [{"text": " Team to produce structured documentation (architecture diagrams, CI/CD, test plans, etc.) targeting different audiences (users, admins, researchers)", "type": "text"}]}]}, {"type": "taskItem", "attrs": {"dir": "auto", "checked": false}, "content": [{"type": "paragraph", "attrs": {"id": "vuomdzxwtful", "dir": "auto", "indent": 0}, "content": [{"text": " Team to measure, analyze, and iterate on performance — not just measure once", "type": "text"}]}]}, {"type": "taskItem", "attrs": {"dir": "auto", "checked": false}, "content": [{"type": "paragraph", "attrs": {"id": "xfgrimngfhso", "dir": "auto", "indent": 0}, "content": [{"text": " Team to ensure all members attend the weekly synchro point, not just 3–4", "type": "text"}]}]}, {"type": "taskItem", "attrs": {"dir": "auto", "checked": false}, "content": [{"type": "paragraph", "attrs": {"id": "kmhcizqlukyh", "dir": "auto", "indent": 0}, "content": [{"text": " Team to identify and document the project's \\"hard point\\" for Mandatory Objective 1", "type": "text"}]}]}, {"type": "taskItem", "attrs": {"dir": "auto", "checked": false}, "content": [{"type": "paragraph", "attrs": {"id": "zwmtjyerjvjr", "dir": "auto", "indent": 0}, "content": [{"text": " Team to prepare the meeting document (as done last time) for the next session", "type": "text"}]}]}, {"type": "taskItem", "attrs": {"dir": "auto", "checked": false}, "content": [{"type": "paragraph", "attrs": {"id": "cgprjuvhpgyd", "dir": "auto", "indent": 0}, "content": [{"text": " Next meeting scheduled for ", "type": "text"}, {"text": "Friday, October 16", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}, {"text": " (moved up from week of Oct 19 due to exam period)", "type": "text"}]}]}]}, {"type": "horizontalRule", "attrs": {"dir": "auto"}}, {"type": "heading", "attrs": {"id": "kmjhlswvxojt", "dir": "auto", "level": 3, "indent": 0}, "content": [{"text": "Project Overview", "type": "text"}]}, {"type": "bulletList", "attrs": {"dir": "auto"}, "content": [{"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "jeyzhzpqjzvn", "dir": "auto", "indent": 0}, "content": [{"text": "Project name:", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}, {"text": " Consoré — aimed at helping neurotypical people navigate digital life and achieve digital autonomy", "type": "text"}]}]}, {"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "aizjbmpiccvw", "dir": "auto", "indent": 0}, "content": [{"text": "Three main components:", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}, {"text": " Backend (API foundation), Dashboard (web interface for helpers), and Launcher (managed by Elias)", "type": "text"}]}]}, {"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "ixooamhxziqv", "dir": "auto", "indent": 0}, "content": [{"text": "Task management:", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}, {"text": " Using Jira (chosen over GitHub Projects based on prior project management experience, approved by DPR)", "type": "text"}]}]}, {"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "cyzmbahtxkxs", "dir": "auto", "indent": 0}, "content": [{"text": "Team locations:", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}, {"text": " Sweden (Elias), Berlin (Enzo), Dublin/Ireland (Lucas, Alexandre), Canada/Quebec (one member), with home schools in Montpellier and Paris", "type": "text"}]}]}]}, {"type": "heading", "attrs": {"id": "hbadxodjzvqe", "dir": "auto", "level": 3, "indent": 0}, "content": [{"text": "Attendance", "type": "text"}]}, {"type": "bulletList", "attrs": {"dir": "auto"}, "content": [{"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "oabjrywehewm", "dir": "auto", "indent": 0}, "content": [{"text": "Ibrahim was absent", "type": "text"}]}]}, {"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "aamidbbldkyo", "dir": "auto", "indent": 0}, "content": [{"text": "Alexandre was absent due to illness (uncertain if attending at all)", "type": "text"}]}]}, {"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "yadhwduzvsee", "dir": "auto", "indent": 0}, "content": [{"text": "Angel/Angèle arrived late", "type": "text"}]}]}]}, {"type": "heading", "attrs": {"id": "pvniofnazzui", "dir": "auto", "level": 3, "indent": 0}, "content": [{"text": "Progress Update", "type": "text"}]}, {"type": "bulletList", "attrs": {"dir": "auto"}, "content": [{"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "jjtfcejlvzgl", "dir": "auto", "indent": 0}, "content": [{"text": "All installation and minor corrections from the previous session have been completed", "type": "text"}]}]}, {"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "ervmktekisdw", "dir": "auto", "indent": 0}, "content": [{"text": "Current goal: build a solid foundation for each component — somewhere between a POC and MVP — before moving to sprints", "type": "text"}]}]}, {"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "euimpbvfomqh", "dir": "auto", "indent": 0}, "content": [{"text": "Code is being documented incrementally via PRs", "type": "text"}]}]}, {"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "ovkivndmcdkt", "dir": "auto", "indent": 0}, "content": [{"text": "Two complementary secondary tracks defined: ", "type": "text"}, {"text": "Track A", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}, {"text": " (secure technical environment) and ", "type": "text"}, {"text": "Track D", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}, {"text": " (measure, test, and optimize performance)", "type": "text"}]}]}]}, {"type": "heading", "attrs": {"id": "qigvrpjrbett", "dir": "auto", "level": 3, "indent": 0}, "content": [{"text": "Objectives Review (Student Guide)", "type": "text"}]}, {"type": "bulletList", "attrs": {"dir": "auto"}, "content": [{"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "mmgssvzzrgsf", "dir": "auto", "indent": 0}, "content": [{"text": "The supervisor noted the team was not sufficiently familiar with their formal TRAC objectives and stressed the need to know them precisely", "type": "text"}]}]}, {"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "gdzcgruglzko", "dir": "auto", "indent": 0}, "content": [{"text": "Mandatory Objective 1:", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}, {"text": " Organize and conduct a technological watch (Veille Techno) to identify and address the project's \\"hard point\\" — due end of October", "type": "text"}]}, {"type": "bulletList", "attrs": {"dir": "auto"}, "content": [{"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "etfafmusvwwu", "dir": "auto", "indent": 0}, "content": [{"text": "Team has not yet clearly identified the hard point", "type": "text"}]}]}, {"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "vbmaqpcmhpqd", "dir": "auto", "indent": 0}, "content": [{"text": "Approach: weekly research sessions → test tracks (POC) → document outcomes → determine if/how they integrate into the project", "type": "text"}]}]}, {"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "fdfwazjstgkh", "dir": "auto", "indent": 0}, "content": [{"text": "Documents must be produced and ready to justify the Veille Techno at the go/no-go", "type": "text"}]}]}]}]}, {"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "yuddjmweyhrm", "dir": "auto", "indent": 0}, "content": [{"text": "Mandatory Objective 2:", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}, {"text": " Structured, documented, and reliable architecture — includes architecture diagrams, CI/CD, test plans", "type": "text"}]}, {"type": "bulletList", "attrs": {"dir": "auto"}, "content": [{"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "czkxywlqjffu", "dir": "auto", "indent": 0}, "content": [{"text": "Documentation must be purpose-aware: distinguish between docs for users, admins, and researchers", "type": "text"}]}]}]}]}, {"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "dhcssbplwklp", "dir": "auto", "indent": 0}, "content": [{"text": "Complementary Objectives (A & D):", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}, {"text": " Match the two secondary tracks already chosen; for Track D, measurement must lead to analysis, modification, and re-measurement — not just a one-time metric", "type": "text"}]}]}, {"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "muverkqroatr", "dir": "auto", "indent": 0}, "content": [{"text": "The Student Guide also contains a list of required deliverables — team was reminded to consult it", "type": "text"}]}]}]}, {"type": "heading", "attrs": {"id": "crcycsdnmtil", "dir": "auto", "level": 3, "indent": 0}, "content": [{"text": "Working Methods & Team Organization", "type": "text"}]}, {"type": "bulletList", "attrs": {"dir": "auto"}, "content": [{"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "evhxmesxwirx", "dir": "auto", "indent": 0}, "content": [{"text": "Team works asynchronously with assigned tasks; code reviews are done by peers", "type": "text"}]}]}, {"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "bifqyrestvtg", "dir": "auto", "indent": 0}, "content": [{"text": "Occasional joint Discord work sessions are held; working hours are shared so others can join", "type": "text"}]}]}, {"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "rgoqypjsnyxg", "dir": "auto", "indent": 0}, "content": [{"text": "A weekly weekend synchro point already exists, but only 3–4 members typically attend", "type": "text"}]}]}, {"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "keubncfczuqg", "dir": "auto", "indent": 0}, "content": [{"text": "Supervisor emphasized the importance of a more rigid work framework given the fully remote, multi-country setup, and the natural tendency to deprioritize the project", "type": "text"}]}]}]}, {"type": "heading", "attrs": {"id": "wceqcjukpcnn", "dir": "auto", "level": 3, "indent": 0}, "content": [{"text": "Supervisor Feedback & Next Steps", "type": "text"}]}, {"type": "bulletList", "attrs": {"dir": "auto"}, "content": [{"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "bpbpdssfvybm", "dir": "auto", "indent": 0}, "content": [{"text": "The team jumped into tools (Jira) before explaining goals and direction — the supervisor asked for a clearer narrative: objective → approach → implementation", "type": "text"}]}]}, {"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "miwznpcdvfvx", "dir": "auto", "indent": 0}, "content": [{"text": "For the next meeting, the team should present: action plans per objective, a clearer work schedule, and demonstrate they know their objectives", "type": "text"}]}]}, {"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "lyarvzprxatq", "dir": "auto", "indent": 0}, "content": [{"text": "The supervisor is available for async questions via the existing Discord channel", "type": "text"}]}]}]}, {"type": "heading", "attrs": {"id": "vrroqtpssaes", "dir": "auto", "level": 1, "indent": 0}, "content": [{"text": "Transcript", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}]}, {"type": "paragraph", "attrs": {"id": "fhkhkljttfkx", "dir": "auto", "indent": 0}, "content": [{"text": "Hello? Can you hear me?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "yzmroviwngef", "dir": "auto", "indent": 0}, "content": [{"text": "I would have taken it off Discord. Oh wow, wait, why? Ah yes, you have to take it off Discord for that.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "oebkvhaorryk", "dir": "auto", "indent": 0}, "content": [{"text": "Hello. Hello.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "sbeompimdiam", "dir": "auto", "indent": 0}, "content": [{"text": "Up.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "omteqsaxjhcb", "dir": "auto", "indent": 0}, "content": [{"text": "Kavaizhu! Very well, thank you. Yes, I may have been connected a little early, you may have wanted to discuss before I arrived. No, but tell me. There's no problem, I'll take it quite well.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "czkgjecyxdnb", "dir": "auto", "indent": 0}, "content": [{"text": "No, you're about to do it.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "vbzitfcxfduj", "dir": "auto", "indent": 0}, "content": [{"text": "Don't worry. I saw that you sent me the document. In the conversation, the little preparation there? Thank you very much. It's very good, it allowed me to start filling things up.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "qsydtzxnxqhh", "dir": "auto", "indent": 0}, "content": [{"text": "Yes, that's it.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "qdtsyyaaglrt", "dir": "auto", "indent": 0}, "content": [{"text": "Let's see.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "kkpanpqrksgk", "dir": "auto", "indent": 0}, "content": [{"text": "It will save us a lot of time.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "chdticknbryr", "dir": "auto", "indent": 0}, "content": [{"text": "Thank you. Is the others here?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "logkknpadrof", "dir": "auto", "indent": 0}, "content": [{"text": "They haven't answered yet.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "vioilvvzsdag", "dir": "auto", "indent": 0}, "content": [{"text": "Okay. That's perfect.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "rkzdytosmvwk", "dir": "auto", "indent": 0}, "content": [{"text": "For now, there are only four. There's no Ibrahim, Angel... And Alexandra.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "wnnquudrgxai", "dir": "auto", "indent": 0}, "content": [{"text": "So Alexandre is busy. So, Alexandre, will you come back? No, Alexandre is not sure because he's sick. We don't know if he's coming or not. We're a bit waiting for it.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "oczznwfudaqr", "dir": "auto", "indent": 0}, "content": [{"text": "I'll let you know, and if he comes, you'll let me know.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "oybmnxzqtity", "dir": "auto", "indent": 0}, "content": [{"text": "Okay.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "jyiaeqrpmbur", "dir": "auto", "indent": 0}, "content": [{"text": "Angel Angèle will arrive in a minute.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "qesvhnkfrmmd", "dir": "auto", "indent": 0}, "content": [{"text": "Ibrahim won't arrive.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "horjpineyeme", "dir": "auto", "indent": 0}, "content": [{"text": "Brahim, I won't see you. Okay.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "hfkcdwpclufl", "dir": "auto", "indent": 0}, "content": [{"text": "I take this opportunity to make the adjustments. Oh, Boop, boop, boop. I think Ibrahim already liked it.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "vhmgeyrtzzlc", "dir": "auto", "indent": 0}, "content": [{"text": "Yeah. It's very possible.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "bvjystcxdtre", "dir": "auto", "indent": 0}, "content": [{"text": "My camera is not detected on Ubuntu, so I think I'll have to restart my computer.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "ntavdmobfucc", "dir": "auto", "indent": 0}, "content": [{"text": "Go ahead, we have time while I take care of that. So, indeed, Ibrahim, I don't have it. I have Elia, Sanjo, Angel, Lucas and Alexandre. OK. Well, Ibrahim, are we going to take it out of the meeting?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "blsrpuqwstjq", "dir": "auto", "indent": 0}, "content": [{"text": "This is Shri Mataji: Sh Okay.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "wrlllrwybzmi", "dir": "auto", "indent": 0}, "content": [{"text": "Sorry, I'm back with you. So where is Alexandre Paula? C'est tout. Okay. Great. So, we only miss Alexandre, since Angel is here. What I propose is that you start by reminding me in one sentence your project. the goal of the project, so that it allows us to be sure, to remember to remind me of your project and then talk about your progress and then we will work on the objectives. Is everyone okay?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "twioinvkqapn", "dir": "auto", "indent": 0}, "content": [{"text": "It's perfect.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "uwajzakkxwiu", "dir": "auto", "indent": 0}, "content": [{"text": "Where's the bucket?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "ygoajvndojnu", "dir": "auto", "indent": 0}, "content": [{"text": "Wait.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "ipfysmtrpvzn", "dir": "auto", "indent": 0}, "content": [{"text": "Okay, great. Wait, just a second.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "pnzpmhxpvdvi", "dir": "auto", "indent": 0}, "content": [{"text": "You just woke up, Angel. you It's 7:30, Pity. I went to bed at 3 or 4 o'clock.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "xusskevwqgrw", "dir": "auto", "indent": 0}, "content": [{"text": "Go ahead, I'm listening. Hello? I look at my loss. Great. Yeah, not very strong, but... Wow.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "ogfjjzbawxjg", "dir": "auto", "indent": 0}, "content": [{"text": "Is it better like that?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "koogadbppumk", "dir": "auto", "indent": 0}, "content": [{"text": "Yes, much better. Perfect.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "kpkkvrnfmiwo", "dir": "auto", "indent": 0}, "content": [{"text": "-Let's see it again soon.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "cimhdwnzyiyo", "dir": "auto", "indent": 0}, "content": [{"text": "No.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "yjjfdhjijkow", "dir": "auto", "indent": 0}, "content": [{"text": "If you want, I can do it.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "prhzmomqamgs", "dir": "auto", "indent": 0}, "content": [{"text": "Right. So, \\"Consoré\\" is a project aimed at helping neurotypical people We are going to have a sort of introduction to everything that is digital life. and all that is around us, rather digital autonomy. In a sentence...", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "lsaksirpuyap", "dir": "auto", "indent": 0}, "content": [{"text": "Okay.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "dpalmsminlio", "dir": "auto", "indent": 0}, "content": [{"text": "So, tell me about your progress.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "bipspnlgumpe", "dir": "auto", "indent": 0}, "content": [{"text": "to allow everyone to follow what everyone is doing. What else? People can addWe have the development of the backend, we have the development of the frontend, I don't know if Elias already started. We have the loader, I don't know. des jours. Do you have something to add?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "adcwipsgezjf", "dir": "auto", "indent": 0}, "content": [{"text": "Thank you.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "uqtosocjawqi", "dir": "auto", "indent": 0}, "content": [{"text": "you I will define it again, on the Jira side, we have finished all the installation and minor corrections that there were compared to the last time.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "llbyncjjilzt", "dir": "auto", "indent": 0}, "content": [{"text": "Your SUI seems really well prepared. I don't know, people, is there anything to add? Put yourself in my shoes, I just want to go do something else.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "qkfrvxfziwqr", "dir": "auto", "indent": 0}, "content": [{"text": "But wait, we were talking about Jira, but maybe we should put it back in context.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "fpxehcqhspxa", "dir": "auto", "indent": 0}, "content": [{"text": "Jira, what is it for? Why? Where is your project? I have a little trouble understanding.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "xiiwaqedonmj", "dir": "auto", "indent": 0}, "content": [{"text": "I will let Angèle talk about Jiraz, he is the one who is mainly busy.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "evwnxbfgppcc", "dir": "auto", "indent": 0}, "content": [{"text": "you Is this. Is it possible to share the screen so you can see better?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "mpojktpewqan", "dir": "auto", "indent": 0}, "content": [{"text": "Yes, of course.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "rywwbbwmxvma", "dir": "auto", "indent": 0}, "content": [{"text": "So I'll do that for you. But if you want, before talking to me about Jira, It would be nice to talk a little bit about what you have done, your goals, where you are going, to structure a little bit. I mean, you remind me of a guy who builds a car and you're explaining to me that you grind rubber but at the end of the day I understand that you want to make a tire. Okay.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "qevulbhlpiem", "dir": "auto", "indent": 0}, "content": [{"text": "So, we started with the technical work, as you know, and the last time, two weeks ago, we didn't really have any secondary tracks yet. We defined our two secondary tracks, A and D, We found it consistent with the technical treatment. a more secure technical environment, so to protect and ensure that this environment So, it's the secondary track A. and the D secondary track which is measure, test and optimize the performance of our in the project.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "gfxsmnlmgixe", "dir": "auto", "indent": 0}, "content": [{"text": "We did these two tracks in secondary school because we found it quite common with a technical project. And for the other tracks, maybe we can work on it too. We'll see because it's often communication tracks that we've seen. It's something that we'll have to come up with later. But for now, we don't find it really important to do the follow-up every two weeks. We preferred to take these tracks. So to do this, we use a follow-up tool called Jira.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "zgpzoupvrltk", "dir": "auto", "indent": 0}, "content": [{"text": "We didn't choose GitHub Project because Personally, I preferred to use Jira. It's a tool that I used a lot during my training in management of projects and others. That's why we started on Gira on this project and it was approved by our DPR. I'll show you what it looks like.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "lacvfbwhkonr", "dir": "auto", "indent": 0}, "content": [{"text": "So the giraffe is for the... It's for the complementary objective number 1.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "yewbeetoqrwq", "dir": "auto", "indent": 0}, "content": [{"text": "You It was about identifying the problem and it was about defining the architecture and having a sort of reliable architecture.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "vbbpzwbhzztq", "dir": "auto", "indent": 0}, "content": [{"text": "Also, that's it. But it's a kind of management tool, just for task development. It's quite basic. It's a bit like a GitHub project. Disqcc is a ticketing tool that allows you to organize yourself in a group. They can't worry about San Lucas.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "aneinfgacqjr", "dir": "auto", "indent": 0}, "content": [{"text": "you Okay.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "uxoivpmhjzws", "dir": "auto", "indent": 0}, "content": [{"text": "I'll quickly show you what it looks like.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "mtfippczvvbv", "dir": "auto", "indent": 0}, "content": [{"text": "I imagine you know me, but that's it. No, Lizzie. What matters to me is to understand that it's not so much the tool itself, Hmm? What matters to me is What have you done? Where are you going? What are the working methods? What are your objectives? How do you work? I don't care if you use Jira, GitHub, whatever you want. But today, we didn't even talk about where you're going, you're throwing Jira at me. Thank you. You see what I mean?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "jqbaousybvqt", "dir": "auto", "indent": 0}, "content": [{"text": "I think the first thing would be to say, well, here we are, we have such an objective to achieve. To achieve this objective, we have to do this, this, this and that. To do this, this and that, we are going to organize ourselves in such and such a way. And that's what we're going to put in place. Okay. So, you chose to help, that's good. It seems to me, given your project, it doesn't seem like a big deal.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "oerswbwbvkgm", "dir": "auto", "indent": 0}, "content": [{"text": "Then, actually, explain why. Well, very well. And then say, OK, now that we've chosen that, what are we going to put in place to meet the objectives? Thank you.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "jszdupeeslcc", "dir": "auto", "indent": 0}, "content": [{"text": ". For now, we haven't decided to go by a sprint system because we plan to go by sprints, but the current one, the one that will probably come soon. But personally, and even for the whole, we chose to do that because we all arrived in our country, settled in, we started classes and all. We don't all necessarily have the same availability and other things. And so, what we did was to have a The main task is to create a solid foundation.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "zskdeednjnuj", "dir": "auto", "indent": 0}, "content": [{"text": "A technical project, so at least having a MVP on each side, not necessarily a MVP, between the POC and the MVP, that is to say, something that works right to left everywhere a solid base is enough on each on for each part, so on the backend, the dashboard, the launcher, all these parts? Once this is done, during the coming month, we will set up sprints to work on it and then we will have a more regular follow-up on that.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "dbtupurzamhm", "dir": "auto", "indent": 0}, "content": [{"text": "So everyone must build a baseThat's it.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "ccdguetkhxqd", "dir": "auto", "indent": 0}, "content": [{"text": "Between POC and MVP, MVP is pretty good, I think. But it's a bit between the two.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "uurodcfmlyxj", "dir": "auto", "indent": 0}, "content": [{"text": "No, go ahead. So, that means you identified the parties? This is her. So what are these parties?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "zmzleahsemha", "dir": "auto", "indent": 0}, "content": [{"text": "So, we have some parts. We have the basin, so here there will be uh all our... like API and others, so it's kind of our foundation. And this... We have the dashboard, which is more superficial, it's the web part where the helpers will connect. It's a slightly separate part, whether it's a track or a backing track. Then we have the launcher, Elias is taking care of it for now. um, For now, it's three big parties that connect to each other.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "ugkwpjtppomy", "dir": "auto", "indent": 0}, "content": [{"text": "And then there might be other things that will come over it, but that's not right now. So, that's it. We're going to say that's three big parts for now.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "mcxdycbcmlsx", "dir": "auto", "indent": 0}, "content": [{"text": "Backend, Dashboard and Launcher. That's right. Oh That works. Okay. For now, on the mandatory objectives, you have advanced?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "gdmnswwjtcbq", "dir": "auto", "indent": 0}, "content": [{"text": "uh We continue when everyone works on our side, we document our part of the code. We try to make some PR issues, but each time the part of the code is a little documented at least. And we're trying to document it as best we can for now.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "cyrplhaqycmu", "dir": "auto", "indent": 0}, "content": [{"text": "Wait, we may not have understood. What are the mandatory objectives for you?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "qkntwnkehika", "dir": "auto", "indent": 0}, "content": [{"text": "the So Um But I don't.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "crrsxjxbpaor", "dir": "auto", "indent": 0}, "content": [{"text": "moi j'ai pas ce qui me dérange c'est là comment dira the approximate number of your answers I mean, the objectives of TRAC, mandatory, complementary and so on, it must be something precise. You don't have to tell me, I think the objectives are about that. I mean, tonight, the French team at the Stade de France, they know where they have to score the goal. yeah the wall foot rebound maybe we have to move the ball forward towards the oh shit You have a document Student Guide, okay?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "yxtkctkmtvxb", "dir": "auto", "indent": 0}, "content": [{"text": "In which there are objectives and you are told if you don't have the objective, you won't have your IP. You have to read them, know them. I tell you, what is your objective that we can... mandatory number one, you tell me, yeah, that's it. You should know it and you should have already started working on it. Okay? Huh? Knowing that the last time I made you notice that you hadn't read the guide and that you absolutely had to read it.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "xmlyoqfdmxeu", "dir": "auto", "indent": 0}, "content": [{"text": "Okay. Anyway. I'm a little annoying you there because if there is no one who moves you, you understand what I mean. We have to read together the objectives, that you are very clear with that and that you realize them. Do you have the document under your eyes? Uh, we. So it's Student Guide. So share it so that we can all agree on what we read.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "gmhjozsgqbvx", "dir": "auto", "indent": 0}, "content": [{"text": "Allez-y.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "yotcjjtqwrls", "dir": "auto", "indent": 0}, "content": [{"text": "You can do it. Go ahead.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "kfcqoijivptl", "dir": "auto", "indent": 0}, "content": [{"text": "Oh you I don't know how to do it.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "gontppvzkvdn", "dir": "auto", "indent": 0}, "content": [{"text": "I'll be right back while you share. I'm coming. Go ahead, go ahead.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "ztqtetmwgieg", "dir": "auto", "indent": 0}, "content": [{"text": "I was thereYeah.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "hyfemnicmwzh", "dir": "auto", "indent": 0}, "content": [{"text": "It's just that...", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "pavordwshtja", "dir": "auto", "indent": 0}, "content": [{"text": "Yeah, for the screen.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "vgpbhjkrewmx", "dir": "auto", "indent": 0}, "content": [{"text": "So that's not it.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "mwsrmzbimpiu", "dir": "auto", "indent": 0}, "content": [{"text": "That's the second one.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "jhicdwquomwr", "dir": "auto", "indent": 0}, "content": [{"text": "Perfect. What? That's the first objective. What?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "neyswqortllu", "dir": "auto", "indent": 0}, "content": [{"text": "And so... Before the end of October, we had the problem characterization. Yeah, hard point.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "jhdtxpopdkqv", "dir": "auto", "indent": 0}, "content": [{"text": "That's it. In French, the number one objective is to organize your technological wave and exploit it to lift the hard point. project Okay. What?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "obveykuxvqna", "dir": "auto", "indent": 0}, "content": [{"text": "Put it here.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "nusqvzamlfnh", "dir": "auto", "indent": 0}, "content": [{"text": "Key.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "eksteidxvqhg", "dir": "auto", "indent": 0}, "content": [{"text": "Hello.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "giodsqjulaqz", "dir": "auto", "indent": 0}, "content": [{"text": "Do you have an idea of what could be the hard part of your project today? Do you have an idea of how to make the Veil Techno?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "vqisydcxmmfi", "dir": "auto", "indent": 0}, "content": [{"text": "No, not really.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "gpnmuwpzildw", "dir": "auto", "indent": 0}, "content": [{"text": "I'm sorry. It's complicated to define. There's a visualizer There's a visualizer Okay, we're all...", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "cltbtxjlhkmk", "dir": "auto", "indent": 0}, "content": [{"text": "So, for the hard point, I can't help you. I could, but I don't want to. First, it's up to you to do it. Oh. Organizing this technology Thank you. Oh. To organize the technical day, what I advise youYeah. See? But You ask the questions. As usual, it's the old technology. How are we going to do it? How much time will we spend on it? What do we want to get out of it? How will she be able to help us in the project? Okay? Where does it integrate, etc.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "opwbehmyiypi", "dir": "auto", "indent": 0}, "content": [{"text": "So the idea is to say you are five, You will say, \\"OK, per week, everyone spends an hour of Veille Techno.\\" During this hour, we do research. At the end of this hour, Identify the tracks. Yes, we remove the track, we test it, we do a POC. Yes, it works. No, it doesn't work. We don't remember the track, we don't remember it for this reason. After the POC, is it useful? Is it not? If it's useful, where will it go in the project?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "pdmwqceftbyr", "dir": "auto", "indent": 0}, "content": [{"text": "All of this must be consigned, make documents Produce these documents because that's what we're asking you for. We're going to ask you to justify your technological advance. We're not going to ask you to do it, we're going to ask you to justify it.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "dadcblkplpot", "dir": "auto", "indent": 0}, "content": [{"text": "So, these documents, for example, Did they get you to do it?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "eptusjzcllpz", "dir": "auto", "indent": 0}, "content": [{"text": "All the weeks? We just keep them on the side to prove it.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "jybaremzpbwq", "dir": "auto", "indent": 0}, "content": [{"text": "Ah no, I mean, yes, we will discuss it together, that's the goal of our meetings, okay? So you can give them to us in advance and so on, that's the goal of our rendezvous. But above all, we're going to have to produce them on the day of the go-no-go. Thank you.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "gpuvxpoxkopr", "dir": "auto", "indent": 0}, "content": [{"text": "OK, so that's how you have to lead your your techno watch. You have to produce. Searching. Verify. Considere. Okay.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "imeilbijsvye", "dir": "auto", "indent": 0}, "content": [{"text": "Okay.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "vxfcesgojonx", "dir": "auto", "indent": 0}, "content": [{"text": "Let's go.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "sqwucikppakv", "dir": "auto", "indent": 0}, "content": [{"text": "to And for the second objective, which was also supposed to be at the end of October, So, the search for setups.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "jfflzzwfkttn", "dir": "auto", "indent": 0}, "content": [{"text": "So that in my opinion is not the second objective. You mix everything, you have to be super precise when you talk. That's not the second objective, we're still in the first one. What? Yes, if you tell me second objective, I think of second objective of TRAC. Your second goal is to Structured, documented, and reliable. Okay? So that's going to be everything that is architecture diagrams. documentation, CI/CD, test plan, etc.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "vyywlranysmk", "dir": "auto", "indent": 0}, "content": [{"text": "Chip. Okay. When we do doc, we ask ourselves why we did it, what we do, how we did it.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "loffrtiulqeq", "dir": "auto", "indent": 0}, "content": [{"text": "Okay.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "uebxcghxfvmb", "dir": "auto", "indent": 0}, "content": [{"text": "Okay? It's not the same as doing A tutorial? for a user, to do a man for an administrator or to do an article for a researcher. No doubt.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "lxzzbsmicnhy", "dir": "auto", "indent": 0}, "content": [{"text": "Look at that guy.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "wzglvwqpscrg", "dir": "auto", "indent": 0}, "content": [{"text": "So you think aboutYou think about the different types of docs. different types of people and how it matches.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "varvifgvixuv", "dir": "auto", "indent": 0}, "content": [{"text": "Okay, that works.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "adziqimbgcjp", "dir": "auto", "indent": 0}, "content": [{"text": "Is that good for you? -Same thing, on the complementary objectives, the two there. Measure, test, optimize. Okay. Same thing, reflection on What do we set up? What do we want to measure? Once we have measured it, we analyze it.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "vpmhpjbwspek", "dir": "auto", "indent": 0}, "content": [{"text": "I got it.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "dfakgsgqstab", "dir": "auto", "indent": 0}, "content": [{"text": "we modify and we reanalyze. It's not just that we measured it, we're happy. 1.12 meters, great. No. We measure something, we deduce performance problems or not, we say, \\"Here, we're going to modify this thing\\" and we measure again.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "bqpilncxthec", "dir": "auto", "indent": 0}, "content": [{"text": "There we go.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "yjdipjzwvcyg", "dir": "auto", "indent": 0}, "content": [{"text": "Okay, is that good for you?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "bthqvjrsjuod", "dir": "auto", "indent": 0}, "content": [{"text": "So So What the...", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "sjogajckmiti", "dir": "auto", "indent": 0}, "content": [{"text": "Wait what? Once again, you have to read the objectives and then tell yourself what to expect, what to expect as an output, what to do. For whom should I do it? Thank you. um In this document, you have the list of supplies to supply. Think about looking at it. Okay. Do you have any organization problems in the group? Given the distance, where are you currently?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "zsohbkwctjfa", "dir": "auto", "indent": 0}, "content": [{"text": "We have one in Germany, in Berlin, two in Ireland. Dukas and Alexandre are not there, in Germany we have Enzo, in Sweden we have Elias and I am in Canada.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "srtprhcxpuox", "dir": "auto", "indent": 0}, "content": [{"text": "Yes, that's it: Sweden, Berlin, Dublin and Quebec. And you are Epitech Montpellier?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "qszoeowesgrk", "dir": "auto", "indent": 0}, "content": [{"text": "Montpellier, in Paris.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "bddpzwuthtgj", "dir": "auto", "indent": 0}, "content": [{"text": "Yeah. Yeah, Montpellier, Paris, that's it?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "clliqglbxzaj", "dir": "auto", "indent": 0}, "content": [{"text": "Alexandre, he comes from Paris. That works.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "yyifrukigrgu", "dir": "auto", "indent": 0}, "content": [{"text": "OK. Before I forget, do you have an idea for the next meeting? So, theoretically, it should be the week of October 19th.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "ufxrsunhwevr", "dir": "auto", "indent": 0}, "content": [{"text": "I'm so serious. Ms. Exxon. We're all starting to have our final moments. In any case, this is the case for Alexandre-Emer. We are beginning to have our time for the definitive. And on October 19, It's not a test period for me, so I'll have a lot of free time. Okay. I would like to do less this week, because it's a week of exams, of mid-sessions. Thank you. I have an exam every day on this week.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "gpuadmsygqry", "dir": "auto", "indent": 0}, "content": [{"text": "So if we do Friday 16th, It's been two weeks instead of three. Hmm.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "pjxtxlwahzyd", "dir": "auto", "indent": 0}, "content": [{"text": "But I haven't done anything this week. I don't mind. Friday, 16, I'm fine. I'm fine with that too.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "orntwofrrpoo", "dir": "auto", "indent": 0}, "content": [{"text": "Pokemon was it?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "bwbgivzsaktu", "dir": "auto", "indent": 0}, "content": [{"text": "Yes, there is no problem.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "padtwptoirlu", "dir": "auto", "indent": 0}, "content": [{"text": "What?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "ssiwbwvcnaqp", "dir": "auto", "indent": 0}, "content": [{"text": "Yes, I think so.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "dgghtdqkqdxj", "dir": "auto", "indent": 0}, "content": [{"text": "We plan the arrival. Do you prepare the thing like last time? Thank you. Okay. Are you preparing for the meeting?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "otvnpznnsdfn", "dir": "auto", "indent": 0}, "content": [{"text": "It works.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "ojepcgiselqx", "dir": "auto", "indent": 0}, "content": [{"text": "The guest and everything, that's good?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "ginzxjuibdik", "dir": "auto", "indent": 0}, "content": [{"text": "It's good, we invite you both.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "egptvnzfmgyj", "dir": "auto", "indent": 0}, "content": [{"text": "What is it?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "zqyfvwlcxzdg", "dir": "auto", "indent": 0}, "content": [{"text": "It works, great. Okay, okay, okay. -Uh... Tuk, tuk, tuk. Okay. I would like to come back to your working methods. but How are you currently working together?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "lyjtkveziijz", "dir": "auto", "indent": 0}, "content": [{"text": "We all feel a bit at home, we have our tasks, we are assigned, we work on them. And then we do the reviews that are not done by other people. Or sometimes we do sessions together in We have a Discord and we get into it. We work from 2 to 3, and then he comes when he wants to work. Sometimes we do sessions like that.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "doaxqghdoegv", "dir": "auto", "indent": 0}, "content": [{"text": "We talked about it with Lucas to complete what he said. We try to put together mandatory meetings but most of the time we give our working hours that we are going to do and we try to see with people who can come etc.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "vxapsdlylejy", "dir": "auto", "indent": 0}, "content": [{"text": "It's to motivate. But then there are people who will have to work together because they will do similar tasks or in the same field. And in this case, we will try to send messages, either on Discord or even on WhatsApp to try to organize and find a time frame in which we will be able to work together.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "vrqkryykpuzi", "dir": "auto", "indent": 0}, "content": [{"text": "Thank you. Ok, we should add a synchro point, an abdominal one, I think. At the beginning. Hm? That is to say, Once a week, even if it's only 15 minutes, 20 minutes, half an hour, the whole group meets to say: \\"This is what we did this week on the OIB.\\" Not necessarily work sessions, but at least synchro points.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "vwxemlrqycuu", "dir": "auto", "indent": 0}, "content": [{"text": "Yeah, we already have one per week. We already know what to do.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "eizewnhhixrz", "dir": "auto", "indent": 0}, "content": [{"text": "Yeah, no, but do you hold on to it?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "tulsvpntzbwm", "dir": "auto", "indent": 0}, "content": [{"text": "Yes, we do it on weekends. I'm so convinced by the... Thank you. We are all available, so we can do it.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "kavdpoxgvois", "dir": "auto", "indent": 0}, "content": [{"text": "So there you have a synchro point. You have a synchro point, Hebdo? Bye.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "cekdtzbacszs", "dir": "auto", "indent": 0}, "content": [{"text": "We're not all in it. We're four in it, in general. Three, four in it. We should all be in it, that's the problem. Yeah, yeah. I understand, but... It's hard to manage to rally everyone at the same time, but it should be. I'm on the same campus as him, so I see him quite regularly. He doesn't share with everyone. I have news about what he's doing and if he advances on the IP. It's not ideal, but I think he had problems for the IP.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "ymbedabwwcfm", "dir": "auto", "indent": 0}, "content": [{"text": "his apartment and well, he's sick but I see it at least twice a week.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "fikcqsypsfqb", "dir": "auto", "indent": 0}, "content": [{"text": "Okay. Let's hope it doesn't count. So for the next time, I would really like you to offer me action plans. So, on the objectives.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "ojwfckqkustz", "dir": "auto", "indent": 0}, "content": [{"text": "okay Thank you.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "xpwhnnxptskv", "dir": "auto", "indent": 0}, "content": [{"text": "And maybe a point on your work organization?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "fkrjowfsoigg", "dir": "auto", "indent": 0}, "content": [{"text": "So, to be more precise, how do we work?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "fkzfodlpfzci", "dir": "auto", "indent": 0}, "content": [{"text": "Yeah, let's say you answer me because you say if I don't answer, he's going to leave every weekend, that's nice, but... I don't have the impression that there is a... When we are all at a distance, it is really important to have a framework of work that is a little more rigid than when we see each other. When we see each other, we can remember each other. Hmm. If I decide not to hang up or if for example a video conf I do not put my camera I can do a lot of things.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "tihglurgykal", "dir": "auto", "indent": 0}, "content": [{"text": "If I shout at you you can turn down the sound, etc. It's not the same as when you see yourself in real life. If we are in a room and I start to hit you hard, you will feel very It's different from if you're on a screen and you're rolling on it. Well, it's the same for you, actually. It's the same between you. So, in a lesser extent, but you feel less pressure, there will always be something more important or more interesting to do than the IP, which is quite normal.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "wbzvhtwhoqsp", "dir": "auto", "indent": 0}, "content": [{"text": "So it's important to remember very regularly that you have to do the IP, knowing that it is not the most important thing in a life. That's not what I'm saying. Of course, but it has its importance and so it's important to remember it regularly, okay?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "wvyblduqfurb", "dir": "auto", "indent": 0}, "content": [{"text": "Okay.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "bnafsumxvmzg", "dir": "auto", "indent": 0}, "content": [{"text": "Thank you. Voilà.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "qgpflkfphuio", "dir": "auto", "indent": 0}, "content": [{"text": "Okay.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "fpjbbqrfbacw", "dir": "auto", "indent": 0}, "content": [{"text": "To the best of their ability, once again. It's not the most important thing in a life, but it's important.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "ozxmvklugrec", "dir": "auto", "indent": 0}, "content": [{"text": "Thank you. So, I would like a point on your work schedule a little more provided, okay? Thank you. No, sir. It works, we're not bad here. And then above all, I insist, an action plan on the objectives, a clear vision. Michael? Where do we want to go?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "azxwfuwgcfek", "dir": "auto", "indent": 0}, "content": [{"text": "Okay.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "vpwtmqeaaxbb", "dir": "auto", "indent": 0}, "content": [{"text": "How do we want to do it? And when? We will do it. Cheers. Okay. OK. Yeah.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "fykvssypkkhv", "dir": "auto", "indent": 0}, "content": [{"text": "Okay?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "qnhiahxsqsgi", "dir": "auto", "indent": 0}, "content": [{"text": "Yeah.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "gzcqbkjmmndu", "dir": "auto", "indent": 0}, "content": [{"text": "Do you have any questions? Complaints, comments, criticisms, do not hesitate.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "gbiuptwczlyg", "dir": "auto", "indent": 0}, "content": [{"text": "No, so... I don't have that many complaints. On the contrary, I like the fact that that things are said suddenly because it allows us to move forward more than we think, which is not going directly. I prefer to serve.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "obzdinuxdxkg", "dir": "auto", "indent": 0}, "content": [{"text": "So the big interest is that I'm just here to help you. So... We can tell each other things. I won't write you down. There's no note. So, we can say things to each other. On the contrary. It's the main thing. Okay? My goal is that you do your best.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "dfcdhkktphpl", "dir": "auto", "indent": 0}, "content": [{"text": "Thank you.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "ggcgxdxebpjg", "dir": "auto", "indent": 0}, "content": [{"text": "Thank you anyway.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "xtxvbvrmeued", "dir": "auto", "indent": 0}, "content": [{"text": "Okay, that's my only goal. Okay. So you do a loop on all the objectives If you need, you can send me a message from time to time to tell me: \\"We saw this, what do you think about it?\\" It doesn't cause me any problem. Okay.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "wlyukqnktodj", "dir": "auto", "indent": 0}, "content": [{"text": "On this channel?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "meckakrisgdz", "dir": "auto", "indent": 0}, "content": [{"text": "Yes, on this channel. We keep this room, so we have all the history there. If we start talking 5 or 6 times, we can't get out of it. Okay?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "jcdxqlmizkqn", "dir": "auto", "indent": 0}, "content": [{"text": "Okay.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "daynvnlpalsz", "dir": "auto", "indent": 0}, "content": [{"text": "Okay.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "qkguipnjupmn", "dir": "auto", "indent": 0}, "content": [{"text": "Okay, perfect.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "harnunnhtbgo", "dir": "auto", "indent": 0}, "content": [{"text": "If you don't have any other questions, that's good for me. Okay.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "bqpjhxammvin", "dir": "auto", "indent": 0}, "content": [{"text": "I don't think we can.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "zzobqvvlhobv", "dir": "auto", "indent": 0}, "content": [{"text": "We'll plan it.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "krxbirmgnvez", "dir": "auto", "indent": 0}, "content": [{"text": "Okay, it works. Thank you. And of course, don't hesitate. rightThank you.", "type": "text"}]}, {"type": "bulletList", "attrs": {"dir": "auto"}, "content": [{"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "pvecfwgvhfov", "dir": "auto", "indent": 0}}]}]}, {"type": "paragraph", "attrs": {"id": "txdzmiyyvpth", "dir": "auto", "indent": 0}, "content": [{"text": "Have a good day. Thank you. you", "type": "text"}]}]}	\N	\N	\N	\N	01a12cf1-0bd0-70e9-87f3-436c4e3a4023	01a12d28-97bc-7e08-89d5-3b6f4a7a6d57	01a12cf1-0bd3-7a42-96f8-8cedaf38cf22	2026-10-11 22:53:31.016293+00	2026-10-11 22:53:31.016293+00	{01a12cf1-0bd0-70e9-87f3-436c4e3a4023}
01a12d2d-b62c-7958-94e6-55c6653ee414	01a12d29-b33c-7771-a510-a4f4d1590e6d	I7zExxA6XC	Compte rendu - Octobre 2, 2026	{"type": "doc", "content": [{"type": "heading", "attrs": {"id": "nsaavdvqubfn", "dir": "auto", "level": 1, "indent": 0}, "content": [{"text": "Summary", "type": "text"}]}, {"type": "heading", "attrs": {"id": "cbpmpksgwkvb", "dir": "auto", "level": 3, "indent": 0}, "content": [{"text": "Action Items", "type": "text"}]}, {"type": "taskList", "attrs": {"dir": "auto"}, "content": [{"type": "taskItem", "attrs": {"dir": "auto", "checked": false}, "content": [{"type": "paragraph", "attrs": {"id": "ceyxjrufsfzy", "dir": "auto", "indent": 0}, "content": [{"text": " Team to read the Student Guide objectives carefully and know them precisely before the next meeting", "type": "text"}]}]}, {"type": "taskItem", "attrs": {"dir": "auto", "checked": false}, "content": [{"type": "paragraph", "attrs": {"id": "uudlesffojyr", "dir": "auto", "indent": 0}, "content": [{"text": " Team to prepare a clear action plan on each TRAC objective (what, how, when) for the next meeting", "type": "text"}]}]}, {"type": "taskItem", "attrs": {"dir": "auto", "checked": false}, "content": [{"type": "paragraph", "attrs": {"id": "jglenzjcqjko", "dir": "auto", "indent": 0}, "content": [{"text": " Team to prepare a more detailed work schedule/organization overview for the next meeting", "type": "text"}]}]}, {"type": "taskItem", "attrs": {"dir": "auto", "checked": false}, "content": [{"type": "paragraph", "attrs": {"id": "ndjstajctjhb", "dir": "auto", "indent": 0}, "content": [{"text": " Team to organize Veille Techno: dedicate ~1 hour/week per person to research, test tracks via POC, and document results", "type": "text"}]}]}, {"type": "taskItem", "attrs": {"dir": "auto", "checked": false}, "content": [{"type": "paragraph", "attrs": {"id": "lcupjqpiifyg", "dir": "auto", "indent": 0}, "content": [{"text": " Team to produce structured documentation (architecture diagrams, CI/CD, test plans, etc.) targeting different audiences (users, admins, researchers)", "type": "text"}]}]}, {"type": "taskItem", "attrs": {"dir": "auto", "checked": false}, "content": [{"type": "paragraph", "attrs": {"id": "vuomdzxwtful", "dir": "auto", "indent": 0}, "content": [{"text": " Team to measure, analyze, and iterate on performance — not just measure once", "type": "text"}]}]}, {"type": "taskItem", "attrs": {"dir": "auto", "checked": false}, "content": [{"type": "paragraph", "attrs": {"id": "xfgrimngfhso", "dir": "auto", "indent": 0}, "content": [{"text": " Team to ensure all members attend the weekly synchro point, not just 3–4", "type": "text"}]}]}, {"type": "taskItem", "attrs": {"dir": "auto", "checked": false}, "content": [{"type": "paragraph", "attrs": {"id": "kmhcizqlukyh", "dir": "auto", "indent": 0}, "content": [{"text": " Team to identify and document the project's \\"hard point\\" for Mandatory Objective 1", "type": "text"}]}]}, {"type": "taskItem", "attrs": {"dir": "auto", "checked": false}, "content": [{"type": "paragraph", "attrs": {"id": "zwmtjyerjvjr", "dir": "auto", "indent": 0}, "content": [{"text": " Team to prepare the meeting document (as done last time) for the next session", "type": "text"}]}]}, {"type": "taskItem", "attrs": {"dir": "auto", "checked": false}, "content": [{"type": "paragraph", "attrs": {"id": "cgprjuvhpgyd", "dir": "auto", "indent": 0}, "content": [{"text": " Next meeting scheduled for ", "type": "text"}, {"text": "Friday, October 16", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}, {"text": " (moved up from week of Oct 19 due to exam period)", "type": "text"}]}]}]}, {"type": "horizontalRule", "attrs": {"dir": "auto"}}, {"type": "heading", "attrs": {"id": "kmjhlswvxojt", "dir": "auto", "level": 3, "indent": 0}, "content": [{"text": "Project Overview", "type": "text"}]}, {"type": "bulletList", "attrs": {"dir": "auto"}, "content": [{"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "jeyzhzpqjzvn", "dir": "auto", "indent": 0}, "content": [{"text": "Project name:", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}, {"text": " Consoré — aimed at helping neurotypical people navigate digital life and achieve digital autonomy", "type": "text"}]}]}, {"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "aizjbmpiccvw", "dir": "auto", "indent": 0}, "content": [{"text": "Three main components:", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}, {"text": " Backend (API foundation), Dashboard (web interface for helpers), and Launcher (managed by Elias)", "type": "text"}]}]}, {"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "ixooamhxziqv", "dir": "auto", "indent": 0}, "content": [{"text": "Task management:", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}, {"text": " Using Jira (chosen over GitHub Projects based on prior project management experience, approved by DPR)", "type": "text"}]}]}, {"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "cyzmbahtxkxs", "dir": "auto", "indent": 0}, "content": [{"text": "Team locations:", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}, {"text": " Sweden (Elias), Berlin (Enzo), Dublin/Ireland (Lucas, Alexandre), Canada/Quebec (one member), with home schools in Montpellier and Paris", "type": "text"}]}]}]}, {"type": "heading", "attrs": {"id": "hbadxodjzvqe", "dir": "auto", "level": 3, "indent": 0}, "content": [{"text": "Attendance", "type": "text"}]}, {"type": "bulletList", "attrs": {"dir": "auto"}, "content": [{"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "oabjrywehewm", "dir": "auto", "indent": 0}, "content": [{"text": "Ibrahim was absent", "type": "text"}]}]}, {"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "aamidbbldkyo", "dir": "auto", "indent": 0}, "content": [{"text": "Alexandre was absent due to illness (uncertain if attending at all)", "type": "text"}]}]}, {"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "yadhwduzvsee", "dir": "auto", "indent": 0}, "content": [{"text": "Angel/Angèle arrived late", "type": "text"}]}]}]}, {"type": "heading", "attrs": {"id": "pvniofnazzui", "dir": "auto", "level": 3, "indent": 0}, "content": [{"text": "Progress Update", "type": "text"}]}, {"type": "bulletList", "attrs": {"dir": "auto"}, "content": [{"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "jjtfcejlvzgl", "dir": "auto", "indent": 0}, "content": [{"text": "All installation and minor corrections from the previous session have been completed", "type": "text"}]}]}, {"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "ervmktekisdw", "dir": "auto", "indent": 0}, "content": [{"text": "Current goal: build a solid foundation for each component — somewhere between a POC and MVP — before moving to sprints", "type": "text"}]}]}, {"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "euimpbvfomqh", "dir": "auto", "indent": 0}, "content": [{"text": "Code is being documented incrementally via PRs", "type": "text"}]}]}, {"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "ovkivndmcdkt", "dir": "auto", "indent": 0}, "content": [{"text": "Two complementary secondary tracks defined: ", "type": "text"}, {"text": "Track A", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}, {"text": " (secure technical environment) and ", "type": "text"}, {"text": "Track D", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}, {"text": " (measure, test, and optimize performance)", "type": "text"}]}]}]}, {"type": "heading", "attrs": {"id": "qigvrpjrbett", "dir": "auto", "level": 3, "indent": 0}, "content": [{"text": "Objectives Review (Student Guide)", "type": "text"}]}, {"type": "bulletList", "attrs": {"dir": "auto"}, "content": [{"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "mmgssvzzrgsf", "dir": "auto", "indent": 0}, "content": [{"text": "The supervisor noted the team was not sufficiently familiar with their formal TRAC objectives and stressed the need to know them precisely", "type": "text"}]}]}, {"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "gdzcgruglzko", "dir": "auto", "indent": 0}, "content": [{"text": "Mandatory Objective 1:", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}, {"text": " Organize and conduct a technological watch (Veille Techno) to identify and address the project's \\"hard point\\" — due end of October", "type": "text"}]}, {"type": "bulletList", "attrs": {"dir": "auto"}, "content": [{"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "etfafmusvwwu", "dir": "auto", "indent": 0}, "content": [{"text": "Team has not yet clearly identified the hard point", "type": "text"}]}]}, {"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "vbmaqpcmhpqd", "dir": "auto", "indent": 0}, "content": [{"text": "Approach: weekly research sessions → test tracks (POC) → document outcomes → determine if/how they integrate into the project", "type": "text"}]}]}, {"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "fdfwazjstgkh", "dir": "auto", "indent": 0}, "content": [{"text": "Documents must be produced and ready to justify the Veille Techno at the go/no-go", "type": "text"}]}]}]}]}, {"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "yuddjmweyhrm", "dir": "auto", "indent": 0}, "content": [{"text": "Mandatory Objective 2:", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}, {"text": " Structured, documented, and reliable architecture — includes architecture diagrams, CI/CD, test plans", "type": "text"}]}, {"type": "bulletList", "attrs": {"dir": "auto"}, "content": [{"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "czkxywlqjffu", "dir": "auto", "indent": 0}, "content": [{"text": "Documentation must be purpose-aware: distinguish between docs for users, admins, and researchers", "type": "text"}]}]}]}]}, {"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "dhcssbplwklp", "dir": "auto", "indent": 0}, "content": [{"text": "Complementary Objectives (A & D):", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}, {"text": " Match the two secondary tracks already chosen; for Track D, measurement must lead to analysis, modification, and re-measurement — not just a one-time metric", "type": "text"}]}]}, {"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "muverkqroatr", "dir": "auto", "indent": 0}, "content": [{"text": "The Student Guide also contains a list of required deliverables — team was reminded to consult it", "type": "text"}]}]}]}, {"type": "heading", "attrs": {"id": "crcycsdnmtil", "dir": "auto", "level": 3, "indent": 0}, "content": [{"text": "Working Methods & Team Organization", "type": "text"}]}, {"type": "bulletList", "attrs": {"dir": "auto"}, "content": [{"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "evhxmesxwirx", "dir": "auto", "indent": 0}, "content": [{"text": "Team works asynchronously with assigned tasks; code reviews are done by peers", "type": "text"}]}]}, {"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "bifqyrestvtg", "dir": "auto", "indent": 0}, "content": [{"text": "Occasional joint Discord work sessions are held; working hours are shared so others can join", "type": "text"}]}]}, {"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "rgoqypjsnyxg", "dir": "auto", "indent": 0}, "content": [{"text": "A weekly weekend synchro point already exists, but only 3–4 members typically attend", "type": "text"}]}]}, {"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "keubncfczuqg", "dir": "auto", "indent": 0}, "content": [{"text": "Supervisor emphasized the importance of a more rigid work framework given the fully remote, multi-country setup, and the natural tendency to deprioritize the project", "type": "text"}]}]}]}, {"type": "heading", "attrs": {"id": "wceqcjukpcnn", "dir": "auto", "level": 3, "indent": 0}, "content": [{"text": "Supervisor Feedback & Next Steps", "type": "text"}]}, {"type": "bulletList", "attrs": {"dir": "auto"}, "content": [{"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "bpbpdssfvybm", "dir": "auto", "indent": 0}, "content": [{"text": "The team jumped into tools (Jira) before explaining goals and direction — the supervisor asked for a clearer narrative: objective → approach → implementation", "type": "text"}]}]}, {"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "miwznpcdvfvx", "dir": "auto", "indent": 0}, "content": [{"text": "For the next meeting, the team should present: action plans per objective, a clearer work schedule, and demonstrate they know their objectives", "type": "text"}]}]}, {"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "lyarvzprxatq", "dir": "auto", "indent": 0}, "content": [{"text": "The supervisor is available for async questions via the existing Discord channel", "type": "text"}]}]}]}, {"type": "heading", "attrs": {"id": "vrroqtpssaes", "dir": "auto", "level": 1, "indent": 0}, "content": [{"text": "Transcript", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}]}, {"type": "paragraph", "attrs": {"id": "fhkhkljttfkx", "dir": "auto", "indent": 0}, "content": [{"text": "Hello? Can you hear me?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "yzmroviwngef", "dir": "auto", "indent": 0}, "content": [{"text": "I would have taken it off Discord. Oh wow, wait, why? Ah yes, you have to take it off Discord for that.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "oebkvhaorryk", "dir": "auto", "indent": 0}, "content": [{"text": "Hello. Hello.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "sbeompimdiam", "dir": "auto", "indent": 0}, "content": [{"text": "Up.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "omteqsaxjhcb", "dir": "auto", "indent": 0}, "content": [{"text": "Kavaizhu! Very well, thank you. Yes, I may have been connected a little early, you may have wanted to discuss before I arrived. No, but tell me. There's no problem, I'll take it quite well.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "czkgjecyxdnb", "dir": "auto", "indent": 0}, "content": [{"text": "No, you're about to do it.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "vbzitfcxfduj", "dir": "auto", "indent": 0}, "content": [{"text": "Don't worry. I saw that you sent me the document. In the conversation, the little preparation there? Thank you very much. It's very good, it allowed me to start filling things up.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "qsydtzxnxqhh", "dir": "auto", "indent": 0}, "content": [{"text": "Yes, that's it.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "qdtsyyaaglrt", "dir": "auto", "indent": 0}, "content": [{"text": "Let's see.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "kkpanpqrksgk", "dir": "auto", "indent": 0}, "content": [{"text": "It will save us a lot of time.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "chdticknbryr", "dir": "auto", "indent": 0}, "content": [{"text": "Thank you. Is the others here?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "logkknpadrof", "dir": "auto", "indent": 0}, "content": [{"text": "They haven't answered yet.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "vioilvvzsdag", "dir": "auto", "indent": 0}, "content": [{"text": "Okay. That's perfect.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "rkzdytosmvwk", "dir": "auto", "indent": 0}, "content": [{"text": "For now, there are only four. There's no Ibrahim, Angel... And Alexandra.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "wnnquudrgxai", "dir": "auto", "indent": 0}, "content": [{"text": "So Alexandre is busy. So, Alexandre, will you come back? No, Alexandre is not sure because he's sick. We don't know if he's coming or not. We're a bit waiting for it.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "oczznwfudaqr", "dir": "auto", "indent": 0}, "content": [{"text": "I'll let you know, and if he comes, you'll let me know.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "oybmnxzqtity", "dir": "auto", "indent": 0}, "content": [{"text": "Okay.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "jyiaeqrpmbur", "dir": "auto", "indent": 0}, "content": [{"text": "Angel Angèle will arrive in a minute.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "qesvhnkfrmmd", "dir": "auto", "indent": 0}, "content": [{"text": "Ibrahim won't arrive.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "horjpineyeme", "dir": "auto", "indent": 0}, "content": [{"text": "Brahim, I won't see you. Okay.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "hfkcdwpclufl", "dir": "auto", "indent": 0}, "content": [{"text": "I take this opportunity to make the adjustments. Oh, Boop, boop, boop. I think Ibrahim already liked it.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "vhmgeyrtzzlc", "dir": "auto", "indent": 0}, "content": [{"text": "Yeah. It's very possible.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "bvjystcxdtre", "dir": "auto", "indent": 0}, "content": [{"text": "My camera is not detected on Ubuntu, so I think I'll have to restart my computer.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "ntavdmobfucc", "dir": "auto", "indent": 0}, "content": [{"text": "Go ahead, we have time while I take care of that. So, indeed, Ibrahim, I don't have it. I have Elia, Sanjo, Angel, Lucas and Alexandre. OK. Well, Ibrahim, are we going to take it out of the meeting?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "blsrpuqwstjq", "dir": "auto", "indent": 0}, "content": [{"text": "This is Shri Mataji: Sh Okay.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "wrlllrwybzmi", "dir": "auto", "indent": 0}, "content": [{"text": "Sorry, I'm back with you. So where is Alexandre Paula? C'est tout. Okay. Great. So, we only miss Alexandre, since Angel is here. What I propose is that you start by reminding me in one sentence your project. the goal of the project, so that it allows us to be sure, to remember to remind me of your project and then talk about your progress and then we will work on the objectives. Is everyone okay?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "twioinvkqapn", "dir": "auto", "indent": 0}, "content": [{"text": "It's perfect.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "uwajzakkxwiu", "dir": "auto", "indent": 0}, "content": [{"text": "Where's the bucket?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "ygoajvndojnu", "dir": "auto", "indent": 0}, "content": [{"text": "Wait.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "ipfysmtrpvzn", "dir": "auto", "indent": 0}, "content": [{"text": "Okay, great. Wait, just a second.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "pnzpmhxpvdvi", "dir": "auto", "indent": 0}, "content": [{"text": "You just woke up, Angel. you It's 7:30, Pity. I went to bed at 3 or 4 o'clock.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "xusskevwqgrw", "dir": "auto", "indent": 0}, "content": [{"text": "Go ahead, I'm listening. Hello? I look at my loss. Great. Yeah, not very strong, but... Wow.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "ogfjjzbawxjg", "dir": "auto", "indent": 0}, "content": [{"text": "Is it better like that?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "koogadbppumk", "dir": "auto", "indent": 0}, "content": [{"text": "Yes, much better. Perfect.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "kpkkvrnfmiwo", "dir": "auto", "indent": 0}, "content": [{"text": "-Let's see it again soon.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "cimhdwnzyiyo", "dir": "auto", "indent": 0}, "content": [{"text": "No.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "yjjfdhjijkow", "dir": "auto", "indent": 0}, "content": [{"text": "If you want, I can do it.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "prhzmomqamgs", "dir": "auto", "indent": 0}, "content": [{"text": "Right. So, \\"Consoré\\" is a project aimed at helping neurotypical people We are going to have a sort of introduction to everything that is digital life. and all that is around us, rather digital autonomy. In a sentence...", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "lsaksirpuyap", "dir": "auto", "indent": 0}, "content": [{"text": "Okay.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "dpalmsminlio", "dir": "auto", "indent": 0}, "content": [{"text": "So, tell me about your progress.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "bipspnlgumpe", "dir": "auto", "indent": 0}, "content": [{"text": "to allow everyone to follow what everyone is doing. What else? People can addWe have the development of the backend, we have the development of the frontend, I don't know if Elias already started. We have the loader, I don't know. des jours. Do you have something to add?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "adcwipsgezjf", "dir": "auto", "indent": 0}, "content": [{"text": "Thank you.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "uqtosocjawqi", "dir": "auto", "indent": 0}, "content": [{"text": "you I will define it again, on the Jira side, we have finished all the installation and minor corrections that there were compared to the last time.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "llbyncjjilzt", "dir": "auto", "indent": 0}, "content": [{"text": "Your SUI seems really well prepared. I don't know, people, is there anything to add? Put yourself in my shoes, I just want to go do something else.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "qkfrvxfziwqr", "dir": "auto", "indent": 0}, "content": [{"text": "But wait, we were talking about Jira, but maybe we should put it back in context.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "fpxehcqhspxa", "dir": "auto", "indent": 0}, "content": [{"text": "Jira, what is it for? Why? Where is your project? I have a little trouble understanding.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "xiiwaqedonmj", "dir": "auto", "indent": 0}, "content": [{"text": "I will let Angèle talk about Jiraz, he is the one who is mainly busy.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "evwnxbfgppcc", "dir": "auto", "indent": 0}, "content": [{"text": "you Is this. Is it possible to share the screen so you can see better?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "mpojktpewqan", "dir": "auto", "indent": 0}, "content": [{"text": "Yes, of course.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "rywwbbwmxvma", "dir": "auto", "indent": 0}, "content": [{"text": "So I'll do that for you. But if you want, before talking to me about Jira, It would be nice to talk a little bit about what you have done, your goals, where you are going, to structure a little bit. I mean, you remind me of a guy who builds a car and you're explaining to me that you grind rubber but at the end of the day I understand that you want to make a tire. Okay.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "qevulbhlpiem", "dir": "auto", "indent": 0}, "content": [{"text": "So, we started with the technical work, as you know, and the last time, two weeks ago, we didn't really have any secondary tracks yet. We defined our two secondary tracks, A and D, We found it consistent with the technical treatment. a more secure technical environment, so to protect and ensure that this environment So, it's the secondary track A. and the D secondary track which is measure, test and optimize the performance of our in the project.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "gfxsmnlmgixe", "dir": "auto", "indent": 0}, "content": [{"text": "We did these two tracks in secondary school because we found it quite common with a technical project. And for the other tracks, maybe we can work on it too. We'll see because it's often communication tracks that we've seen. It's something that we'll have to come up with later. But for now, we don't find it really important to do the follow-up every two weeks. We preferred to take these tracks. So to do this, we use a follow-up tool called Jira.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "zgpzoupvrltk", "dir": "auto", "indent": 0}, "content": [{"text": "We didn't choose GitHub Project because Personally, I preferred to use Jira. It's a tool that I used a lot during my training in management of projects and others. That's why we started on Gira on this project and it was approved by our DPR. I'll show you what it looks like.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "lacvfbwhkonr", "dir": "auto", "indent": 0}, "content": [{"text": "So the giraffe is for the... It's for the complementary objective number 1.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "yewbeetoqrwq", "dir": "auto", "indent": 0}, "content": [{"text": "You It was about identifying the problem and it was about defining the architecture and having a sort of reliable architecture.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "vbbpzwbhzztq", "dir": "auto", "indent": 0}, "content": [{"text": "Also, that's it. But it's a kind of management tool, just for task development. It's quite basic. It's a bit like a GitHub project. Disqcc is a ticketing tool that allows you to organize yourself in a group. They can't worry about San Lucas.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "aneinfgacqjr", "dir": "auto", "indent": 0}, "content": [{"text": "you Okay.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "uxoivpmhjzws", "dir": "auto", "indent": 0}, "content": [{"text": "I'll quickly show you what it looks like.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "mtfippczvvbv", "dir": "auto", "indent": 0}, "content": [{"text": "I imagine you know me, but that's it. No, Lizzie. What matters to me is to understand that it's not so much the tool itself, Hmm? What matters to me is What have you done? Where are you going? What are the working methods? What are your objectives? How do you work? I don't care if you use Jira, GitHub, whatever you want. But today, we didn't even talk about where you're going, you're throwing Jira at me. Thank you. You see what I mean?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "jqbaousybvqt", "dir": "auto", "indent": 0}, "content": [{"text": "I think the first thing would be to say, well, here we are, we have such an objective to achieve. To achieve this objective, we have to do this, this, this and that. To do this, this and that, we are going to organize ourselves in such and such a way. And that's what we're going to put in place. Okay. So, you chose to help, that's good. It seems to me, given your project, it doesn't seem like a big deal.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "oerswbwbvkgm", "dir": "auto", "indent": 0}, "content": [{"text": "Then, actually, explain why. Well, very well. And then say, OK, now that we've chosen that, what are we going to put in place to meet the objectives? Thank you.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "jszdupeeslcc", "dir": "auto", "indent": 0}, "content": [{"text": ". For now, we haven't decided to go by a sprint system because we plan to go by sprints, but the current one, the one that will probably come soon. But personally, and even for the whole, we chose to do that because we all arrived in our country, settled in, we started classes and all. We don't all necessarily have the same availability and other things. And so, what we did was to have a The main task is to create a solid foundation.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "zskdeednjnuj", "dir": "auto", "indent": 0}, "content": [{"text": "A technical project, so at least having a MVP on each side, not necessarily a MVP, between the POC and the MVP, that is to say, something that works right to left everywhere a solid base is enough on each on for each part, so on the backend, the dashboard, the launcher, all these parts? Once this is done, during the coming month, we will set up sprints to work on it and then we will have a more regular follow-up on that.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "dbtupurzamhm", "dir": "auto", "indent": 0}, "content": [{"text": "So everyone must build a baseThat's it.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "ccdguetkhxqd", "dir": "auto", "indent": 0}, "content": [{"text": "Between POC and MVP, MVP is pretty good, I think. But it's a bit between the two.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "uurodcfmlyxj", "dir": "auto", "indent": 0}, "content": [{"text": "No, go ahead. So, that means you identified the parties? This is her. So what are these parties?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "zmzleahsemha", "dir": "auto", "indent": 0}, "content": [{"text": "So, we have some parts. We have the basin, so here there will be uh all our... like API and others, so it's kind of our foundation. And this... We have the dashboard, which is more superficial, it's the web part where the helpers will connect. It's a slightly separate part, whether it's a track or a backing track. Then we have the launcher, Elias is taking care of it for now. um, For now, it's three big parties that connect to each other.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "ugkwpjtppomy", "dir": "auto", "indent": 0}, "content": [{"text": "And then there might be other things that will come over it, but that's not right now. So, that's it. We're going to say that's three big parts for now.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "mcxdycbcmlsx", "dir": "auto", "indent": 0}, "content": [{"text": "Backend, Dashboard and Launcher. That's right. Oh That works. Okay. For now, on the mandatory objectives, you have advanced?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "gdmnswwjtcbq", "dir": "auto", "indent": 0}, "content": [{"text": "uh We continue when everyone works on our side, we document our part of the code. We try to make some PR issues, but each time the part of the code is a little documented at least. And we're trying to document it as best we can for now.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "cyrplhaqycmu", "dir": "auto", "indent": 0}, "content": [{"text": "Wait, we may not have understood. What are the mandatory objectives for you?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "qkntwnkehika", "dir": "auto", "indent": 0}, "content": [{"text": "the So Um But I don't.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "crrsxjxbpaor", "dir": "auto", "indent": 0}, "content": [{"text": "moi j'ai pas ce qui me dérange c'est là comment dira the approximate number of your answers I mean, the objectives of TRAC, mandatory, complementary and so on, it must be something precise. You don't have to tell me, I think the objectives are about that. I mean, tonight, the French team at the Stade de France, they know where they have to score the goal. yeah the wall foot rebound maybe we have to move the ball forward towards the oh shit You have a document Student Guide, okay?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "yxtkctkmtvxb", "dir": "auto", "indent": 0}, "content": [{"text": "In which there are objectives and you are told if you don't have the objective, you won't have your IP. You have to read them, know them. I tell you, what is your objective that we can... mandatory number one, you tell me, yeah, that's it. You should know it and you should have already started working on it. Okay? Huh? Knowing that the last time I made you notice that you hadn't read the guide and that you absolutely had to read it.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "xmlyoqfdmxeu", "dir": "auto", "indent": 0}, "content": [{"text": "Okay. Anyway. I'm a little annoying you there because if there is no one who moves you, you understand what I mean. We have to read together the objectives, that you are very clear with that and that you realize them. Do you have the document under your eyes? Uh, we. So it's Student Guide. So share it so that we can all agree on what we read.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "gmhjozsgqbvx", "dir": "auto", "indent": 0}, "content": [{"text": "Allez-y.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "yotcjjtqwrls", "dir": "auto", "indent": 0}, "content": [{"text": "You can do it. Go ahead.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "kfcqoijivptl", "dir": "auto", "indent": 0}, "content": [{"text": "Oh you I don't know how to do it.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "gontppvzkvdn", "dir": "auto", "indent": 0}, "content": [{"text": "I'll be right back while you share. I'm coming. Go ahead, go ahead.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "ztqtetmwgieg", "dir": "auto", "indent": 0}, "content": [{"text": "I was thereYeah.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "hyfemnicmwzh", "dir": "auto", "indent": 0}, "content": [{"text": "It's just that...", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "pavordwshtja", "dir": "auto", "indent": 0}, "content": [{"text": "Yeah, for the screen.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "vgpbhjkrewmx", "dir": "auto", "indent": 0}, "content": [{"text": "So that's not it.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "mwsrmzbimpiu", "dir": "auto", "indent": 0}, "content": [{"text": "That's the second one.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "jhicdwquomwr", "dir": "auto", "indent": 0}, "content": [{"text": "Perfect. What? That's the first objective. What?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "neyswqortllu", "dir": "auto", "indent": 0}, "content": [{"text": "And so... Before the end of October, we had the problem characterization. Yeah, hard point.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "jhdtxpopdkqv", "dir": "auto", "indent": 0}, "content": [{"text": "That's it. In French, the number one objective is to organize your technological wave and exploit it to lift the hard point. project Okay. What?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "obveykuxvqna", "dir": "auto", "indent": 0}, "content": [{"text": "Put it here.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "nusqvzamlfnh", "dir": "auto", "indent": 0}, "content": [{"text": "Key.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "eksteidxvqhg", "dir": "auto", "indent": 0}, "content": [{"text": "Hello.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "giodsqjulaqz", "dir": "auto", "indent": 0}, "content": [{"text": "Do you have an idea of what could be the hard part of your project today? Do you have an idea of how to make the Veil Techno?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "vqisydcxmmfi", "dir": "auto", "indent": 0}, "content": [{"text": "No, not really.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "gpnmuwpzildw", "dir": "auto", "indent": 0}, "content": [{"text": "I'm sorry. It's complicated to define. There's a visualizer There's a visualizer Okay, we're all...", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "cltbtxjlhkmk", "dir": "auto", "indent": 0}, "content": [{"text": "So, for the hard point, I can't help you. I could, but I don't want to. First, it's up to you to do it. Oh. Organizing this technology Thank you. Oh. To organize the technical day, what I advise youYeah. See? But You ask the questions. As usual, it's the old technology. How are we going to do it? How much time will we spend on it? What do we want to get out of it? How will she be able to help us in the project? Okay? Where does it integrate, etc.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "opwbehmyiypi", "dir": "auto", "indent": 0}, "content": [{"text": "So the idea is to say you are five, You will say, \\"OK, per week, everyone spends an hour of Veille Techno.\\" During this hour, we do research. At the end of this hour, Identify the tracks. Yes, we remove the track, we test it, we do a POC. Yes, it works. No, it doesn't work. We don't remember the track, we don't remember it for this reason. After the POC, is it useful? Is it not? If it's useful, where will it go in the project?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "pdmwqceftbyr", "dir": "auto", "indent": 0}, "content": [{"text": "All of this must be consigned, make documents Produce these documents because that's what we're asking you for. We're going to ask you to justify your technological advance. We're not going to ask you to do it, we're going to ask you to justify it.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "dadcblkplpot", "dir": "auto", "indent": 0}, "content": [{"text": "So, these documents, for example, Did they get you to do it?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "eptusjzcllpz", "dir": "auto", "indent": 0}, "content": [{"text": "All the weeks? We just keep them on the side to prove it.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "jybaremzpbwq", "dir": "auto", "indent": 0}, "content": [{"text": "Ah no, I mean, yes, we will discuss it together, that's the goal of our meetings, okay? So you can give them to us in advance and so on, that's the goal of our rendezvous. But above all, we're going to have to produce them on the day of the go-no-go. Thank you.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "gpuvxpoxkopr", "dir": "auto", "indent": 0}, "content": [{"text": "OK, so that's how you have to lead your your techno watch. You have to produce. Searching. Verify. Considere. Okay.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "imeilbijsvye", "dir": "auto", "indent": 0}, "content": [{"text": "Okay.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "vxfcesgojonx", "dir": "auto", "indent": 0}, "content": [{"text": "Let's go.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "sqwucikppakv", "dir": "auto", "indent": 0}, "content": [{"text": "to And for the second objective, which was also supposed to be at the end of October, So, the search for setups.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "jfflzzwfkttn", "dir": "auto", "indent": 0}, "content": [{"text": "So that in my opinion is not the second objective. You mix everything, you have to be super precise when you talk. That's not the second objective, we're still in the first one. What? Yes, if you tell me second objective, I think of second objective of TRAC. Your second goal is to Structured, documented, and reliable. Okay? So that's going to be everything that is architecture diagrams. documentation, CI/CD, test plan, etc.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "vyywlranysmk", "dir": "auto", "indent": 0}, "content": [{"text": "Chip. Okay. When we do doc, we ask ourselves why we did it, what we do, how we did it.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "loffrtiulqeq", "dir": "auto", "indent": 0}, "content": [{"text": "Okay.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "uebxcghxfvmb", "dir": "auto", "indent": 0}, "content": [{"text": "Okay? It's not the same as doing A tutorial? for a user, to do a man for an administrator or to do an article for a researcher. No doubt.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "lxzzbsmicnhy", "dir": "auto", "indent": 0}, "content": [{"text": "Look at that guy.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "wzglvwqpscrg", "dir": "auto", "indent": 0}, "content": [{"text": "So you think aboutYou think about the different types of docs. different types of people and how it matches.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "varvifgvixuv", "dir": "auto", "indent": 0}, "content": [{"text": "Okay, that works.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "adziqimbgcjp", "dir": "auto", "indent": 0}, "content": [{"text": "Is that good for you? -Same thing, on the complementary objectives, the two there. Measure, test, optimize. Okay. Same thing, reflection on What do we set up? What do we want to measure? Once we have measured it, we analyze it.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "vpmhpjbwspek", "dir": "auto", "indent": 0}, "content": [{"text": "I got it.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "dfakgsgqstab", "dir": "auto", "indent": 0}, "content": [{"text": "we modify and we reanalyze. It's not just that we measured it, we're happy. 1.12 meters, great. No. We measure something, we deduce performance problems or not, we say, \\"Here, we're going to modify this thing\\" and we measure again.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "bqpilncxthec", "dir": "auto", "indent": 0}, "content": [{"text": "There we go.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "yjdipjzwvcyg", "dir": "auto", "indent": 0}, "content": [{"text": "Okay, is that good for you?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "bthqvjrsjuod", "dir": "auto", "indent": 0}, "content": [{"text": "So So What the...", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "sjogajckmiti", "dir": "auto", "indent": 0}, "content": [{"text": "Wait what? Once again, you have to read the objectives and then tell yourself what to expect, what to expect as an output, what to do. For whom should I do it? Thank you. um In this document, you have the list of supplies to supply. Think about looking at it. Okay. Do you have any organization problems in the group? Given the distance, where are you currently?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "zsohbkwctjfa", "dir": "auto", "indent": 0}, "content": [{"text": "We have one in Germany, in Berlin, two in Ireland. Dukas and Alexandre are not there, in Germany we have Enzo, in Sweden we have Elias and I am in Canada.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "srtprhcxpuox", "dir": "auto", "indent": 0}, "content": [{"text": "Yes, that's it: Sweden, Berlin, Dublin and Quebec. And you are Epitech Montpellier?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "qszoeowesgrk", "dir": "auto", "indent": 0}, "content": [{"text": "Montpellier, in Paris.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "bddpzwuthtgj", "dir": "auto", "indent": 0}, "content": [{"text": "Yeah. Yeah, Montpellier, Paris, that's it?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "clliqglbxzaj", "dir": "auto", "indent": 0}, "content": [{"text": "Alexandre, he comes from Paris. That works.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "yyifrukigrgu", "dir": "auto", "indent": 0}, "content": [{"text": "OK. Before I forget, do you have an idea for the next meeting? So, theoretically, it should be the week of October 19th.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "ufxrsunhwevr", "dir": "auto", "indent": 0}, "content": [{"text": "I'm so serious. Ms. Exxon. We're all starting to have our final moments. In any case, this is the case for Alexandre-Emer. We are beginning to have our time for the definitive. And on October 19, It's not a test period for me, so I'll have a lot of free time. Okay. I would like to do less this week, because it's a week of exams, of mid-sessions. Thank you. I have an exam every day on this week.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "gpuadmsygqry", "dir": "auto", "indent": 0}, "content": [{"text": "So if we do Friday 16th, It's been two weeks instead of three. Hmm.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "pjxtxlwahzyd", "dir": "auto", "indent": 0}, "content": [{"text": "But I haven't done anything this week. I don't mind. Friday, 16, I'm fine. I'm fine with that too.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "orntwofrrpoo", "dir": "auto", "indent": 0}, "content": [{"text": "Pokemon was it?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "bwbgivzsaktu", "dir": "auto", "indent": 0}, "content": [{"text": "Yes, there is no problem.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "padtwptoirlu", "dir": "auto", "indent": 0}, "content": [{"text": "What?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "ssiwbwvcnaqp", "dir": "auto", "indent": 0}, "content": [{"text": "Yes, I think so.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "dgghtdqkqdxj", "dir": "auto", "indent": 0}, "content": [{"text": "We plan the arrival. Do you prepare the thing like last time? Thank you. Okay. Are you preparing for the meeting?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "otvnpznnsdfn", "dir": "auto", "indent": 0}, "content": [{"text": "It works.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "ojepcgiselqx", "dir": "auto", "indent": 0}, "content": [{"text": "The guest and everything, that's good?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "ginzxjuibdik", "dir": "auto", "indent": 0}, "content": [{"text": "It's good, we invite you both.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "egptvnzfmgyj", "dir": "auto", "indent": 0}, "content": [{"text": "What is it?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "zqyfvwlcxzdg", "dir": "auto", "indent": 0}, "content": [{"text": "It works, great. Okay, okay, okay. -Uh... Tuk, tuk, tuk. Okay. I would like to come back to your working methods. but How are you currently working together?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "lyjtkveziijz", "dir": "auto", "indent": 0}, "content": [{"text": "We all feel a bit at home, we have our tasks, we are assigned, we work on them. And then we do the reviews that are not done by other people. Or sometimes we do sessions together in We have a Discord and we get into it. We work from 2 to 3, and then he comes when he wants to work. Sometimes we do sessions like that.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "doaxqghdoegv", "dir": "auto", "indent": 0}, "content": [{"text": "We talked about it with Lucas to complete what he said. We try to put together mandatory meetings but most of the time we give our working hours that we are going to do and we try to see with people who can come etc.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "vxapsdlylejy", "dir": "auto", "indent": 0}, "content": [{"text": "It's to motivate. But then there are people who will have to work together because they will do similar tasks or in the same field. And in this case, we will try to send messages, either on Discord or even on WhatsApp to try to organize and find a time frame in which we will be able to work together.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "vrqkryykpuzi", "dir": "auto", "indent": 0}, "content": [{"text": "Thank you. Ok, we should add a synchro point, an abdominal one, I think. At the beginning. Hm? That is to say, Once a week, even if it's only 15 minutes, 20 minutes, half an hour, the whole group meets to say: \\"This is what we did this week on the OIB.\\" Not necessarily work sessions, but at least synchro points.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "vwxemlrqycuu", "dir": "auto", "indent": 0}, "content": [{"text": "Yeah, we already have one per week. We already know what to do.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "eizewnhhixrz", "dir": "auto", "indent": 0}, "content": [{"text": "Yeah, no, but do you hold on to it?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "tulsvpntzbwm", "dir": "auto", "indent": 0}, "content": [{"text": "Yes, we do it on weekends. I'm so convinced by the... Thank you. We are all available, so we can do it.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "kavdpoxgvois", "dir": "auto", "indent": 0}, "content": [{"text": "So there you have a synchro point. You have a synchro point, Hebdo? Bye.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "cekdtzbacszs", "dir": "auto", "indent": 0}, "content": [{"text": "We're not all in it. We're four in it, in general. Three, four in it. We should all be in it, that's the problem. Yeah, yeah. I understand, but... It's hard to manage to rally everyone at the same time, but it should be. I'm on the same campus as him, so I see him quite regularly. He doesn't share with everyone. I have news about what he's doing and if he advances on the IP. It's not ideal, but I think he had problems for the IP.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "ymbedabwwcfm", "dir": "auto", "indent": 0}, "content": [{"text": "his apartment and well, he's sick but I see it at least twice a week.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "fikcqsypsfqb", "dir": "auto", "indent": 0}, "content": [{"text": "Okay. Let's hope it doesn't count. So for the next time, I would really like you to offer me action plans. So, on the objectives.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "ojwfckqkustz", "dir": "auto", "indent": 0}, "content": [{"text": "okay Thank you.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "xpwhnnxptskv", "dir": "auto", "indent": 0}, "content": [{"text": "And maybe a point on your work organization?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "fkrjowfsoigg", "dir": "auto", "indent": 0}, "content": [{"text": "So, to be more precise, how do we work?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "fkzfodlpfzci", "dir": "auto", "indent": 0}, "content": [{"text": "Yeah, let's say you answer me because you say if I don't answer, he's going to leave every weekend, that's nice, but... I don't have the impression that there is a... When we are all at a distance, it is really important to have a framework of work that is a little more rigid than when we see each other. When we see each other, we can remember each other. Hmm. If I decide not to hang up or if for example a video conf I do not put my camera I can do a lot of things.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "tihglurgykal", "dir": "auto", "indent": 0}, "content": [{"text": "If I shout at you you can turn down the sound, etc. It's not the same as when you see yourself in real life. If we are in a room and I start to hit you hard, you will feel very It's different from if you're on a screen and you're rolling on it. Well, it's the same for you, actually. It's the same between you. So, in a lesser extent, but you feel less pressure, there will always be something more important or more interesting to do than the IP, which is quite normal.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "wbzvhtwhoqsp", "dir": "auto", "indent": 0}, "content": [{"text": "So it's important to remember very regularly that you have to do the IP, knowing that it is not the most important thing in a life. That's not what I'm saying. Of course, but it has its importance and so it's important to remember it regularly, okay?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "wvyblduqfurb", "dir": "auto", "indent": 0}, "content": [{"text": "Okay.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "bnafsumxvmzg", "dir": "auto", "indent": 0}, "content": [{"text": "Thank you. Voilà.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "qgpflkfphuio", "dir": "auto", "indent": 0}, "content": [{"text": "Okay.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "fpjbbqrfbacw", "dir": "auto", "indent": 0}, "content": [{"text": "To the best of their ability, once again. It's not the most important thing in a life, but it's important.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "ozxmvklugrec", "dir": "auto", "indent": 0}, "content": [{"text": "Thank you. So, I would like a point on your work schedule a little more provided, okay? Thank you. No, sir. It works, we're not bad here. And then above all, I insist, an action plan on the objectives, a clear vision. Michael? Where do we want to go?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "azxwfuwgcfek", "dir": "auto", "indent": 0}, "content": [{"text": "Okay.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "vpwtmqeaaxbb", "dir": "auto", "indent": 0}, "content": [{"text": "How do we want to do it? And when? We will do it. Cheers. Okay. OK. Yeah.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "fykvssypkkhv", "dir": "auto", "indent": 0}, "content": [{"text": "Okay?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "qnhiahxsqsgi", "dir": "auto", "indent": 0}, "content": [{"text": "Yeah.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "gzcqbkjmmndu", "dir": "auto", "indent": 0}, "content": [{"text": "Do you have any questions? Complaints, comments, criticisms, do not hesitate.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "gbiuptwczlyg", "dir": "auto", "indent": 0}, "content": [{"text": "No, so... I don't have that many complaints. On the contrary, I like the fact that that things are said suddenly because it allows us to move forward more than we think, which is not going directly. I prefer to serve.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "obzdinuxdxkg", "dir": "auto", "indent": 0}, "content": [{"text": "So the big interest is that I'm just here to help you. So... We can tell each other things. I won't write you down. There's no note. So, we can say things to each other. On the contrary. It's the main thing. Okay? My goal is that you do your best.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "dfcdhkktphpl", "dir": "auto", "indent": 0}, "content": [{"text": "Thank you.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "ggcgxdxebpjg", "dir": "auto", "indent": 0}, "content": [{"text": "Thank you anyway.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "xtxvbvrmeued", "dir": "auto", "indent": 0}, "content": [{"text": "Okay, that's my only goal. Okay. So you do a loop on all the objectives If you need, you can send me a message from time to time to tell me: \\"We saw this, what do you think about it?\\" It doesn't cause me any problem. Okay.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "wlyukqnktodj", "dir": "auto", "indent": 0}, "content": [{"text": "On this channel?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "meckakrisgdz", "dir": "auto", "indent": 0}, "content": [{"text": "Yes, on this channel. We keep this room, so we have all the history there. If we start talking 5 or 6 times, we can't get out of it. Okay?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "jcdxqlmizkqn", "dir": "auto", "indent": 0}, "content": [{"text": "Okay.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "daynvnlpalsz", "dir": "auto", "indent": 0}, "content": [{"text": "Okay.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "qkguipnjupmn", "dir": "auto", "indent": 0}, "content": [{"text": "Okay, perfect.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "harnunnhtbgo", "dir": "auto", "indent": 0}, "content": [{"text": "If you don't have any other questions, that's good for me. Okay.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "bqpjhxammvin", "dir": "auto", "indent": 0}, "content": [{"text": "I don't think we can.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "zzobqvvlhobv", "dir": "auto", "indent": 0}, "content": [{"text": "We'll plan it.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "krxbirmgnvez", "dir": "auto", "indent": 0}, "content": [{"text": "Okay, it works. Thank you. And of course, don't hesitate. rightThank you.", "type": "text"}]}, {"type": "bulletList", "attrs": {"dir": "auto"}, "content": [{"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "pvecfwgvhfov", "dir": "auto", "indent": 0}}]}]}, {"type": "paragraph", "attrs": {"id": "txdzmiyyvpth", "dir": "auto", "indent": 0}, "content": [{"text": "Have a good day. Thank you. you", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "breyitelarnb", "dir": "auto", "indent": 0}}, {"type": "paragraph", "attrs": {"id": "yhfpdiapsggy", "dir": "auto", "indent": 0}, "content": []}]}	\N	\N	\N	\N	01a12cf1-0bd0-70e9-87f3-436c4e3a4023	01a12d28-97bc-7e08-89d5-3b6f4a7a6d57	01a12cf1-0bd3-7a42-96f8-8cedaf38cf22	2026-10-11 22:55:32.906213+00	2026-10-11 22:55:32.906213+00	{01a12cf1-0bd0-70e9-87f3-436c4e3a4023}
01a12d3e-4308-7723-8782-9ecaac527056	01a12d3d-5791-724e-b806-eff94b764e78	sXNWvhvlC2	[test-roundtrip] 1791760357232	{"type": "doc", "content": [{"type": "heading", "attrs": {"id": "evxgawasuvtg", "dir": "auto", "level": 1, "indent": 0}, "content": [{"text": "Titre test", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "nkzkjdmrwylu", "dir": "auto", "indent": 0}, "content": [{"text": "Paragraphe ", "type": "text"}, {"text": "gras", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}, {"text": " et ", "type": "text"}, {"text": "italique", "type": "text", "marks": [{"type": "italic", "attrs": {}}]}, {"text": ".", "type": "text"}]}, {"type": "codeBlock", "attrs": {"dir": "auto", "language": "js"}, "content": [{"text": "console.log('hello');", "type": "text"}]}, {"type": "heading", "attrs": {"id": "xnblackbmhpl", "dir": "auto", "level": 2, "indent": 0}, "content": [{"text": "Section ajoutée", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "snhiqcdjflwd", "dir": "auto", "indent": 0}, "content": [{"text": "Contenu supplémentaire.", "type": "text"}]}]}	\N	\N	\N	\N	01a12cf1-0bd0-70e9-87f3-436c4e3a4023	01a12d28-97bc-7e08-89d5-3b6f4a7a6d57	01a12cf1-0bd3-7a42-96f8-8cedaf38cf22	2026-10-11 23:13:37.544005+00	2026-10-11 23:13:37.544005+00	{01a12cf1-0bd0-70e9-87f3-436c4e3a4023}
01a12d3f-8cc2-752b-a550-50a12a5018ed	01a12d3e-a064-7971-b3f5-23da8d8c0bab	dzjNVW00tj	Dispositif de veille technologique	{"type": "doc", "content": [{"type": "paragraph", "attrs": {"id": "nxrraciegswd", "dir": "auto", "indent": 0}, "content": [{"text": "Projet ", "type": "text"}, {"text": "KansOS", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}, {"text": " · Technical Track Tech 4 · Objectif obligatoire 1", "type": "text"}, {"type": "hardBreak", "attrs": {"dir": "auto"}}, {"text": "14 octobre 2026", "type": "text"}]}, {"type": "horizontalRule", "attrs": {"dir": "auto"}}, {"type": "heading", "attrs": {"id": "gtfvycahneut", "dir": "auto", "level": 2, "indent": 0}, "content": [{"text": "À quoi elle sert", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "fzjdynvecgwy", "dir": "auto", "indent": 0}, "content": [{"text": "La veille sert à lever notre point dur : savoir quelle proportion des écrans d'une application tierce est assez décrite pour permettre un guidage fiable, et comment faire là où elle ne l'est pas.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "tqetvkbakmob", "dir": "auto", "indent": 0}, "content": [{"text": "Ce n'est pas un exercice documentaire. Chaque entrée du journal doit dire ce qu'elle change pour le projet, ou pourquoi elle ne change rien.", "type": "text"}]}, {"type": "heading", "attrs": {"id": "snhawyywbvex", "dir": "auto", "level": 2, "indent": 0}, "content": [{"text": "Rythme", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "holrwcxcqstj", "dir": "auto", "indent": 0}, "content": [{"text": "1 heure par personne et par semaine", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}, {"text": ", placée librement — l'équipe est répartie sur quatre pays et n'a pas les mêmes emplois du temps.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "epghhgdavwso", "dir": "auto", "indent": 0}, "content": [{"text": "Restitution au point de synchro hebdomadaire", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}, {"text": " du week-end, où chacun dit en deux minutes ce qu'il a trouvé.", "type": "text"}]}, {"type": "heading", "attrs": {"id": "zoapsfdxcqvd", "dir": "auto", "level": 2, "indent": 0}, "content": [{"text": "Répartition", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "jmipqyguoufe", "dir": "auto", "indent": 0}, "content": [{"text": "Alignée sur les trois composants. Chaque binôme suit aussi le sujet transverse qui relève de son composant, pour qu'aucun domaine ne reste sans responsable.", "type": "text"}]}, {"type": "table", "attrs": {"dir": "auto"}, "content": [{"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableHeader", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "jvugstlxkzhc", "dir": "auto", "indent": 0}, "content": [{"text": "Composant", "type": "text"}]}]}, {"type": "tableHeader", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "srncybybvfza", "dir": "auto", "indent": 0}, "content": [{"text": "Qui", "type": "text"}]}]}, {"type": "tableHeader", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "nkfimvoovgqr", "dir": "auto", "indent": 0}, "content": [{"text": "Domaines suivis", "type": "text"}]}]}]}, {"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "jxdfylookdaf", "dir": "auto", "indent": 0}, "content": [{"text": "Launcher", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "wygytfchhsak", "dir": "auto", "indent": 0}, "content": [{"text": "Elias + ", "type": "text"}, {"text": "[ ]", "type": "text", "marks": [{"type": "code", "attrs": {}}]}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "hnwaevpeajpx", "dir": "auto", "indent": 0}, "content": [{"text": "arbre d'accessibilité Android, API launcher, politique Google Play, modèles exécutables sur appareil", "type": "text"}]}]}]}, {"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "wmpyjjcqjeyo", "dir": "auto", "indent": 0}, "content": [{"text": "Backend", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "pzxzwfeyhfdt", "dir": "auto", "indent": 0}, "content": [{"text": "[ ]", "type": "text", "marks": [{"type": "code", "attrs": {}}]}, {"text": " + ", "type": "text"}, {"text": "[ ]", "type": "text", "marks": [{"type": "code", "attrs": {}}]}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "spwcfuxdbntt", "dir": "auto", "indent": 0}, "content": [{"text": "NestJS et Prisma, performance et observabilité, sécurité, chiffrement, RGPD et AI Act", "type": "text"}]}]}]}, {"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "lsyrwxhimsfh", "dir": "auto", "indent": 0}, "content": [{"text": "Dashboard", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "njfvjftqjjzo", "dir": "auto", "indent": 0}, "content": [{"text": "[ ]", "type": "text", "marks": [{"type": "code", "attrs": {}}]}, {"text": " + ", "type": "text"}, {"text": "[ ]", "type": "text", "marks": [{"type": "code", "attrs": {}}]}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "tzstweplrsza", "dir": "auto", "indent": 0}, "content": [{"text": "accessibilité web (RGAA, WCAG), FALC, ergonomie cognitive, déploiement et ROM dégooglisées", "type": "text"}]}]}]}]}, {"type": "paragraph", "attrs": {"id": "tepnksazkfmn", "dir": "auto", "indent": 0}, "content": [{"text": "Une veille portée par une seule personne ne se diffuse pas : c'est pour ça qu'il y a deux personnes par composant, et que la restitution est hebdomadaire.", "type": "text"}]}, {"type": "heading", "attrs": {"id": "dujnfqpvdgts", "dir": "auto", "level": 2, "indent": 0}, "content": [{"text": "Sources suivies", "type": "text"}]}, {"type": "table", "attrs": {"dir": "auto"}, "content": [{"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableHeader", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "dqxdnipcfdtq", "dir": "auto", "indent": 0}, "content": [{"text": "Source", "type": "text"}]}]}, {"type": "tableHeader", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "fvbtrydhbbte", "dir": "auto", "indent": 0}, "content": [{"text": "Ce qu'elle apporte", "type": "text"}]}]}, {"type": "tableHeader", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "vfwiqmflgtpx", "dir": "auto", "indent": 0}, "content": [{"text": "Binôme", "type": "text"}]}]}]}, {"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "sjyvfbuxiyqp", "dir": "auto", "indent": 0}, "content": [{"text": "Documentation Android — Accessibility", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "kttdzzwxzhsf", "dir": "auto", "indent": 0}, "content": [{"text": "référence sur l'arbre d'accessibilité, les événements, les overlays", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "vqyjahcsbvga", "dir": "auto", "indent": 0}, "content": [{"text": "Launcher", "type": "text"}]}]}]}, {"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "vinxkejbfcrg", "dir": "auto", "indent": 0}, "content": [{"text": "Google Play — Developer Program Policy", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "jzkaccnriokr", "dir": "auto", "indent": 0}, "content": [{"text": "contrainte de distribution. C'est la seule source qui peut invalider le produit du jour au lendemain", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "pmygtzarkxxz", "dir": "auto", "indent": 0}, "content": [{"text": "Launcher", "type": "text"}]}]}]}, {"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "snbpnxyydcxw", "dir": "auto", "indent": 0}, "content": [{"text": "Android Developers Blog, notes de version AOSP", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "oqhjkkveiogi", "dir": "auto", "indent": 0}, "content": [{"text": "restrictions nouvelles à chaque version majeure", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "podetvufircc", "dir": "auto", "indent": 0}, "content": [{"text": "Launcher", "type": "text"}]}]}]}, {"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "duhgmcavugdn", "dir": "auto", "indent": 0}, "content": [{"text": "Dépôts GitHub : ", "type": "text"}, {"text": "androidx", "type": "text", "marks": [{"type": "code", "attrs": {}}]}, {"text": ", ", "type": "text"}, {"text": "llama.cpp", "type": "text", "marks": [{"type": "code", "attrs": {}}]}, {"text": ", ", "type": "text"}, {"text": "executorch", "type": "text", "marks": [{"type": "code", "attrs": {}}]}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "syiagcltgzja", "dir": "auto", "indent": 0}, "content": [{"text": "évolutions concrètes, releases, discussions d'issues", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "elkhatugmnuy", "dir": "auto", "indent": 0}, "content": [{"text": "Launcher", "type": "text"}]}]}]}, {"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "deqdzmzsnnac", "dir": "auto", "indent": 0}, "content": [{"text": "arXiv (cs.HC, cs.AI) et Hugging Face", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "yczbnbvwyqwd", "dir": "auto", "indent": 0}, "content": [{"text": "état de l'art des agents d'interface et des modèles embarquables", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "jwtlqdtpusyx", "dir": "auto", "indent": 0}, "content": [{"text": "Launcher", "type": "text"}]}]}]}, {"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "shctvssmjghx", "dir": "auto", "indent": 0}, "content": [{"text": "NestJS, Prisma — notes de version", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "uwfigcazfhcr", "dir": "auto", "indent": 0}, "content": [{"text": "évolutions de la stack, ruptures de compatibilité", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "thrxklaetlix", "dir": "auto", "indent": 0}, "content": [{"text": "Backend", "type": "text"}]}]}]}, {"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "jyalrvdsjkrs", "dir": "auto", "indent": 0}, "content": [{"text": "CNIL — actualités et recommandations", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "ladkgjptvbio", "dir": "auto", "indent": 0}, "content": [{"text": "données de santé, AIPD, article 9", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "xokmqdylsxgw", "dir": "auto", "indent": 0}, "content": [{"text": "Backend", "type": "text"}]}]}]}, {"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "fozdsiqlclci", "dir": "auto", "indent": 0}, "content": [{"text": "AI Act — textes et lignes directrices", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "purarbrzapta", "dir": "auto", "indent": 0}, "content": [{"text": "obligations de transparence, article 50", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "rzzsjatydaqf", "dir": "auto", "indent": 0}, "content": [{"text": "Backend", "type": "text"}]}]}]}, {"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "axtykduwbfkc", "dir": "auto", "indent": 0}, "content": [{"text": "RGAA et WCAG — notes de version", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "uelphwtjikno", "dir": "auto", "indent": 0}, "content": [{"text": "référentiel d'accessibilité de la console", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "qqizwuuvpngh", "dir": "auto", "indent": 0}, "content": [{"text": "Dashboard", "type": "text"}]}]}]}, {"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "ldtznxstmilk", "dir": "auto", "indent": 0}, "content": [{"text": "/e/OS, iodéOS, GrapheneOS — journaux de publication", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "wwtmrzrdqalw", "dir": "auto", "indent": 0}, "content": [{"text": "faisabilité d'un déploiement sans services Google", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "wbmxethgwimy", "dir": "auto", "indent": 0}, "content": [{"text": "Dashboard", "type": "text"}]}]}]}]}, {"type": "heading", "attrs": {"id": "iwcughphztqi", "dir": "auto", "level": 2, "indent": 0}, "content": [{"text": "Outils", "type": "text"}]}, {"type": "table", "attrs": {"dir": "auto"}, "content": [{"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableHeader", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "wlbgleknzrov", "dir": "auto", "indent": 0}, "content": [{"text": "Outil", "type": "text"}]}]}, {"type": "tableHeader", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "lcuozvzfgjji", "dir": "auto", "indent": 0}, "content": [{"text": "Rôle", "type": "text"}]}]}, {"type": "tableHeader", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "ljdlglvfqahl", "dir": "auto", "indent": 0}, "content": [{"text": "Montrable en séance", "type": "text"}]}]}]}, {"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "knfxsaurmyul", "dir": "auto", "indent": 0}, "content": [{"text": "Suivi des releases GitHub", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}, {"text": " sur les dépôts listés ci-dessus", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "abiwyopqeklw", "dir": "auto", "indent": 0}, "content": [{"text": "les nouveautés arrivent sans qu'on aille les chercher", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "gwxneqjzrxce", "dir": "auto", "indent": 0}, "content": [{"text": "la liste des dépôts suivis", "type": "text"}]}]}]}, {"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "fohgkjxdyxfn", "dir": "auto", "indent": 0}, "content": [{"text": "Cet espace Docmost", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "qmlblsmadbdx", "dir": "auto", "indent": 0}, "content": [{"text": "journal, notes de lecture, comptes rendus de présentation", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "uwtrgcnbbtpu", "dir": "auto", "indent": 0}, "content": [{"text": "l'espace lui-même", "type": "text"}]}]}]}, {"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "jkrmxgnulxay", "dir": "auto", "indent": 0}, "content": [{"text": "Abonnements RSS", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}, {"text": " aux blogs et flux arXiv", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "boweztrwpflp", "dir": "auto", "indent": 0}, "content": [{"text": "collecte passive", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "vnyvvjzjcexz", "dir": "auto", "indent": 0}, "content": [{"text": "la liste des abonnements", "type": "text"}]}]}]}]}, {"type": "paragraph", "attrs": {"id": "mvslmwjxxgmp", "dir": "auto", "indent": 0}, "content": [{"text": "Le suivi GitHub est le seul mécanisme automatique, et il est volontairement le plus simple possible : rien à héberger, rien à sauvegarder, rien qui tombe en panne.", "type": "text"}]}, {"type": "heading", "attrs": {"id": "zbusvkjskqpu", "dir": "auto", "level": 2, "indent": 0}, "content": [{"text": "Journal de veille", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "yiivmweavimx", "dir": "auto", "indent": 0}, "content": [{"text": "Une ligne par entrée, format fixe :", "type": "text"}]}, {"type": "table", "attrs": {"dir": "auto"}, "content": [{"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableHeader", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "iarzoewynbuy", "dir": "auto", "indent": 0}, "content": [{"text": "Date", "type": "text"}]}]}, {"type": "tableHeader", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "bkrxyefmrcly", "dir": "auto", "indent": 0}, "content": [{"text": "Source", "type": "text"}]}]}, {"type": "tableHeader", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "kpmoanppisxc", "dir": "auto", "indent": 0}, "content": [{"text": "Ce qu'on a trouvé", "type": "text"}]}]}, {"type": "tableHeader", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "ckguhtofjvus", "dir": "auto", "indent": 0}, "content": [{"text": "Ce que ça change pour KansOS", "type": "text"}]}]}, {"type": "tableHeader", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "fnronccgdcxv", "dir": "auto", "indent": 0}, "content": [{"text": "Suite donnée", "type": "text"}]}]}]}]}, {"type": "paragraph", "attrs": {"id": "cyhigpmgsnqc", "dir": "auto", "indent": 0}, "content": [{"text": "Une entrée sans conclusion ne compte pas.", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}, {"text": " La colonne « suite donnée » contient soit une action, soit la raison explicite de l'inaction.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "tbgzhzidjeav", "dir": "auto", "indent": 0}, "content": [{"text": "Objectif : ", "type": "text"}, {"text": "20 entrées minimum sur l'année", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}, {"text": ", étalées d'octobre à mai.", "type": "text"}]}, {"type": "heading", "attrs": {"id": "lsdmqnyrckqm", "dir": "auto", "level": 3, "indent": 0}, "content": [{"text": "Entrées déjà consignées", "type": "text"}]}, {"type": "table", "attrs": {"dir": "auto"}, "content": [{"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableHeader", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "iphgqzlyaydq", "dir": "auto", "indent": 0}, "content": [{"text": "Date", "type": "text"}]}]}, {"type": "tableHeader", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "bjgeemgtduhk", "dir": "auto", "indent": 0}, "content": [{"text": "Source", "type": "text"}]}]}, {"type": "tableHeader", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "cpyrxmhvkidc", "dir": "auto", "indent": 0}, "content": [{"text": "Ce qu'on a trouvé", "type": "text"}]}]}, {"type": "tableHeader", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "qrrbcasdugnd", "dir": "auto", "indent": 0}, "content": [{"text": "Ce que ça change", "type": "text"}]}]}, {"type": "tableHeader", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "mrpnuwayzgzx", "dir": "auto", "indent": 0}, "content": [{"text": "Suite donnée", "type": "text"}]}]}]}, {"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "pnfyeikvrypq", "dir": "auto", "indent": 0}, "content": [{"text": "[date]", "type": "text", "marks": [{"type": "code", "attrs": {}}]}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "eqixfajscfhl", "dir": "auto", "indent": 0}, "content": [{"text": "Google Play Developer Program Policy", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "xogjukaekvlz", "dir": "auto", "indent": 0}, "content": [{"text": "durcissement du 30/10/2025 sur les services d'accessibilité ; les launchers ne sont pas éligibles au drapeau ", "type": "text"}, {"text": "isAccessibilityTool", "type": "text", "marks": [{"type": "code", "attrs": {}}]}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "bwpeaucddkfc", "dir": "auto", "indent": 0}, "content": [{"text": "confirme que le guidage passif est la seule voie distribuable", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "xewzmpgmcpuu", "dir": "auto", "indent": 0}, "content": [{"text": "intégré à la note de caractérisation ; POC de vérification de la déclaration Play ajouté", "type": "text"}]}]}]}, {"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "mxgslvsdamya", "dir": "auto", "indent": 0}, "content": [{"text": "[date]", "type": "text", "marks": [{"type": "code", "attrs": {}}]}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "wynaibibnodl", "dir": "auto", "indent": 0}, "content": [{"text": "Documentation Jetpack Compose", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "wqnsqolgdbkh", "dir": "auto", "indent": 0}, "content": [{"text": "pas d'identifiant de vue stable sauf si l'application active ", "type": "text"}, {"text": "testTagsAsResourceId", "type": "text", "marks": [{"type": "code", "attrs": {}}]}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "wbukqbxnuztc", "dir": "auto", "indent": 0}, "content": [{"text": "identifie la cause racine du point dur", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "qbzulocwkzfi", "dir": "auto", "indent": 0}, "content": [{"text": "fonde le protocole de mesure de couverture", "type": "text"}]}]}]}, {"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "umsvfrruyxpt", "dir": "auto", "indent": 0}, "content": [{"text": "[date]", "type": "text", "marks": [{"type": "code", "attrs": {}}]}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "bfrwmqahqrmb", "dir": "auto", "indent": 0}, "content": [{"text": "arXiv:2509.26539 (Apple)", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "qkyqfofqpils", "dir": "auto", "indent": 0}, "content": [{"text": "Ferret-UI Lite, 3 B, 28,0 % de réussite sur AndroidWorld", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "ojgkplgyvpsz", "dir": "auto", "indent": 0}, "content": [{"text": "un petit modèle embarquable est très loin d'être fiable seul", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "lhnnikqtesox", "dir": "auto", "indent": 0}, "content": [{"text": "écarte le modèle comme voie principale ; conservé comme recours", "type": "text"}]}]}]}, {"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "kwccqnrydize", "dir": "auto", "indent": 0}, "content": [{"text": "[date]", "type": "text", "marks": [{"type": "code", "attrs": {}}]}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "ddnsinvbcxba", "dir": "auto", "indent": 0}, "content": [{"text": "Scores AndroidWorld agrégés", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "uyiwyxhmdrms", "dir": "auto", "indent": 0}, "content": [{"text": "Holo3.1-4B annoncé à 71,0 %, Holo3.1-35B à 79,3 % — chiffres ", "type": "text"}, {"text": "auto-déclarés", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}, {"text": " par l'éditeur", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "wenouneprugy", "dir": "auto", "indent": 0}, "content": [{"text": "même au mieux, une action sur cinq est fausse : inacceptable sur une démarche bancaire", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "xferkvfgrqcq", "dir": "auto", "indent": 0}, "content": [{"text": "argument retenu dans la note ; à revérifier si un harnais indépendant publie des résultats", "type": "text"}]}]}]}, {"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "cfitjkbhyvtv", "dir": "auto", "indent": 0}, "content": [{"text": "[date]", "type": "text", "marks": [{"type": "code", "attrs": {}}]}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "bhghamfgjyqd", "dir": "auto", "indent": 0}, "content": [{"text": "ML Kit GenAI", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "ztxypwgxxyyf", "dir": "auto", "indent": 0}, "content": [{"text": "BACKGROUND_USE_BLOCKED", "type": "text", "marks": [{"type": "code", "attrs": {}}]}, {"text": " renvoyé depuis un service d'accessibilité", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "ynzxncakgysm", "dir": "auto", "indent": 0}, "content": [{"text": "Gemini Nano est inutilisable pour notre cas", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "pdfcpahpeptp", "dir": "auto", "indent": 0}, "content": [{"text": "piste abandonnée, raison consignée", "type": "text"}]}]}]}]}, {"type": "blockquote", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "hryzdzjfjdvk", "dir": "auto", "indent": 0}, "content": [{"text": "À faire avant envoi", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}, {"text": " : dater ces cinq entrées, et en ajouter celles de la semaine en cours.", "type": "text"}]}]}, {"type": "heading", "attrs": {"id": "odrwlfzwbdol", "dir": "auto", "level": 2, "indent": 0}, "content": [{"text": "Partage interne", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "ppajhhcyngcc", "dir": "auto", "indent": 0}, "content": [{"text": "À partir de novembre", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}, {"text": " : un créneau dédié dans le point de synchro hebdomadaire, une personne présente à tour de rôle ce qu'elle a trouvé.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "conrgyzspmue", "dir": "auto", "indent": 0}, "content": [{"text": "Chaque présentation est consignée dans cet espace : qui, quoi, à qui, ce qui en a été retenu.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "xjqzqkazbabp", "dir": "auto", "indent": 0}, "content": [{"text": "Objectif : ", "type": "text"}, {"text": "6 présentations minimum sur l'année", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}, {"text": ".", "type": "text"}]}, {"type": "heading", "attrs": {"id": "azdkbjvkwkvt", "dir": "auto", "level": 2, "indent": 0}, "content": [{"text": "Exploitation", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "gwvfmchttzih", "dir": "auto", "indent": 0}, "content": [{"text": "Sur l'année, ", "type": "text"}, {"text": "au moins 3 apports de la veille réellement intégrés au projet", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}, {"text": ", avec pour chacun la source d'origine et ce qu'il a changé.", "type": "text"}]}, {"type": "heading", "attrs": {"id": "jmuoxqbqkrjf", "dir": "auto", "level": 2, "indent": 0}, "content": [{"text": "Communautés techniques", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "ologfhitdryg", "dir": "auto", "indent": 0}, "content": [{"text": "Le guide inscrit ce bloc dans l'objectif obligatoire 1, pas dans l'objectif B.", "type": "text"}]}, {"type": "bulletList", "attrs": {"dir": "auto"}, "content": [{"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "rsstmssxnitw", "dir": "auto", "indent": 0}, "content": [{"text": "2 communautés", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}, {"text": " : un espace de développeurs Android orienté accessibilité, et la communauté d'un des runtimes d'inférence suivis.", "type": "text"}]}]}, {"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "cofsxrrwrryq", "dir": "auto", "indent": 0}, "content": [{"text": "5 contributions publiques", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}, {"text": " sur l'année : une question posée avec son contexte, une réponse donnée, un rapport de bug documenté, un retour d'expérience.", "type": "text"}]}]}, {"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "dbtjiskukedl", "dir": "auto", "indent": 0}, "content": [{"text": "1 contribution externe minimum", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}, {"text": ", même modeste — un correctif de documentation est recevable.", "type": "text"}]}]}, {"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "psaynmuyiing", "dir": "auto", "indent": 0}, "content": [{"text": "Pour chacune : le lien, la date, le contexte, ce qui en est sorti.", "type": "text"}]}]}]}, {"type": "paragraph", "attrs": {"id": "hmkjcgslwqas", "dir": "auto", "indent": 0}, "content": [{"text": "Démarrage en novembre.", "type": "text"}]}]}	\N	\N	\N	\N	01a12cf1-0bd0-70e9-87f3-436c4e3a4023	01a12d29-3a97-7210-ac78-1927a95f2edd	01a12cf1-0bd3-7a42-96f8-8cedaf38cf22	2026-10-11 23:15:01.949473+00	2026-10-11 23:15:01.949473+00	{01a12cf1-0bd0-70e9-87f3-436c4e3a4023}
\.


--
-- Data for Name: page_labels; Type: TABLE DATA; Schema: public; Owner: docmost
--

COPY public.page_labels (id, page_id, label_id, created_at) FROM stdin;
\.


--
-- Data for Name: page_permissions; Type: TABLE DATA; Schema: public; Owner: docmost
--

COPY public.page_permissions (id, page_access_id, user_id, group_id, role, added_by_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: page_transclusion_references; Type: TABLE DATA; Schema: public; Owner: docmost
--

COPY public.page_transclusion_references (id, workspace_id, reference_page_id, source_page_id, transclusion_id, created_at) FROM stdin;
\.


--
-- Data for Name: page_transclusions; Type: TABLE DATA; Schema: public; Owner: docmost
--

COPY public.page_transclusions (id, workspace_id, page_id, transclusion_id, content, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: page_verifications; Type: TABLE DATA; Schema: public; Owner: docmost
--

COPY public.page_verifications (id, page_id, workspace_id, space_id, type, status, mode, period_amount, period_unit, verified_at, verified_by_id, expires_at, requested_at, requested_by_id, rejected_at, rejected_by_id, rejection_comment, data, creator_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: page_verifiers; Type: TABLE DATA; Schema: public; Owner: docmost
--

COPY public.page_verifiers (id, page_verification_id, user_id, is_primary, added_by_id, created_at) FROM stdin;
\.


--
-- Data for Name: pages; Type: TABLE DATA; Schema: public; Owner: docmost
--

COPY public.pages (id, slug_id, title, icon, cover_photo, "position", content, ydoc, text_content, tsv, parent_page_id, creator_id, last_updated_by_id, deleted_by_id, space_id, workspace_id, is_locked, created_at, updated_at, deleted_at, contributor_ids, is_base, base_schema_version) FROM stdin;
01a12d3e-a064-7971-b3f5-23da8d8c0bab	dzjNVW00tj	Dispositif de veille technologique	\N	\N	a0A71	{"type": "doc", "content": [{"type": "paragraph", "attrs": {"id": "nxrraciegswd", "dir": "auto", "indent": 0}, "content": [{"text": "Projet ", "type": "text"}, {"text": "KansOS", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}, {"text": " · Technical Track Tech 4 · Objectif obligatoire 1", "type": "text"}, {"type": "hardBreak", "attrs": {"dir": "auto"}}, {"text": "14 octobre 2026", "type": "text"}]}, {"type": "horizontalRule", "attrs": {"dir": "auto"}}, {"type": "heading", "attrs": {"id": "gtfvycahneut", "dir": "auto", "level": 2, "indent": 0}, "content": [{"text": "À quoi elle sert", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "fzjdynvecgwy", "dir": "auto", "indent": 0}, "content": [{"text": "La veille sert à lever notre point dur : savoir quelle proportion des écrans d'une application tierce est assez décrite pour permettre un guidage fiable, et comment faire là où elle ne l'est pas.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "tqetvkbakmob", "dir": "auto", "indent": 0}, "content": [{"text": "Ce n'est pas un exercice documentaire. Chaque entrée du journal doit dire ce qu'elle change pour le projet, ou pourquoi elle ne change rien.", "type": "text"}]}, {"type": "heading", "attrs": {"id": "snhawyywbvex", "dir": "auto", "level": 2, "indent": 0}, "content": [{"text": "Rythme", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "holrwcxcqstj", "dir": "auto", "indent": 0}, "content": [{"text": "1 heure par personne et par semaine", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}, {"text": ", placée librement — l'équipe est répartie sur quatre pays et n'a pas les mêmes emplois du temps.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "epghhgdavwso", "dir": "auto", "indent": 0}, "content": [{"text": "Restitution au point de synchro hebdomadaire", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}, {"text": " du week-end, où chacun dit en deux minutes ce qu'il a trouvé.", "type": "text"}]}, {"type": "heading", "attrs": {"id": "zoapsfdxcqvd", "dir": "auto", "level": 2, "indent": 0}, "content": [{"text": "Répartition", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "jmipqyguoufe", "dir": "auto", "indent": 0}, "content": [{"text": "Alignée sur les trois composants. Chaque binôme suit aussi le sujet transverse qui relève de son composant, pour qu'aucun domaine ne reste sans responsable.", "type": "text"}]}, {"type": "table", "attrs": {"dir": "auto"}, "content": [{"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableHeader", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "jvugstlxkzhc", "dir": "auto", "indent": 0}, "content": [{"text": "Composant", "type": "text"}]}]}, {"type": "tableHeader", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "srncybybvfza", "dir": "auto", "indent": 0}, "content": [{"text": "Qui", "type": "text"}]}]}, {"type": "tableHeader", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "nkfimvoovgqr", "dir": "auto", "indent": 0}, "content": [{"text": "Domaines suivis", "type": "text"}]}]}]}, {"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "jxdfylookdaf", "dir": "auto", "indent": 0}, "content": [{"text": "Launcher", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "wygytfchhsak", "dir": "auto", "indent": 0}, "content": [{"text": "Elias + ", "type": "text"}, {"text": "[ ]", "type": "text", "marks": [{"type": "code", "attrs": {}}]}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "hnwaevpeajpx", "dir": "auto", "indent": 0}, "content": [{"text": "arbre d'accessibilité Android, API launcher, politique Google Play, modèles exécutables sur appareil", "type": "text"}]}]}]}, {"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "wmpyjjcqjeyo", "dir": "auto", "indent": 0}, "content": [{"text": "Backend", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "pzxzwfeyhfdt", "dir": "auto", "indent": 0}, "content": [{"text": "[ ]", "type": "text", "marks": [{"type": "code", "attrs": {}}]}, {"text": " + ", "type": "text"}, {"text": "[ ]", "type": "text", "marks": [{"type": "code", "attrs": {}}]}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "spwcfuxdbntt", "dir": "auto", "indent": 0}, "content": [{"text": "NestJS et Prisma, performance et observabilité, sécurité, chiffrement, RGPD et AI Act", "type": "text"}]}]}]}, {"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "lsyrwxhimsfh", "dir": "auto", "indent": 0}, "content": [{"text": "Dashboard", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "njfvjftqjjzo", "dir": "auto", "indent": 0}, "content": [{"text": "[ ]", "type": "text", "marks": [{"type": "code", "attrs": {}}]}, {"text": " + ", "type": "text"}, {"text": "[ ]", "type": "text", "marks": [{"type": "code", "attrs": {}}]}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "tzstweplrsza", "dir": "auto", "indent": 0}, "content": [{"text": "accessibilité web (RGAA, WCAG), FALC, ergonomie cognitive, déploiement et ROM dégooglisées", "type": "text"}]}]}]}]}, {"type": "paragraph", "attrs": {"id": "tepnksazkfmn", "dir": "auto", "indent": 0}, "content": [{"text": "Une veille portée par une seule personne ne se diffuse pas : c'est pour ça qu'il y a deux personnes par composant, et que la restitution est hebdomadaire.", "type": "text"}]}, {"type": "heading", "attrs": {"id": "dujnfqpvdgts", "dir": "auto", "level": 2, "indent": 0}, "content": [{"text": "Sources suivies", "type": "text"}]}, {"type": "table", "attrs": {"dir": "auto"}, "content": [{"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableHeader", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "dqxdnipcfdtq", "dir": "auto", "indent": 0}, "content": [{"text": "Source", "type": "text"}]}]}, {"type": "tableHeader", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "fvbtrydhbbte", "dir": "auto", "indent": 0}, "content": [{"text": "Ce qu'elle apporte", "type": "text"}]}]}, {"type": "tableHeader", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "vfwiqmflgtpx", "dir": "auto", "indent": 0}, "content": [{"text": "Binôme", "type": "text"}]}]}]}, {"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "sjyvfbuxiyqp", "dir": "auto", "indent": 0}, "content": [{"text": "Documentation Android — Accessibility", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "kttdzzwxzhsf", "dir": "auto", "indent": 0}, "content": [{"text": "référence sur l'arbre d'accessibilité, les événements, les overlays", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "vqyjahcsbvga", "dir": "auto", "indent": 0}, "content": [{"text": "Launcher", "type": "text"}]}]}]}, {"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "vinxkejbfcrg", "dir": "auto", "indent": 0}, "content": [{"text": "Google Play — Developer Program Policy", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "jzkaccnriokr", "dir": "auto", "indent": 0}, "content": [{"text": "contrainte de distribution. C'est la seule source qui peut invalider le produit du jour au lendemain", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "pmygtzarkxxz", "dir": "auto", "indent": 0}, "content": [{"text": "Launcher", "type": "text"}]}]}]}, {"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "snbpnxyydcxw", "dir": "auto", "indent": 0}, "content": [{"text": "Android Developers Blog, notes de version AOSP", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "oqhjkkveiogi", "dir": "auto", "indent": 0}, "content": [{"text": "restrictions nouvelles à chaque version majeure", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "podetvufircc", "dir": "auto", "indent": 0}, "content": [{"text": "Launcher", "type": "text"}]}]}]}, {"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "duhgmcavugdn", "dir": "auto", "indent": 0}, "content": [{"text": "Dépôts GitHub : ", "type": "text"}, {"text": "androidx", "type": "text", "marks": [{"type": "code", "attrs": {}}]}, {"text": ", ", "type": "text"}, {"text": "llama.cpp", "type": "text", "marks": [{"type": "code", "attrs": {}}]}, {"text": ", ", "type": "text"}, {"text": "executorch", "type": "text", "marks": [{"type": "code", "attrs": {}}]}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "syiagcltgzja", "dir": "auto", "indent": 0}, "content": [{"text": "évolutions concrètes, releases, discussions d'issues", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "elkhatugmnuy", "dir": "auto", "indent": 0}, "content": [{"text": "Launcher", "type": "text"}]}]}]}, {"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "deqdzmzsnnac", "dir": "auto", "indent": 0}, "content": [{"text": "arXiv (cs.HC, cs.AI) et Hugging Face", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "yczbnbvwyqwd", "dir": "auto", "indent": 0}, "content": [{"text": "état de l'art des agents d'interface et des modèles embarquables", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "jwtlqdtpusyx", "dir": "auto", "indent": 0}, "content": [{"text": "Launcher", "type": "text"}]}]}]}, {"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "shctvssmjghx", "dir": "auto", "indent": 0}, "content": [{"text": "NestJS, Prisma — notes de version", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "uwfigcazfhcr", "dir": "auto", "indent": 0}, "content": [{"text": "évolutions de la stack, ruptures de compatibilité", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "thrxklaetlix", "dir": "auto", "indent": 0}, "content": [{"text": "Backend", "type": "text"}]}]}]}, {"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "jyalrvdsjkrs", "dir": "auto", "indent": 0}, "content": [{"text": "CNIL — actualités et recommandations", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "ladkgjptvbio", "dir": "auto", "indent": 0}, "content": [{"text": "données de santé, AIPD, article 9", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "xokmqdylsxgw", "dir": "auto", "indent": 0}, "content": [{"text": "Backend", "type": "text"}]}]}]}, {"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "fozdsiqlclci", "dir": "auto", "indent": 0}, "content": [{"text": "AI Act — textes et lignes directrices", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "purarbrzapta", "dir": "auto", "indent": 0}, "content": [{"text": "obligations de transparence, article 50", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "rzzsjatydaqf", "dir": "auto", "indent": 0}, "content": [{"text": "Backend", "type": "text"}]}]}]}, {"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "axtykduwbfkc", "dir": "auto", "indent": 0}, "content": [{"text": "RGAA et WCAG — notes de version", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "uelphwtjikno", "dir": "auto", "indent": 0}, "content": [{"text": "référentiel d'accessibilité de la console", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "qqizwuuvpngh", "dir": "auto", "indent": 0}, "content": [{"text": "Dashboard", "type": "text"}]}]}]}, {"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "ldtznxstmilk", "dir": "auto", "indent": 0}, "content": [{"text": "/e/OS, iodéOS, GrapheneOS — journaux de publication", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "wwtmrzrdqalw", "dir": "auto", "indent": 0}, "content": [{"text": "faisabilité d'un déploiement sans services Google", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "wbmxethgwimy", "dir": "auto", "indent": 0}, "content": [{"text": "Dashboard", "type": "text"}]}]}]}]}, {"type": "heading", "attrs": {"id": "iwcughphztqi", "dir": "auto", "level": 2, "indent": 0}, "content": [{"text": "Outils", "type": "text"}]}, {"type": "table", "attrs": {"dir": "auto"}, "content": [{"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableHeader", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "wlbgleknzrov", "dir": "auto", "indent": 0}, "content": [{"text": "Outil", "type": "text"}]}]}, {"type": "tableHeader", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "lcuozvzfgjji", "dir": "auto", "indent": 0}, "content": [{"text": "Rôle", "type": "text"}]}]}, {"type": "tableHeader", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "ljdlglvfqahl", "dir": "auto", "indent": 0}, "content": [{"text": "Montrable en séance", "type": "text"}]}]}]}, {"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "knfxsaurmyul", "dir": "auto", "indent": 0}, "content": [{"text": "Suivi des releases GitHub", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}, {"text": " sur les dépôts listés ci-dessus", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "abiwyopqeklw", "dir": "auto", "indent": 0}, "content": [{"text": "les nouveautés arrivent sans qu'on aille les chercher", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "gwxneqjzrxce", "dir": "auto", "indent": 0}, "content": [{"text": "la liste des dépôts suivis", "type": "text"}]}]}]}, {"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "fohgkjxdyxfn", "dir": "auto", "indent": 0}, "content": [{"text": "Cet espace Docmost", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "qmlblsmadbdx", "dir": "auto", "indent": 0}, "content": [{"text": "journal, notes de lecture, comptes rendus de présentation", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "uwtrgcnbbtpu", "dir": "auto", "indent": 0}, "content": [{"text": "l'espace lui-même", "type": "text"}]}]}]}, {"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "jkrmxgnulxay", "dir": "auto", "indent": 0}, "content": [{"text": "Abonnements RSS", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}, {"text": " aux blogs et flux arXiv", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "boweztrwpflp", "dir": "auto", "indent": 0}, "content": [{"text": "collecte passive", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "vnyvvjzjcexz", "dir": "auto", "indent": 0}, "content": [{"text": "la liste des abonnements", "type": "text"}]}]}]}]}, {"type": "paragraph", "attrs": {"id": "mvslmwjxxgmp", "dir": "auto", "indent": 0}, "content": [{"text": "Le suivi GitHub est le seul mécanisme automatique, et il est volontairement le plus simple possible : rien à héberger, rien à sauvegarder, rien qui tombe en panne.", "type": "text"}]}, {"type": "heading", "attrs": {"id": "zbusvkjskqpu", "dir": "auto", "level": 2, "indent": 0}, "content": [{"text": "Journal de veille", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "yiivmweavimx", "dir": "auto", "indent": 0}, "content": [{"text": "Une ligne par entrée, format fixe :", "type": "text"}]}, {"type": "table", "attrs": {"dir": "auto"}, "content": [{"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableHeader", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "iarzoewynbuy", "dir": "auto", "indent": 0}, "content": [{"text": "Date", "type": "text"}]}]}, {"type": "tableHeader", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "bkrxyefmrcly", "dir": "auto", "indent": 0}, "content": [{"text": "Source", "type": "text"}]}]}, {"type": "tableHeader", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "kpmoanppisxc", "dir": "auto", "indent": 0}, "content": [{"text": "Ce qu'on a trouvé", "type": "text"}]}]}, {"type": "tableHeader", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "ckguhtofjvus", "dir": "auto", "indent": 0}, "content": [{"text": "Ce que ça change pour KansOS", "type": "text"}]}]}, {"type": "tableHeader", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "fnronccgdcxv", "dir": "auto", "indent": 0}, "content": [{"text": "Suite donnée", "type": "text"}]}]}]}]}, {"type": "paragraph", "attrs": {"id": "cyhigpmgsnqc", "dir": "auto", "indent": 0}, "content": [{"text": "Une entrée sans conclusion ne compte pas.", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}, {"text": " La colonne « suite donnée » contient soit une action, soit la raison explicite de l'inaction.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "tbgzhzidjeav", "dir": "auto", "indent": 0}, "content": [{"text": "Objectif : ", "type": "text"}, {"text": "20 entrées minimum sur l'année", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}, {"text": ", étalées d'octobre à mai.", "type": "text"}]}, {"type": "heading", "attrs": {"id": "lsdmqnyrckqm", "dir": "auto", "level": 3, "indent": 0}, "content": [{"text": "Entrées déjà consignées", "type": "text"}]}, {"type": "table", "attrs": {"dir": "auto"}, "content": [{"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableHeader", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "iphgqzlyaydq", "dir": "auto", "indent": 0}, "content": [{"text": "Date", "type": "text"}]}]}, {"type": "tableHeader", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "bjgeemgtduhk", "dir": "auto", "indent": 0}, "content": [{"text": "Source", "type": "text"}]}]}, {"type": "tableHeader", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "cpyrxmhvkidc", "dir": "auto", "indent": 0}, "content": [{"text": "Ce qu'on a trouvé", "type": "text"}]}]}, {"type": "tableHeader", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "qrrbcasdugnd", "dir": "auto", "indent": 0}, "content": [{"text": "Ce que ça change", "type": "text"}]}]}, {"type": "tableHeader", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "mrpnuwayzgzx", "dir": "auto", "indent": 0}, "content": [{"text": "Suite donnée", "type": "text"}]}]}]}, {"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "pnfyeikvrypq", "dir": "auto", "indent": 0}, "content": [{"text": "[date]", "type": "text", "marks": [{"type": "code", "attrs": {}}]}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "eqixfajscfhl", "dir": "auto", "indent": 0}, "content": [{"text": "Google Play Developer Program Policy", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "xogjukaekvlz", "dir": "auto", "indent": 0}, "content": [{"text": "durcissement du 30/10/2025 sur les services d'accessibilité ; les launchers ne sont pas éligibles au drapeau ", "type": "text"}, {"text": "isAccessibilityTool", "type": "text", "marks": [{"type": "code", "attrs": {}}]}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "bwpeaucddkfc", "dir": "auto", "indent": 0}, "content": [{"text": "confirme que le guidage passif est la seule voie distribuable", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "xewzmpgmcpuu", "dir": "auto", "indent": 0}, "content": [{"text": "intégré à la note de caractérisation ; POC de vérification de la déclaration Play ajouté", "type": "text"}]}]}]}, {"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "mxgslvsdamya", "dir": "auto", "indent": 0}, "content": [{"text": "[date]", "type": "text", "marks": [{"type": "code", "attrs": {}}]}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "wynaibibnodl", "dir": "auto", "indent": 0}, "content": [{"text": "Documentation Jetpack Compose", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "wqnsqolgdbkh", "dir": "auto", "indent": 0}, "content": [{"text": "pas d'identifiant de vue stable sauf si l'application active ", "type": "text"}, {"text": "testTagsAsResourceId", "type": "text", "marks": [{"type": "code", "attrs": {}}]}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "wbukqbxnuztc", "dir": "auto", "indent": 0}, "content": [{"text": "identifie la cause racine du point dur", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "qbzulocwkzfi", "dir": "auto", "indent": 0}, "content": [{"text": "fonde le protocole de mesure de couverture", "type": "text"}]}]}]}, {"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "umsvfrruyxpt", "dir": "auto", "indent": 0}, "content": [{"text": "[date]", "type": "text", "marks": [{"type": "code", "attrs": {}}]}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "bfrwmqahqrmb", "dir": "auto", "indent": 0}, "content": [{"text": "arXiv:2509.26539 (Apple)", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "qkyqfofqpils", "dir": "auto", "indent": 0}, "content": [{"text": "Ferret-UI Lite, 3 B, 28,0 % de réussite sur AndroidWorld", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "ojgkplgyvpsz", "dir": "auto", "indent": 0}, "content": [{"text": "un petit modèle embarquable est très loin d'être fiable seul", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "lhnnikqtesox", "dir": "auto", "indent": 0}, "content": [{"text": "écarte le modèle comme voie principale ; conservé comme recours", "type": "text"}]}]}]}, {"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "kwccqnrydize", "dir": "auto", "indent": 0}, "content": [{"text": "[date]", "type": "text", "marks": [{"type": "code", "attrs": {}}]}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "ddnsinvbcxba", "dir": "auto", "indent": 0}, "content": [{"text": "Scores AndroidWorld agrégés", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "uyiwyxhmdrms", "dir": "auto", "indent": 0}, "content": [{"text": "Holo3.1-4B annoncé à 71,0 %, Holo3.1-35B à 79,3 % — chiffres ", "type": "text"}, {"text": "auto-déclarés", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}, {"text": " par l'éditeur", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "wenouneprugy", "dir": "auto", "indent": 0}, "content": [{"text": "même au mieux, une action sur cinq est fausse : inacceptable sur une démarche bancaire", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "xferkvfgrqcq", "dir": "auto", "indent": 0}, "content": [{"text": "argument retenu dans la note ; à revérifier si un harnais indépendant publie des résultats", "type": "text"}]}]}]}, {"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "cfitjkbhyvtv", "dir": "auto", "indent": 0}, "content": [{"text": "[date]", "type": "text", "marks": [{"type": "code", "attrs": {}}]}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "bhghamfgjyqd", "dir": "auto", "indent": 0}, "content": [{"text": "ML Kit GenAI", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "ztxypwgxxyyf", "dir": "auto", "indent": 0}, "content": [{"text": "BACKGROUND_USE_BLOCKED", "type": "text", "marks": [{"type": "code", "attrs": {}}]}, {"text": " renvoyé depuis un service d'accessibilité", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "ynzxncakgysm", "dir": "auto", "indent": 0}, "content": [{"text": "Gemini Nano est inutilisable pour notre cas", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "pdfcpahpeptp", "dir": "auto", "indent": 0}, "content": [{"text": "piste abandonnée, raison consignée", "type": "text"}]}]}]}]}, {"type": "blockquote", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "hryzdzjfjdvk", "dir": "auto", "indent": 0}, "content": [{"text": "À faire avant envoi", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}, {"text": " : dater ces cinq entrées, et en ajouter celles de la semaine en cours.", "type": "text"}]}]}, {"type": "heading", "attrs": {"id": "odrwlfzwbdol", "dir": "auto", "level": 2, "indent": 0}, "content": [{"text": "Partage interne", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "ppajhhcyngcc", "dir": "auto", "indent": 0}, "content": [{"text": "À partir de novembre", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}, {"text": " : un créneau dédié dans le point de synchro hebdomadaire, une personne présente à tour de rôle ce qu'elle a trouvé.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "conrgyzspmue", "dir": "auto", "indent": 0}, "content": [{"text": "Chaque présentation est consignée dans cet espace : qui, quoi, à qui, ce qui en a été retenu.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "xjqzqkazbabp", "dir": "auto", "indent": 0}, "content": [{"text": "Objectif : ", "type": "text"}, {"text": "6 présentations minimum sur l'année", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}, {"text": ".", "type": "text"}]}, {"type": "heading", "attrs": {"id": "azdkbjvkwkvt", "dir": "auto", "level": 2, "indent": 0}, "content": [{"text": "Exploitation", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "gwvfmchttzih", "dir": "auto", "indent": 0}, "content": [{"text": "Sur l'année, ", "type": "text"}, {"text": "au moins 3 apports de la veille réellement intégrés au projet", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}, {"text": ", avec pour chacun la source d'origine et ce qu'il a changé.", "type": "text"}]}, {"type": "heading", "attrs": {"id": "jmuoxqbqkrjf", "dir": "auto", "level": 2, "indent": 0}, "content": [{"text": "Communautés techniques", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "ologfhitdryg", "dir": "auto", "indent": 0}, "content": [{"text": "Le guide inscrit ce bloc dans l'objectif obligatoire 1, pas dans l'objectif B.", "type": "text"}]}, {"type": "bulletList", "attrs": {"dir": "auto"}, "content": [{"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "rsstmssxnitw", "dir": "auto", "indent": 0}, "content": [{"text": "2 communautés", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}, {"text": " : un espace de développeurs Android orienté accessibilité, et la communauté d'un des runtimes d'inférence suivis.", "type": "text"}]}]}, {"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "cofsxrrwrryq", "dir": "auto", "indent": 0}, "content": [{"text": "5 contributions publiques", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}, {"text": " sur l'année : une question posée avec son contexte, une réponse donnée, un rapport de bug documenté, un retour d'expérience.", "type": "text"}]}]}, {"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "dbtjiskukedl", "dir": "auto", "indent": 0}, "content": [{"text": "1 contribution externe minimum", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}, {"text": ", même modeste — un correctif de documentation est recevable.", "type": "text"}]}]}, {"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "psaynmuyiing", "dir": "auto", "indent": 0}, "content": [{"text": "Pour chacune : le lien, la date, le contexte, ce qui en est sorti.", "type": "text"}]}]}]}, {"type": "paragraph", "attrs": {"id": "hmkjcgslwqas", "dir": "auto", "indent": 0}, "content": [{"text": "Démarrage en novembre.", "type": "text"}]}]}	\\x01990a94bafdc5050007010764656661756c740309706172616772617068070094bafdc5050006040094bafdc505010750726f6a6574208694bafdc5050804626f6c64027b7d8494bafdc50509064b616e734f538694bafdc5050f04626f6c64046e756c6c8494bafdc505103420c2b720546563686e6963616c20547261636b2054656368203420c2b7204f626a6563746966206f626c696761746f69726520318794bafdc50501030968617264427265616b280094bafdc50543036469720177046175746f8794bafdc5054306040094bafdc505450f3134206f63746f6272652032303236280094bafdc5050002696401770c6e7872726163696567737764280094bafdc5050006696e64656e74017d00280094bafdc50500036469720177046175746f8794bafdc50500030e686f72697a6f6e74616c52756c65280094bafdc50558036469720177046175746f8794bafdc50558030768656164696e67070094bafdc5055a06040094bafdc5055b11c3802071756f6920656c6c652073657274280094bafdc5055a02696401770c67746676796361686e657574280094bafdc5055a06696e64656e74017d00280094bafdc5055a036469720177046175746f280094bafdc5055a056c6576656c017d028794bafdc5055a0309706172616772617068070094bafdc5057006040094bafdc50571c8014c61207665696c6c65207365727420c3a0206c65766572206e6f74726520706f696e7420647572203a207361766f6972207175656c6c652070726f706f7274696f6e2064657320c3a96372616e73206427756e65206170706c69636174696f6e207469657263652065737420617373657a2064c3a9637269746520706f7572207065726d657474726520756e206775696461676520666961626c652c20657420636f6d6d656e74206661697265206cc3a0206fc3b920656c6c65206e65206c27657374207061732e280094bafdc5057002696401770c667a6a64796e766563677779280094bafdc5057006696e64656e74017d00280094bafdc50570036469720177046175746f8794bafdc505700309706172616772617068070094bafdc505b80206040094bafdc505b9028d014365206e276573742070617320756e20657865726369636520646f63756d656e74616972652e2043686171756520656e7472c3a965206475206a6f75726e616c20646f6974206469726520636520717527656c6c65206368616e676520706f7572206c652070726f6a65742c206f7520706f757271756f6920656c6c65206e65206368616e6765207269656e2e280094bafdc505b80202696401770c74716574766b62616b6d6f62280094bafdc505b80206696e64656e74017d00280094bafdc505b802036469720177046175746f8794bafdc505b802030768656164696e67070094bafdc505c90306040094bafdc505ca0306527974686d65280094bafdc505c90302696401770c736e68617779797762766578280094bafdc505c90306696e64656e74017d00280094bafdc505c903036469720177046175746f280094bafdc505c903056c6576656c017d028794bafdc505c9030309706172616772617068070094bafdc505d50306060094bafdc505d60304626f6c64027b7d8494bafdc505d70323312068657572652070617220706572736f6e6e65206574207061722073656d61696e658694bafdc505fa0304626f6c64046e756c6c8494bafdc505fb03672c20706c6163c3a965206c696272656d656e7420e28094206c27c3a97175697065206573742072c3a970617274696520737572207175617472652070617973206574206e276120706173206c6573206dc3aa6d657320656d706c6f69732064752074656d70732e280094bafdc505d50302696401770c686f6c72776378637173746a280094bafdc505d50306696e64656e74017d00280094bafdc505d503036469720177046175746f8794bafdc505d5030309706172616772617068070094bafdc505e00406060094bafdc505e10404626f6c64027b7d8494bafdc505e2042c5265737469747574696f6e20617520706f696e742064652073796e6368726f20686562646f6d6164616972658694bafdc5058e0504626f6c64046e756c6c8494bafdc5058f0540206475207765656b2d656e642c206fc3b92063686163756e2064697420656e2064657578206d696e7574657320636520717527696c20612074726f7576c3a92e280094bafdc505e00402696401770c65706768686764617677736f280094bafdc505e00406696e64656e74017d00280094bafdc505e004036469720177046175746f8794bafdc505e004030768656164696e67070094bafdc505d10506040094bafdc505d2050c52c3a9706172746974696f6e280094bafdc505d10502696401770c7a6f61707366647863717664280094bafdc505d10506696e64656e74017d00280094bafdc505d105036469720177046175746f280094bafdc505d105056c6576656c017d028794bafdc505d1050309706172616772617068070094bafdc505e20506040094bafdc505e3059f01416c69676ec3a96520737572206c65732074726f697320636f6d706f73616e74732e204368617175652062696ec3b46d652073756974206175737369206c652073756a6574207472616e737665727365207175692072656cc3a8766520646520736f6e20636f6d706f73616e742c20706f757220717527617563756e20646f6d61696e65206e652072657374652073616e7320726573706f6e7361626c652e280094bafdc505e20502696401770c6a6d6970717967756f756665280094bafdc505e20506696e64656e74017d00280094bafdc505e205036469720177046175746f8794bafdc505e20503057461626c65070094bafdc505830703087461626c65526f77070094bafdc5058407030b7461626c65486561646572070094bafdc50585070309706172616772617068070094bafdc505860706040094bafdc505870709436f6d706f73616e74280094bafdc505860702696401770c6a76756773746c786b7a6863280094bafdc505860706696e64656e74017d00280094bafdc5058607036469720177046175746f280094bafdc5058507036469720177046175746f280094bafdc505850707636f6c7370616e017d01280094bafdc505850707726f777370616e017d018794bafdc5058507030b7461626c65486561646572070094bafdc50597070309706172616772617068070094bafdc505980706040094bafdc505990703517569280094bafdc505980702696401770c73726e637962796276667a61280094bafdc505980706696e64656e74017d00280094bafdc5059807036469720177046175746f280094bafdc5059707036469720177046175746f280094bafdc505970707636f6c7370616e017d01280094bafdc505970707726f777370616e017d018794bafdc5059707030b7461626c65486561646572070094bafdc505a3070309706172616772617068070094bafdc505a40706040094bafdc505a5070f446f6d61696e657320737569766973280094bafdc505a40702696401770c6e6b66696d766f6f76677172280094bafdc505a40706696e64656e74017d00280094bafdc505a407036469720177046175746f280094bafdc505a307036469720177046175746f280094bafdc505a30707636f6c7370616e017d01280094bafdc505a30707726f777370616e017d01280094bafdc5058407036469720177046175746f8794bafdc505840703087461626c65526f77070094bafdc505bc0703097461626c6543656c6c070094bafdc505bd070309706172616772617068070094bafdc505be0706060094bafdc505bf0704626f6c64027b7d8494bafdc505c007084c61756e636865728694bafdc505c80704626f6c64046e756c6c280094bafdc505be0702696401770c6a786466796c6f6f6b646166280094bafdc505be0706696e64656e74017d00280094bafdc505be07036469720177046175746f280094bafdc505bd07036469720177046175746f280094bafdc505bd0707636f6c7370616e017d01280094bafdc505bd0707726f777370616e017d018794bafdc505bd0703097461626c6543656c6c070094bafdc505d0070309706172616772617068070094bafdc505d10706040094bafdc505d20708456c696173202b208694bafdc505da0704636f6465027b7d8494bafdc505db07035b205d8694bafdc505de0704636f6465046e756c6c280094bafdc505d10702696401770c77796779746663686873616b280094bafdc505d10706696e64656e74017d00280094bafdc505d107036469720177046175746f280094bafdc505d007036469720177046175746f280094bafdc505d00707636f6c7370616e017d01280094bafdc505d00707726f777370616e017d018794bafdc505d00703097461626c6543656c6c070094bafdc505e6070309706172616772617068070094bafdc505e70706040094bafdc505e8076761726272652064276163636573736962696c6974c3a920416e64726f69642c20415049206c61756e636865722c20706f6c69746971756520476f6f676c6520506c61792c206d6f64c3a86c6573206578c3a963757461626c65732073757220617070617265696c280094bafdc505e70702696401770c686e776165767065616a7078280094bafdc505e70706696e64656e74017d00280094bafdc505e707036469720177046175746f280094bafdc505e607036469720177046175746f280094bafdc505e60707636f6c7370616e017d01280094bafdc505e60707726f777370616e017d01280094bafdc505bc07036469720177046175746f8794bafdc505bc0703087461626c65526f77070094bafdc505d40803097461626c6543656c6c070094bafdc505d5080309706172616772617068070094bafdc505d60806060094bafdc505d70804626f6c64027b7d8494bafdc505d808074261636b656e648694bafdc505df0804626f6c64046e756c6c280094bafdc505d60802696401770c776d70796a6a63716a65796f280094bafdc505d60806696e64656e74017d00280094bafdc505d608036469720177046175746f280094bafdc505d508036469720177046175746f280094bafdc505d50807636f6c7370616e017d01280094bafdc505d50807726f777370616e017d018794bafdc505d50803097461626c6543656c6c070094bafdc505e7080309706172616772617068070094bafdc505e80806060094bafdc505e90804636f6465027b7d8494bafdc505ea08035b205d8694bafdc505ed0804636f6465046e756c6c8494bafdc505ee0803202b208694bafdc505f10804636f6465027b7d8494bafdc505f208035b205d8694bafdc505f50804636f6465046e756c6c280094bafdc505e80802696401770c707a787a7766657968666474280094bafdc505e80806696e64656e74017d00280094bafdc505e808036469720177046175746f280094bafdc505e708036469720177046175746f280094bafdc505e70807636f6c7370616e017d01280094bafdc505e70807726f777370616e017d018794bafdc505e70803097461626c6543656c6c070094bafdc505fd080309706172616772617068070094bafdc505fe0806040094bafdc505ff08584e6573744a5320657420507269736d612c20706572666f726d616e6365206574206f62736572766162696c6974c3a92c2073c3a96375726974c3a92c20636869666672656d656e742c205247504420657420414920416374280094bafdc505fe0802696401770c7370776366757864626e7474280094bafdc505fe0806696e64656e74017d00280094bafdc505fe08036469720177046175746f280094bafdc505fd08036469720177046175746f280094bafdc505fd0807636f6c7370616e017d01280094bafdc505fd0807726f777370616e017d01280094bafdc505d408036469720177046175746f8794bafdc505d40803087461626c65526f77070094bafdc505dc0903097461626c6543656c6c070094bafdc505dd090309706172616772617068070094bafdc505de0906060094bafdc505df0904626f6c64027b7d8494bafdc505e0090944617368626f6172648694bafdc505e90904626f6c64046e756c6c280094bafdc505de0902696401770c6c737972777868696d736668280094bafdc505de0906696e64656e74017d00280094bafdc505de09036469720177046175746f280094bafdc505dd09036469720177046175746f280094bafdc505dd0907636f6c7370616e017d01280094bafdc505dd0907726f777370616e017d018794bafdc505dd0903097461626c6543656c6c070094bafdc505f1090309706172616772617068070094bafdc505f20906060094bafdc505f30904636f6465027b7d8494bafdc505f409035b205d8694bafdc505f70904636f6465046e756c6c8494bafdc505f80903202b208694bafdc505fb0904636f6465027b7d8494bafdc505fc09035b205d8694bafdc505ff0904636f6465046e756c6c280094bafdc505f20902696401770c6e6a66766a6674716a6a7a6f280094bafdc505f20906696e64656e74017d00280094bafdc505f209036469720177046175746f280094bafdc505f109036469720177046175746f280094bafdc505f10907636f6c7370616e017d01280094bafdc505f10907726f777370616e017d018794bafdc505f10903097461626c6543656c6c070094bafdc505870a0309706172616772617068070094bafdc505880a06040094bafdc505890a5e6163636573736962696c6974c3a9207765622028524741412c2057434147292c2046414c432c206572676f6e6f6d696520636f676e69746976652c2064c3a9706c6f69656d656e7420657420524f4d2064c3a9676f6f676c6973c3a96573280094bafdc505880a02696401770c747a73747765706c72737a61280094bafdc505880a06696e64656e74017d00280094bafdc505880a036469720177046175746f280094bafdc505870a036469720177046175746f280094bafdc505870a07636f6c7370616e017d01280094bafdc505870a07726f777370616e017d01280094bafdc505dc09036469720177046175746f280094bafdc5058307036469720177046175746f8794bafdc50583070309706172616772617068070094bafdc505ec0a06040094bafdc505ed0a9c01556e65207665696c6c6520706f7274c3a9652070617220756e65207365756c6520706572736f6e6e65206e65207365206469666675736520706173203a20632765737420706f757220c3a76120717527696c20792061206465757820706572736f6e6e65732070617220636f6d706f73616e742c20657420717565206c61207265737469747574696f6e2065737420686562646f6d6164616972652e280094bafdc505ec0a02696401770c7465706e6b73617a6b666d6e280094bafdc505ec0a06696e64656e74017d00280094bafdc505ec0a036469720177046175746f8794bafdc505ec0a030768656164696e67070094bafdc5058b0c06040094bafdc5058c0c0f536f75726365732073756976696573280094bafdc5058b0c02696401770c64756a6e6671707664677473280094bafdc5058b0c06696e64656e74017d00280094bafdc5058b0c036469720177046175746f280094bafdc5058b0c056c6576656c017d028794bafdc5058b0c03057461626c65070094bafdc505a00c03087461626c65526f77070094bafdc505a10c030b7461626c65486561646572070094bafdc505a20c0309706172616772617068070094bafdc505a30c06040094bafdc505a40c06536f75726365280094bafdc505a30c02696401770c647178646e69706366647471280094bafdc505a30c06696e64656e74017d00280094bafdc505a30c036469720177046175746f280094bafdc505a20c036469720177046175746f280094bafdc505a20c07636f6c7370616e017d01280094bafdc505a20c07726f777370616e017d018794bafdc505a20c030b7461626c65486561646572070094bafdc505b10c0309706172616772617068070094bafdc505b20c06040094bafdc505b30c12436520717527656c6c65206170706f727465280094bafdc505b20c02696401770c667662747279646862627465280094bafdc505b20c06696e64656e74017d00280094bafdc505b20c036469720177046175746f280094bafdc505b10c036469720177046175746f280094bafdc505b10c07636f6c7370616e017d01280094bafdc505b10c07726f777370616e017d018794bafdc505b10c030b7461626c65486561646572070094bafdc505cc0c0309706172616772617068070094bafdc505cd0c06040094bafdc505ce0c0742696ec3b46d65280094bafdc505cd0c02696401770c76667769716d666c67747078280094bafdc505cd0c06696e64656e74017d00280094bafdc505cd0c036469720177046175746f280094bafdc505cc0c036469720177046175746f280094bafdc505cc0c07636f6c7370616e017d01280094bafdc505cc0c07726f777370616e017d01280094bafdc505a10c036469720177046175746f8794bafdc505a10c03087461626c65526f77070094bafdc505dc0c03097461626c6543656c6c070094bafdc505dd0c0309706172616772617068070094bafdc505de0c06040094bafdc505df0c27446f63756d656e746174696f6e20416e64726f696420e28094204163636573736962696c697479280094bafdc505de0c02696401770c736a79766662757869797170280094bafdc505de0c06696e64656e74017d00280094bafdc505de0c036469720177046175746f280094bafdc505dd0c036469720177046175746f280094bafdc505dd0c07636f6c7370616e017d01280094bafdc505dd0c07726f777370616e017d018794bafdc505dd0c03097461626c6543656c6c070094bafdc5058b0d0309706172616772617068070094bafdc5058c0d06040094bafdc5058d0d4872c3a966c3a972656e636520737572206c2761726272652064276163636573736962696c6974c3a92c206c657320c3a976c3a96e656d656e74732c206c6573206f7665726c617973280094bafdc5058c0d02696401770c6b7474647a7a77787a687366280094bafdc5058c0d06696e64656e74017d00280094bafdc5058c0d036469720177046175746f280094bafdc5058b0d036469720177046175746f280094bafdc5058b0d07636f6c7370616e017d01280094bafdc5058b0d07726f777370616e017d018794bafdc5058b0d03097461626c6543656c6c070094bafdc505d70d0309706172616772617068070094bafdc505d80d06040094bafdc505d90d084c61756e63686572280094bafdc505d80d02696401770c7671796a6168637362766761280094bafdc505d80d06696e64656e74017d00280094bafdc505d80d036469720177046175746f280094bafdc505d70d036469720177046175746f280094bafdc505d70d07636f6c7370616e017d01280094bafdc505d70d07726f777370616e017d01280094bafdc505dc0c036469720177046175746f8794bafdc505dc0c03087461626c65526f77070094bafdc505e90d03097461626c6543656c6c070094bafdc505ea0d0309706172616772617068070094bafdc505eb0d06040094bafdc505ec0d28476f6f676c6520506c617920e2809420446576656c6f7065722050726f6772616d20506f6c696379280094bafdc505eb0d02696401770c76696e786b656a6266637267280094bafdc505eb0d06696e64656e74017d00280094bafdc505eb0d036469720177046175746f280094bafdc505ea0d036469720177046175746f280094bafdc505ea0d07636f6c7370616e017d01280094bafdc505ea0d07726f777370616e017d018794bafdc505ea0d03097461626c6543656c6c070094bafdc505990e0309706172616772617068070094bafdc5059a0e06040094bafdc5059b0e64636f6e747261696e746520646520646973747269627574696f6e2e204327657374206c61207365756c6520736f7572636520717569207065757420696e76616c69646572206c652070726f64756974206475206a6f7572206175206c656e64656d61696e280094bafdc5059a0e02696401770c6a7a6b6163636e72696f6b72280094bafdc5059a0e06696e64656e74017d00280094bafdc5059a0e036469720177046175746f280094bafdc505990e036469720177046175746f280094bafdc505990e07636f6c7370616e017d01280094bafdc505990e07726f777370616e017d018794bafdc505990e03097461626c6543656c6c070094bafdc505860f0309706172616772617068070094bafdc505870f06040094bafdc505880f084c61756e63686572280094bafdc505870f02696401770c706d7967747a61726b78787a280094bafdc505870f06696e64656e74017d00280094bafdc505870f036469720177046175746f280094bafdc505860f036469720177046175746f280094bafdc505860f07636f6c7370616e017d01280094bafdc505860f07726f777370616e017d01280094bafdc505e90d036469720177046175746f8794bafdc505e90d03087461626c65526f77070094bafdc505980f03097461626c6543656c6c070094bafdc505990f0309706172616772617068070094bafdc5059a0f06040094bafdc5059b0f2e416e64726f696420446576656c6f7065727320426c6f672c206e6f7465732064652076657273696f6e20414f5350280094bafdc5059a0f02696401770c736e62706e78797964637877280094bafdc5059a0f06696e64656e74017d00280094bafdc5059a0f036469720177046175746f280094bafdc505990f036469720177046175746f280094bafdc505990f07636f6c7370616e017d01280094bafdc505990f07726f777370616e017d018794bafdc505990f03097461626c6543656c6c070094bafdc505d00f0309706172616772617068070094bafdc505d10f06040094bafdc505d20f307265737472696374696f6e73206e6f7576656c6c657320c3a0206368617175652076657273696f6e206d616a65757265280094bafdc505d10f02696401770c6f71686a6b6b7665696f6769280094bafdc505d10f06696e64656e74017d00280094bafdc505d10f036469720177046175746f280094bafdc505d00f036469720177046175746f280094bafdc505d00f07636f6c7370616e017d01280094bafdc505d00f07726f777370616e017d018794bafdc505d00f03097461626c6543656c6c070094bafdc50588100309706172616772617068070094bafdc505891006040094bafdc5058a10084c61756e63686572280094bafdc505891002696401770c706f64657476756669726363280094bafdc505891006696e64656e74017d00280094bafdc5058910036469720177046175746f280094bafdc5058810036469720177046175746f280094bafdc505881007636f6c7370616e017d01280094bafdc505881007726f777370616e017d01280094bafdc505980f036469720177046175746f8794bafdc505980f03087461626c65526f77070094bafdc5059a1003097461626c6543656c6c070094bafdc5059b100309706172616772617068070094bafdc5059c1006040094bafdc5059d101244c3a970c3b4747320476974487562203a208694bafdc505ad1004636f6465027b7d8494bafdc505ae1008616e64726f6964788694bafdc505b61004636f6465046e756c6c8494bafdc505b710022c208694bafdc505b91004636f6465027b7d8494bafdc505ba10096c6c616d612e6370708694bafdc505c31004636f6465046e756c6c8494bafdc505c410022c208694bafdc505c61004636f6465027b7d8494bafdc505c7100a6578656375746f7263688694bafdc505d11004636f6465046e756c6c280094bafdc5059c1002696401770c647568676d6361767567646e280094bafdc5059c1006696e64656e74017d00280094bafdc5059c10036469720177046175746f280094bafdc5059b10036469720177046175746f280094bafdc5059b1007636f6c7370616e017d01280094bafdc5059b1007726f777370616e017d018794bafdc5059b1003097461626c6543656c6c070094bafdc505d9100309706172616772617068070094bafdc505da1006040094bafdc505db1036c3a9766f6c7574696f6e7320636f6e6372c3a87465732c2072656c65617365732c2064697363757373696f6e73206427697373756573280094bafdc505da1002696401770c7379696167636c74677a6a61280094bafdc505da1006696e64656e74017d00280094bafdc505da10036469720177046175746f280094bafdc505d910036469720177046175746f280094bafdc505d91007636f6c7370616e017d01280094bafdc505d91007726f777370616e017d018794bafdc505d91003097461626c6543656c6c070094bafdc50596110309706172616772617068070094bafdc505971106040094bafdc5059811084c61756e63686572280094bafdc505971102696401770c656c6b68617475676d6e7579280094bafdc505971106696e64656e74017d00280094bafdc5059711036469720177046175746f280094bafdc5059611036469720177046175746f280094bafdc505961107636f6c7370616e017d01280094bafdc505961107726f777370616e017d01280094bafdc5059a10036469720177046175746f8794bafdc5059a1003087461626c65526f77070094bafdc505a81103097461626c6543656c6c070094bafdc505a9110309706172616772617068070094bafdc505aa1106040094bafdc505ab11246172586976202863732e48432c2063732e4149292065742048756767696e672046616365280094bafdc505aa1102696401770c646571647a6d7a736e6e6163280094bafdc505aa1106696e64656e74017d00280094bafdc505aa11036469720177046175746f280094bafdc505a911036469720177046175746f280094bafdc505a91107636f6c7370616e017d01280094bafdc505a91107726f777370616e017d018794bafdc505a91103097461626c6543656c6c070094bafdc505d6110309706172616772617068070094bafdc505d71106040094bafdc505d81142c3a9746174206465206c2761727420646573206167656e7473206427696e7465726661636520657420646573206d6f64c3a86c657320656d626172717561626c6573280094bafdc505d71102696401770c79637a626e62767779717764280094bafdc505d71106696e64656e74017d00280094bafdc505d711036469720177046175746f280094bafdc505d611036469720177046175746f280094bafdc505d61107636f6c7370616e017d01280094bafdc505d61107726f777370616e017d018794bafdc505d61103097461626c6543656c6c070094bafdc5059f120309706172616772617068070094bafdc505a01206040094bafdc505a112084c61756e63686572280094bafdc505a01202696401770c6a77746c7164747075737978280094bafdc505a01206696e64656e74017d00280094bafdc505a012036469720177046175746f280094bafdc5059f12036469720177046175746f280094bafdc5059f1207636f6c7370616e017d01280094bafdc5059f1207726f777370616e017d01280094bafdc505a811036469720177046175746f8794bafdc505a81103087461626c65526f77070094bafdc505b11203097461626c6543656c6c070094bafdc505b2120309706172616772617068070094bafdc505b31206040094bafdc505b412234e6573744a532c20507269736d6120e28094206e6f7465732064652076657273696f6e280094bafdc505b31202696401770c736863747673736d6a676878280094bafdc505b31206696e64656e74017d00280094bafdc505b312036469720177046175746f280094bafdc505b212036469720177046175746f280094bafdc505b21207636f6c7370616e017d01280094bafdc505b21207726f777370616e017d018794bafdc505b21203097461626c6543656c6c070094bafdc505dc120309706172616772617068070094bafdc505dd1206040094bafdc505de1233c3a9766f6c7574696f6e73206465206c6120737461636b2c20727570747572657320646520636f6d7061746962696c6974c3a9280094bafdc505dd1202696401770c757766696763617a66686372280094bafdc505dd1206696e64656e74017d00280094bafdc505dd12036469720177046175746f280094bafdc505dc12036469720177046175746f280094bafdc505dc1207636f6c7370616e017d01280094bafdc505dc1207726f777370616e017d018794bafdc505dc1203097461626c6543656c6c070094bafdc50596130309706172616772617068070094bafdc505971306040094bafdc5059813074261636b656e64280094bafdc505971302696401770c746872786b6c6165746c6978280094bafdc505971306696e64656e74017d00280094bafdc5059713036469720177046175746f280094bafdc5059613036469720177046175746f280094bafdc505961307636f6c7370616e017d01280094bafdc505961307726f777370616e017d01280094bafdc505b112036469720177046175746f8794bafdc505b11203087461626c65526f77070094bafdc505a71303097461626c6543656c6c070094bafdc505a8130309706172616772617068070094bafdc505a91306040094bafdc505aa1327434e494c20e280942061637475616c6974c3a973206574207265636f6d6d616e646174696f6e73280094bafdc505a91302696401770c6a79616c727664736a6b7273280094bafdc505a91306696e64656e74017d00280094bafdc505a913036469720177046175746f280094bafdc505a813036469720177046175746f280094bafdc505a81307636f6c7370616e017d01280094bafdc505a81307726f777370616e017d018794bafdc505a81303097461626c6543656c6c070094bafdc505d5130309706172616772617068070094bafdc505d61306040094bafdc505d71323646f6e6ec3a965732064652073616e74c3a92c20414950442c2061727469636c652039280094bafdc505d61302696401770c6c61646b676a70747662696f280094bafdc505d61306696e64656e74017d00280094bafdc505d613036469720177046175746f280094bafdc505d513036469720177046175746f280094bafdc505d51307636f6c7370616e017d01280094bafdc505d51307726f777370616e017d018794bafdc505d51303097461626c6543656c6c070094bafdc505ff130309706172616772617068070094bafdc505801406040094bafdc5058114074261636b656e64280094bafdc505801402696401770c786f6b6d7164796c73786777280094bafdc505801406696e64656e74017d00280094bafdc5058014036469720177046175746f280094bafdc505ff13036469720177046175746f280094bafdc505ff1307636f6c7370616e017d01280094bafdc505ff1307726f777370616e017d01280094bafdc505a713036469720177046175746f8794bafdc505a71303087461626c65526f77070094bafdc505901403097461626c6543656c6c070094bafdc50591140309706172616772617068070094bafdc505921406040094bafdc50593142741492041637420e2809420746578746573206574206c69676e6573206469726563747269636573280094bafdc505921402696401770c666f7a647369716c636c6369280094bafdc505921406696e64656e74017d00280094bafdc5059214036469720177046175746f280094bafdc5059114036469720177046175746f280094bafdc505911407636f6c7370616e017d01280094bafdc505911407726f777370616e017d018794bafdc505911403097461626c6543656c6c070094bafdc505bf140309706172616772617068070094bafdc505c01406040094bafdc505c114276f626c69676174696f6e73206465207472616e73706172656e63652c2061727469636c65203530280094bafdc505c01402696401770c707572617262727a61707461280094bafdc505c01406696e64656e74017d00280094bafdc505c014036469720177046175746f280094bafdc505bf14036469720177046175746f280094bafdc505bf1407636f6c7370616e017d01280094bafdc505bf1407726f777370616e017d018794bafdc505bf1403097461626c6543656c6c070094bafdc505ef140309706172616772617068070094bafdc505f01406040094bafdc505f114074261636b656e64280094bafdc505f01402696401770c727a7a736a61747964617166280094bafdc505f01406696e64656e74017d00280094bafdc505f014036469720177046175746f280094bafdc505ef14036469720177046175746f280094bafdc505ef1407636f6c7370616e017d01280094bafdc505ef1407726f777370616e017d01280094bafdc5059014036469720177046175746f8794bafdc505901403087461626c65526f77070094bafdc505801503097461626c6543656c6c070094bafdc50581150309706172616772617068070094bafdc505821506040094bafdc50583152152474141206574205743414720e28094206e6f7465732064652076657273696f6e280094bafdc505821502696401770c617874796b64757762666b63280094bafdc505821506696e64656e74017d00280094bafdc5058215036469720177046175746f280094bafdc5058115036469720177046175746f280094bafdc505811507636f6c7370616e017d01280094bafdc505811507726f777370616e017d018794bafdc505811503097461626c6543656c6c070094bafdc505a9150309706172616772617068070094bafdc505aa1506040094bafdc505ab152c72c3a966c3a972656e7469656c2064276163636573736962696c6974c3a9206465206c6120636f6e736f6c65280094bafdc505aa1502696401770c75656c706877746a696b6e6f280094bafdc505aa1506696e64656e74017d00280094bafdc505aa15036469720177046175746f280094bafdc505a915036469720177046175746f280094bafdc505a91507636f6c7370616e017d01280094bafdc505a91507726f777370616e017d018794bafdc505a91503097461626c6543656c6c070094bafdc505db150309706172616772617068070094bafdc505dc1506040094bafdc505dd150944617368626f617264280094bafdc505dc1502696401770c7171697a77757576706e6768280094bafdc505dc1506696e64656e74017d00280094bafdc505dc15036469720177046175746f280094bafdc505db15036469720177046175746f280094bafdc505db1507636f6c7370616e017d01280094bafdc505db1507726f777370616e017d01280094bafdc5058015036469720177046175746f8794bafdc505801503087461626c65526f77070094bafdc505ee1503097461626c6543656c6c070094bafdc505ef150309706172616772617068070094bafdc505f01506040094bafdc505f115362f652f4f532c20696f64c3a94f532c204772617068656e654f5320e28094206a6f75726e617578206465207075626c69636174696f6e280094bafdc505f01502696401770c6c64747a6e7873746d696c6b280094bafdc505f01506696e64656e74017d00280094bafdc505f015036469720177046175746f280094bafdc505ef15036469720177046175746f280094bafdc505ef1507636f6c7370616e017d01280094bafdc505ef1507726f777370616e017d018794bafdc505ef1503097461626c6543656c6c070094bafdc505ab160309706172616772617068070094bafdc505ac1606040094bafdc505ad1633666169736162696c6974c3a9206427756e2064c3a9706c6f69656d656e742073616e7320736572766963657320476f6f676c65280094bafdc505ac1602696401770c7777746d727a726471616c77280094bafdc505ac1606696e64656e74017d00280094bafdc505ac16036469720177046175746f280094bafdc505ab16036469720177046175746f280094bafdc505ab1607636f6c7370616e017d01280094bafdc505ab1607726f777370616e017d018794bafdc505ab1603097461626c6543656c6c070094bafdc505e5160309706172616772617068070094bafdc505e61606040094bafdc505e7160944617368626f617264280094bafdc505e61602696401770c77626d786574686777696d79280094bafdc505e61606696e64656e74017d00280094bafdc505e616036469720177046175746f280094bafdc505e516036469720177046175746f280094bafdc505e51607636f6c7370616e017d01280094bafdc505e51607726f777370616e017d01280094bafdc505ee15036469720177046175746f280094bafdc505a00c036469720177046175746f8794bafdc505a00c030768656164696e67070094bafdc505f91606040094bafdc505fa16064f7574696c73280094bafdc505f91602696401770c69776375676870687a747169280094bafdc505f91606696e64656e74017d00280094bafdc505f916036469720177046175746f280094bafdc505f916056c6576656c017d028794bafdc505f91603057461626c65070094bafdc505851703087461626c65526f77070094bafdc5058617030b7461626c65486561646572070094bafdc50587170309706172616772617068070094bafdc505881706040094bafdc5058917054f7574696c280094bafdc505881702696401770c776c62676c656b6e7a726f76280094bafdc505881706696e64656e74017d00280094bafdc5058817036469720177046175746f280094bafdc5058717036469720177046175746f280094bafdc505871707636f6c7370616e017d01280094bafdc505871707726f777370616e017d018794bafdc5058717030b7461626c65486561646572070094bafdc50595170309706172616772617068070094bafdc505961706040094bafdc50597170552c3b46c65280094bafdc505961702696401770c6c63756f7a767a66676a6a69280094bafdc505961706696e64656e74017d00280094bafdc5059617036469720177046175746f280094bafdc5059517036469720177046175746f280094bafdc505951707636f6c7370616e017d01280094bafdc505951707726f777370616e017d018794bafdc5059517030b7461626c65486561646572070094bafdc505a2170309706172616772617068070094bafdc505a31706040094bafdc505a417144d6f6e747261626c6520656e2073c3a9616e6365280094bafdc505a31702696401770c6c6a646c676c76667161686c280094bafdc505a31706696e64656e74017d00280094bafdc505a317036469720177046175746f280094bafdc505a217036469720177046175746f280094bafdc505a21707636f6c7370616e017d01280094bafdc505a21707726f777370616e017d01280094bafdc5058617036469720177046175746f8794bafdc505861703087461626c65526f77070094bafdc505bf1703097461626c6543656c6c070094bafdc505c0170309706172616772617068070094bafdc505c11706060094bafdc505c21704626f6c64027b7d8494bafdc505c317195375697669206465732072656c6561736573204769744875628694bafdc505dc1704626f6c64046e756c6c8494bafdc505dd172320737572206c65732064c3a970c3b47473206c697374c3a9732063692d646573737573280094bafdc505c11702696401770c6b6e6678736175726d79756c280094bafdc505c11706696e64656e74017d00280094bafdc505c117036469720177046175746f280094bafdc505c017036469720177046175746f280094bafdc505c01707636f6c7370616e017d01280094bafdc505c01707726f777370616e017d018794bafdc505c01703097461626c6543656c6c070094bafdc50584180309706172616772617068070094bafdc505851806040094bafdc5058618366c6573206e6f757665617574c3a973206172726976656e742073616e73207175276f6e2061696c6c65206c6573206368657263686572280094bafdc505851802696401770c61626977796f7071656b6c77280094bafdc505851806696e64656e74017d00280094bafdc5058518036469720177046175746f280094bafdc5058418036469720177046175746f280094bafdc505841807636f6c7370616e017d01280094bafdc505841807726f777370616e017d018794bafdc505841803097461626c6543656c6c070094bafdc505c2180309706172616772617068070094bafdc505c31806040094bafdc505c4181c6c61206c69737465206465732064c3a970c3b4747320737569766973280094bafdc505c31802696401770c6777786e65716a7a72786365280094bafdc505c31806696e64656e74017d00280094bafdc505c318036469720177046175746f280094bafdc505c218036469720177046175746f280094bafdc505c21807636f6c7370616e017d01280094bafdc505c21807726f777370616e017d01280094bafdc505bf17036469720177046175746f8794bafdc505bf1703087461626c65526f77070094bafdc505e61803097461626c6543656c6c070094bafdc505e7180309706172616772617068070094bafdc505e81806060094bafdc505e91804626f6c64027b7d8494bafdc505ea18124365742065737061636520446f636d6f73748694bafdc505fc1804626f6c64046e756c6c280094bafdc505e81802696401770c666f68676b6a78647978666e280094bafdc505e81806696e64656e74017d00280094bafdc505e818036469720177046175746f280094bafdc505e718036469720177046175746f280094bafdc505e71807636f6c7370616e017d01280094bafdc505e71807726f777370616e017d018794bafdc505e71803097461626c6543656c6c070094bafdc50584190309706172616772617068070094bafdc505851906040094bafdc50586193a6a6f75726e616c2c206e6f746573206465206c6563747572652c20636f6d707465732072656e647573206465207072c3a973656e746174696f6e280094bafdc505851902696401770c716d6c626c736d6164626478280094bafdc505851906696e64656e74017d00280094bafdc5058519036469720177046175746f280094bafdc5058419036469720177046175746f280094bafdc505841907636f6c7370616e017d01280094bafdc505841907726f777370616e017d018794bafdc505841903097461626c6543656c6c070094bafdc505c6190309706172616772617068070094bafdc505c71906040094bafdc505c819126c27657370616365206c75692d6dc3aa6d65280094bafdc505c71902696401770c7577747267636e6262747075280094bafdc505c71906696e64656e74017d00280094bafdc505c719036469720177046175746f280094bafdc505c619036469720177046175746f280094bafdc505c61907636f6c7370616e017d01280094bafdc505c61907726f777370616e017d01280094bafdc505e618036469720177046175746f8794bafdc505e61803087461626c65526f77070094bafdc505e11903097461626c6543656c6c070094bafdc505e2190309706172616772617068070094bafdc505e31906060094bafdc505e41904626f6c64027b7d8494bafdc505e5190f41626f6e6e656d656e7473205253538694bafdc505f41904626f6c64046e756c6c8494bafdc505f519182061757820626c6f677320657420666c7578206172586976280094bafdc505e31902696401770c6a6b726d78676e756c786179280094bafdc505e31906696e64656e74017d00280094bafdc505e319036469720177046175746f280094bafdc505e219036469720177046175746f280094bafdc505e21907636f6c7370616e017d01280094bafdc505e21907726f777370616e017d018794bafdc505e21903097461626c6543656c6c070094bafdc505941a0309706172616772617068070094bafdc505951a06040094bafdc505961a10636f6c6c656374652070617373697665280094bafdc505951a02696401770c626f77657a74727770666c70280094bafdc505951a06696e64656e74017d00280094bafdc505951a036469720177046175746f280094bafdc505941a036469720177046175746f280094bafdc505941a07636f6c7370616e017d01280094bafdc505941a07726f777370616e017d018794bafdc505941a03097461626c6543656c6c070094bafdc505ad1a0309706172616772617068070094bafdc505ae1a06040094bafdc505af1a186c61206c69737465206465732061626f6e6e656d656e7473280094bafdc505ae1a02696401770c766e7976766a7a6a6365787a280094bafdc505ae1a06696e64656e74017d00280094bafdc505ae1a036469720177046175746f280094bafdc505ad1a036469720177046175746f280094bafdc505ad1a07636f6c7370616e017d01280094bafdc505ad1a07726f777370616e017d01280094bafdc505e119036469720177046175746f280094bafdc5058517036469720177046175746f8794bafdc50585170309706172616772617068070094bafdc505d01a06040094bafdc505d11aa7014c652073756976692047697448756220657374206c65207365756c206dc3a963616e69736d65206175746f6d6174697175652c20657420696c2065737420766f6c6f6e74616972656d656e74206c6520706c75732073696d706c6520706f737369626c65203a207269656e20c3a02068c3a96265726765722c207269656e20c3a02073617576656761726465722c207269656e2071756920746f6d626520656e2070616e6e652e280094bafdc505d01a02696401770c6d76736c6d776a7878676d70280094bafdc505d01a06696e64656e74017d00280094bafdc505d01a036469720177046175746f8794bafdc505d01a030768656164696e67070094bafdc505f81b06040094bafdc505f91b114a6f75726e616c206465207665696c6c65280094bafdc505f81b02696401770c7a627573766b6a736b717075280094bafdc505f81b06696e64656e74017d00280094bafdc505f81b036469720177046175746f280094bafdc505f81b056c6576656c017d028794bafdc505f81b0309706172616772617068070094bafdc5058f1c06040094bafdc505901c24556e65206c69676e652070617220656e7472c3a9652c20666f726d61742066697865203a280094bafdc5058f1c02696401770c796969766d77656176696d78280094bafdc5058f1c06696e64656e74017d00280094bafdc5058f1c036469720177046175746f8794bafdc5058f1c03057461626c65070094bafdc505b71c03087461626c65526f77070094bafdc505b81c030b7461626c65486561646572070094bafdc505b91c0309706172616772617068070094bafdc505ba1c06040094bafdc505bb1c0444617465280094bafdc505ba1c02696401770c6961727a6f6577796e627579280094bafdc505ba1c06696e64656e74017d00280094bafdc505ba1c036469720177046175746f280094bafdc505b91c036469720177046175746f280094bafdc505b91c07636f6c7370616e017d01280094bafdc505b91c07726f777370616e017d018794bafdc505b91c030b7461626c65486561646572070094bafdc505c61c0309706172616772617068070094bafdc505c71c06040094bafdc505c81c06536f75726365280094bafdc505c71c02696401770c626b72787965666d72636c79280094bafdc505c71c06696e64656e74017d00280094bafdc505c71c036469720177046175746f280094bafdc505c61c036469720177046175746f280094bafdc505c61c07636f6c7370616e017d01280094bafdc505c61c07726f777370616e017d018794bafdc505c61c030b7461626c65486561646572070094bafdc505d51c0309706172616772617068070094bafdc505d61c06040094bafdc505d71c124365207175276f6e20612074726f7576c3a9280094bafdc505d61c02696401770c6b706d6f616e707069737863280094bafdc505d61c06696e64656e74017d00280094bafdc505d61c036469720177046175746f280094bafdc505d51c036469720177046175746f280094bafdc505d51c07636f6c7370616e017d01280094bafdc505d51c07726f777370616e017d018794bafdc505d51c030b7461626c65486561646572070094bafdc505ef1c0309706172616772617068070094bafdc505f01c06040094bafdc505f11c1d43652071756520c3a761206368616e676520706f7572204b616e734f53280094bafdc505f01c02696401770c636b677568746f666a767573280094bafdc505f01c06696e64656e74017d00280094bafdc505f01c036469720177046175746f280094bafdc505ef1c036469720177046175746f280094bafdc505ef1c07636f6c7370616e017d01280094bafdc505ef1c07726f777370616e017d018794bafdc505ef1c030b7461626c65486561646572070094bafdc505941d0309706172616772617068070094bafdc505951d06040094bafdc505961d0d537569746520646f6e6ec3a965280094bafdc505951d02696401770c666e726f6e63636764637876280094bafdc505951d06696e64656e74017d00280094bafdc505951d036469720177046175746f280094bafdc505941d036469720177046175746f280094bafdc505941d07636f6c7370616e017d01280094bafdc505941d07726f777370616e017d01280094bafdc505b81c036469720177046175746f280094bafdc505b71c036469720177046175746f8794bafdc505b71c0309706172616772617068070094bafdc505ab1d06060094bafdc505ac1d04626f6c64027b7d8494bafdc505ad1d2a556e6520656e7472c3a9652073616e7320636f6e636c7573696f6e206e6520636f6d707465207061732e8694bafdc505d61d04626f6c64046e756c6c8494bafdc505d71d61204c6120636f6c6f6e6e6520c2ab20737569746520646f6e6ec3a96520c2bb20636f6e7469656e7420736f697420756e6520616374696f6e2c20736f6974206c6120726169736f6e206578706c6963697465206465206c27696e616374696f6e2e280094bafdc505ab1d02696401770c6379686967706d67736e7163280094bafdc505ab1d06696e64656e74017d00280094bafdc505ab1d036469720177046175746f8794bafdc505ab1d0309706172616772617068070094bafdc505b91e06040094bafdc505ba1e0b4f626a6563746966203a208694bafdc505c51e04626f6c64027b7d8494bafdc505c61e20323020656e7472c3a96573206d696e696d756d20737572206c27616e6ec3a9658694bafdc505e41e04626f6c64046e756c6c8494bafdc505e51e1d2c20c3a974616cc3a965732064276f63746f62726520c3a0206d61692e280094bafdc505b91e02696401770c7462677a687a69646a656176280094bafdc505b91e06696e64656e74017d00280094bafdc505b91e036469720177046175746f8794bafdc505b91e030768656164696e67070094bafdc505831f06040094bafdc505841f1b456e7472c3a965732064c3a96ac3a020636f6e7369676ec3a96573280094bafdc505831f02696401770c6c73646d716e7972636b716d280094bafdc505831f06696e64656e74017d00280094bafdc505831f036469720177046175746f280094bafdc505831f056c6576656c017d038794bafdc505831f03057461626c65070094bafdc505a01f03087461626c65526f77070094bafdc505a11f030b7461626c65486561646572070094bafdc505a21f0309706172616772617068070094bafdc505a31f06040094bafdc505a41f0444617465280094bafdc505a31f02696401770c69706867717a6c7961796471280094bafdc505a31f06696e64656e74017d00280094bafdc505a31f036469720177046175746f280094bafdc505a21f036469720177046175746f280094bafdc505a21f07636f6c7370616e017d01280094bafdc505a21f07726f777370616e017d018794bafdc505a21f030b7461626c65486561646572070094bafdc505af1f0309706172616772617068070094bafdc505b01f06040094bafdc505b11f06536f75726365280094bafdc505b01f02696401770c626a6765656d67746475686b280094bafdc505b01f06696e64656e74017d00280094bafdc505b01f036469720177046175746f280094bafdc505af1f036469720177046175746f280094bafdc505af1f07636f6c7370616e017d01280094bafdc505af1f07726f777370616e017d018794bafdc505af1f030b7461626c65486561646572070094bafdc505be1f0309706172616772617068070094bafdc505bf1f06040094bafdc505c01f124365207175276f6e20612074726f7576c3a9280094bafdc505bf1f02696401770c63707972786d68766b696463280094bafdc505bf1f06696e64656e74017d00280094bafdc505bf1f036469720177046175746f280094bafdc505be1f036469720177046175746f280094bafdc505be1f07636f6c7370616e017d01280094bafdc505be1f07726f777370616e017d018794bafdc505be1f030b7461626c65486561646572070094bafdc505d81f0309706172616772617068070094bafdc505d91f06040094bafdc505da1f1143652071756520c3a761206368616e6765280094bafdc505d91f02696401770c717272626361736475676e64280094bafdc505d91f06696e64656e74017d00280094bafdc505d91f036469720177046175746f280094bafdc505d81f036469720177046175746f280094bafdc505d81f07636f6c7370616e017d01280094bafdc505d81f07726f777370616e017d018794bafdc505d81f030b7461626c65486561646572070094bafdc505f11f0309706172616772617068070094bafdc505f21f06040094bafdc505f31f0d537569746520646f6e6ec3a965280094bafdc505f21f02696401770c6d72706e757761797a677a78280094bafdc505f21f06696e64656e74017d00280094bafdc505f21f036469720177046175746f280094bafdc505f11f036469720177046175746f280094bafdc505f11f07636f6c7370616e017d01280094bafdc505f11f07726f777370616e017d01280094bafdc505a11f036469720177046175746f8794bafdc505a11f03087461626c65526f77070094bafdc505872003097461626c6543656c6c070094bafdc50588200309706172616772617068070094bafdc505892006060094bafdc5058a2004636f6465027b7d8494bafdc5058b20065b646174655d8694bafdc505912004636f6465046e756c6c280094bafdc505892002696401770c706e667965696b7672797071280094bafdc505892006696e64656e74017d00280094bafdc5058920036469720177046175746f280094bafdc5058820036469720177046175746f280094bafdc505882007636f6c7370616e017d01280094bafdc505882007726f777370616e017d018794bafdc505882003097461626c6543656c6c070094bafdc50599200309706172616772617068070094bafdc5059a2006040094bafdc5059b2024476f6f676c6520506c617920446576656c6f7065722050726f6772616d20506f6c696379280094bafdc5059a2002696401770c6571697866616a736366686c280094bafdc5059a2006696e64656e74017d00280094bafdc5059a20036469720177046175746f280094bafdc5059920036469720177046175746f280094bafdc505992007636f6c7370616e017d01280094bafdc505992007726f777370616e017d018794bafdc505992003097461626c6543656c6c070094bafdc505c6200309706172616772617068070094bafdc505c72006040094bafdc505c8206f64757263697373656d656e742064752033302f31302f3230323520737572206c65732073657276696365732064276163636573736962696c6974c3a9203b206c6573206c61756e6368657273206e6520736f6e742070617320c3a96c696769626c65732061752064726170656175208694bafdc505b52104636f6465027b7d8494bafdc505b6211369734163636573736962696c697479546f6f6c8694bafdc505c92104636f6465046e756c6c280094bafdc505c72002696401770c786f676a756b61656b766c7a280094bafdc505c72006696e64656e74017d00280094bafdc505c720036469720177046175746f280094bafdc505c620036469720177046175746f280094bafdc505c62007636f6c7370616e017d01280094bafdc505c62007726f777370616e017d018794bafdc505c62003097461626c6543656c6c070094bafdc505d1210309706172616772617068070094bafdc505d22106040094bafdc505d3213d636f6e6669726d6520717565206c6520677569646167652070617373696620657374206c61207365756c6520766f696520646973747269627561626c65280094bafdc505d22102696401770c6277706561756364646b6663280094bafdc505d22106696e64656e74017d00280094bafdc505d221036469720177046175746f280094bafdc505d121036469720177046175746f280094bafdc505d12107636f6c7370616e017d01280094bafdc505d12107726f777370616e017d018794bafdc505d12103097461626c6543656c6c070094bafdc50597220309706172616772617068070094bafdc505982206040094bafdc50599225f696e74c3a96772c3a920c3a0206c61206e6f746520646520636172616374c3a97269736174696f6e203b20504f432064652076c3a972696669636174696f6e206465206c612064c3a9636c61726174696f6e20506c617920616a6f7574c3a9280094bafdc505982202696401770c7865777a6d70676d63707575280094bafdc505982206696e64656e74017d00280094bafdc5059822036469720177046175746f280094bafdc5059722036469720177046175746f280094bafdc505972207636f6c7370616e017d01280094bafdc505972207726f777370616e017d01280094bafdc5058720036469720177046175746f8794bafdc505872003087461626c65526f77070094bafdc505f92203097461626c6543656c6c070094bafdc505fa220309706172616772617068070094bafdc505fb2206060094bafdc505fc2204636f6465027b7d8494bafdc505fd22065b646174655d8694bafdc505832304636f6465046e756c6c280094bafdc505fb2202696401770c6d7867736c767364616d7961280094bafdc505fb2206696e64656e74017d00280094bafdc505fb22036469720177046175746f280094bafdc505fa22036469720177046175746f280094bafdc505fa2207636f6c7370616e017d01280094bafdc505fa2207726f777370616e017d018794bafdc505fa2203097461626c6543656c6c070094bafdc5058b230309706172616772617068070094bafdc5058c2306040094bafdc5058d231d446f63756d656e746174696f6e204a65747061636b20436f6d706f7365280094bafdc5058c2302696401770c77796e61696269626e6f646c280094bafdc5058c2306696e64656e74017d00280094bafdc5058c23036469720177046175746f280094bafdc5058b23036469720177046175746f280094bafdc5058b2307636f6c7370616e017d01280094bafdc5058b2307726f777370616e017d018794bafdc5058b2303097461626c6543656c6c070094bafdc505b1230309706172616772617068070094bafdc505b22306040094bafdc505b3233d7061732064276964656e74696669616e742064652076756520737461626c652073617566207369206c276170706c69636174696f6e20616374697665208694bafdc505f02304636f6465027b7d8494bafdc505f12314746573745461677341735265736f7572636549648694bafdc505852404636f6465046e756c6c280094bafdc505b22302696401770c77716e73716f6c6764626b68280094bafdc505b22306696e64656e74017d00280094bafdc505b223036469720177046175746f280094bafdc505b123036469720177046175746f280094bafdc505b12307636f6c7370616e017d01280094bafdc505b12307726f777370616e017d018794bafdc505b12303097461626c6543656c6c070094bafdc5058d240309706172616772617068070094bafdc5058e2406040094bafdc5058f24266964656e7469666965206c6120636175736520726163696e6520647520706f696e7420647572280094bafdc5058e2402696401770c7762756b7162786e757a7463280094bafdc5058e2406696e64656e74017d00280094bafdc5058e24036469720177046175746f280094bafdc5058d24036469720177046175746f280094bafdc5058d2407636f6c7370616e017d01280094bafdc5058d2407726f777370616e017d018794bafdc5058d2403097461626c6543656c6c070094bafdc505bc240309706172616772617068070094bafdc505bd2406040094bafdc505be242a666f6e6465206c652070726f746f636f6c65206465206d657375726520646520636f7576657274757265280094bafdc505bd2402696401770c71627a756c6f63776b7a6669280094bafdc505bd2406696e64656e74017d00280094bafdc505bd24036469720177046175746f280094bafdc505bc24036469720177046175746f280094bafdc505bc2407636f6c7370616e017d01280094bafdc505bc2407726f777370616e017d01280094bafdc505f922036469720177046175746f8794bafdc505f92203087461626c65526f77070094bafdc505f02403097461626c6543656c6c070094bafdc505f1240309706172616772617068070094bafdc505f22406060094bafdc505f32404636f6465027b7d8494bafdc505f424065b646174655d8694bafdc505fa2404636f6465046e756c6c280094bafdc505f22402696401770c756d73766672727579787074280094bafdc505f22406696e64656e74017d00280094bafdc505f224036469720177046175746f280094bafdc505f124036469720177046175746f280094bafdc505f12407636f6c7370616e017d01280094bafdc505f12407726f777370616e017d018794bafdc505f12403097461626c6543656c6c070094bafdc50582250309706172616772617068070094bafdc505832506040094bafdc50584251861725869763a323530392e323635333920284170706c6529280094bafdc505832502696401770c626672776d71616871726d62280094bafdc505832506696e64656e74017d00280094bafdc5058325036469720177046175746f280094bafdc5058225036469720177046175746f280094bafdc505822507636f6c7370616e017d01280094bafdc505822507726f777370616e017d018794bafdc505822503097461626c6543656c6c070094bafdc505a3250309706172616772617068070094bafdc505a42506040094bafdc505a525394665727265742d5549204c6974652c203320422c2032382c3020252064652072c3a97573736974652073757220416e64726f6964576f726c64280094bafdc505a42502696401770c716b7971666f667170696c73280094bafdc505a42506696e64656e74017d00280094bafdc505a425036469720177046175746f280094bafdc505a325036469720177046175746f280094bafdc505a32507636f6c7370616e017d01280094bafdc505a32507726f777370616e017d018794bafdc505a32503097461626c6543656c6c070094bafdc505e4250309706172616772617068070094bafdc505e52506040094bafdc505e6253f756e207065746974206d6f64c3a86c6520656d626172717561626c6520657374207472c3a873206c6f696e206427c3aa74726520666961626c65207365756c280094bafdc505e52502696401770c6f6a676b706c67797670737a280094bafdc505e52506696e64656e74017d00280094bafdc505e525036469720177046175746f280094bafdc505e425036469720177046175746f280094bafdc505e42507636f6c7370616e017d01280094bafdc505e42507726f777370616e017d018794bafdc505e42503097461626c6543656c6c070094bafdc505a9260309706172616772617068070094bafdc505aa2606040094bafdc505ab2642c3a96361727465206c65206d6f64c3a86c6520636f6d6d6520766f6965207072696e636970616c65203b20636f6e73657276c3a920636f6d6d65207265636f757273280094bafdc505aa2602696401770c6c686e6e696b717465736f78280094bafdc505aa2606696e64656e74017d00280094bafdc505aa26036469720177046175746f280094bafdc505a926036469720177046175746f280094bafdc505a92607636f6c7370616e017d01280094bafdc505a92607726f777370616e017d01280094bafdc505f024036469720177046175746f8794bafdc505f02403087461626c65526f77070094bafdc505f22603097461626c6543656c6c070094bafdc505f3260309706172616772617068070094bafdc505f42606060094bafdc505f52604636f6465027b7d8494bafdc505f626065b646174655d8694bafdc505fc2604636f6465046e756c6c280094bafdc505f42602696401770c6b776363716e727964697a65280094bafdc505f42606696e64656e74017d00280094bafdc505f426036469720177046175746f280094bafdc505f326036469720177046175746f280094bafdc505f32607636f6c7370616e017d01280094bafdc505f32607726f777370616e017d018794bafdc505f32603097461626c6543656c6c070094bafdc50584270309706172616772617068070094bafdc505852706040094bafdc50586271d53636f72657320416e64726f6964576f726c6420616772c3a967c3a973280094bafdc505852702696401770c64646e73696e766263786261280094bafdc505852706696e64656e74017d00280094bafdc5058527036469720177046175746f280094bafdc5058427036469720177046175746f280094bafdc505842707636f6c7370616e017d01280094bafdc505842707726f777370616e017d018794bafdc505842703097461626c6543656c6c070094bafdc505a8270309706172616772617068070094bafdc505a92706040094bafdc505aa2742486f6c6f332e312d344220616e6e6f6e63c3a920c3a02037312c3020252c20486f6c6f332e312d33354220c3a02037392c33202520e28094206368696666726573208694bafdc505e72704626f6c64027b7d8494bafdc505e8270f6175746f2d64c3a9636c6172c3a9738694bafdc505f52704626f6c64046e756c6c8494bafdc505f6270f20706172206c27c3a9646974657572280094bafdc505a92702696401770c757969777978686d64726d73280094bafdc505a92706696e64656e74017d00280094bafdc505a927036469720177046175746f280094bafdc505a827036469720177046175746f280094bafdc505a82707636f6c7370616e017d01280094bafdc505a82707726f777370616e017d018794bafdc505a82703097461626c6543656c6c070094bafdc5058b280309706172616772617068070094bafdc5058c2806040094bafdc5058d28586dc3aa6d65206175206d696575782c20756e6520616374696f6e207375722063696e712065737420666175737365203a20696e61636365707461626c652073757220756e652064c3a96d61726368652062616e6361697265280094bafdc5058c2802696401770c77656e6f756e657072756779280094bafdc5058c2806696e64656e74017d00280094bafdc5058c28036469720177046175746f280094bafdc5058b28036469720177046175746f280094bafdc5058b2807636f6c7370616e017d01280094bafdc5058b2807726f777370616e017d018794bafdc5058b2803097461626c6543656c6c070094bafdc505ea280309706172616772617068070094bafdc505eb2806040094bafdc505ec285e617267756d656e7420726574656e752064616e73206c61206e6f7465203b20c3a020726576c3a972696669657220736920756e206861726e61697320696e64c3a970656e64616e74207075626c6965206465732072c3a973756c74617473280094bafdc505eb2802696401770c786665726b76666772716371280094bafdc505eb2806696e64656e74017d00280094bafdc505eb28036469720177046175746f280094bafdc505ea28036469720177046175746f280094bafdc505ea2807636f6c7370616e017d01280094bafdc505ea2807726f777370616e017d01280094bafdc505f226036469720177046175746f8794bafdc505f22603087461626c65526f77070094bafdc505ce2903097461626c6543656c6c070094bafdc505cf290309706172616772617068070094bafdc505d02906060094bafdc505d12904636f6465027b7d8494bafdc505d229065b646174655d8694bafdc505d82904636f6465046e756c6c280094bafdc505d02902696401770c636669746a6b626879767476280094bafdc505d02906696e64656e74017d00280094bafdc505d029036469720177046175746f280094bafdc505cf29036469720177046175746f280094bafdc505cf2907636f6c7370616e017d01280094bafdc505cf2907726f777370616e017d018794bafdc505cf2903097461626c6543656c6c070094bafdc505e0290309706172616772617068070094bafdc505e12906040094bafdc505e2290c4d4c204b69742047656e4149280094bafdc505e12902696401770c62686768616d66676a797164280094bafdc505e12906696e64656e74017d00280094bafdc505e129036469720177046175746f280094bafdc505e029036469720177046175746f280094bafdc505e02907636f6c7370616e017d01280094bafdc505e02907726f777370616e017d018794bafdc505e02903097461626c6543656c6c070094bafdc505f5290309706172616772617068070094bafdc505f62906060094bafdc505f72904636f6465027b7d8494bafdc505f829164241434b47524f554e445f5553455f424c4f434b45448694bafdc5058e2a04636f6465046e756c6c8494bafdc5058f2a2c2072656e766f79c3a92064657075697320756e20736572766963652064276163636573736962696c6974c3a9280094bafdc505f62902696401770c7a7478797077677878797966280094bafdc505f62906696e64656e74017d00280094bafdc505f629036469720177046175746f280094bafdc505f529036469720177046175746f280094bafdc505f52907636f6c7370616e017d01280094bafdc505f52907726f777370616e017d018794bafdc505f52903097461626c6543656c6c070094bafdc505c02a0309706172616772617068070094bafdc505c12a06040094bafdc505c22a2b47656d696e69204e616e6f2065737420696e7574696c697361626c6520706f7572206e6f74726520636173280094bafdc505c12a02696401770c796e7a786e63616b6779736d280094bafdc505c12a06696e64656e74017d00280094bafdc505c12a036469720177046175746f280094bafdc505c02a036469720177046175746f280094bafdc505c02a07636f6c7370616e017d01280094bafdc505c02a07726f777370616e017d018794bafdc505c02a03097461626c6543656c6c070094bafdc505f42a0309706172616772617068070094bafdc505f52a06040094bafdc505f62a247069737465206162616e646f6e6ec3a9652c20726169736f6e20636f6e7369676ec3a965280094bafdc505f52a02696401770c706466637061687065707470280094bafdc505f52a06696e64656e74017d00280094bafdc505f52a036469720177046175746f280094bafdc505f42a036469720177046175746f280094bafdc505f42a07636f6c7370616e017d01280094bafdc505f42a07726f777370616e017d01280094bafdc505ce29036469720177046175746f280094bafdc505a01f036469720177046175746f8794bafdc505a01f030a626c6f636b71756f7465070094bafdc505a12b0309706172616772617068070094bafdc505a22b06060094bafdc505a32b04626f6c64027b7d8494bafdc505a42b14c380206661697265206176616e7420656e766f698694bafdc505b72b04626f6c64046e756c6c8494bafdc505b82b48203a206461746572206365732063696e7120656e7472c3a965732c20657420656e20616a6f757465722063656c6c6573206465206c612073656d61696e6520656e20636f7572732e280094bafdc505a22b02696401770c6872797a647a6a666a64766b280094bafdc505a22b06696e64656e74017d00280094bafdc505a22b036469720177046175746f280094bafdc505a12b036469720177046175746f8794bafdc505a12b030768656164696e67070094bafdc505842c06040094bafdc505852c0f5061727461676520696e7465726e65280094bafdc505842c02696401770c6f6472776c667a7762646f6c280094bafdc505842c06696e64656e74017d00280094bafdc505842c036469720177046175746f280094bafdc505842c056c6576656c017d028794bafdc505842c0309706172616772617068070094bafdc505992c06060094bafdc5059a2c04626f6c64027b7d8494bafdc5059b2c15c38020706172746972206465206e6f76656d6272658694bafdc505af2c04626f6c64046e756c6c8494bafdc505b02c7b203a20756e206372c3a96e6561752064c3a96469c3a92064616e73206c6520706f696e742064652073796e6368726f20686562646f6d6164616972652c20756e6520706572736f6e6e65207072c3a973656e746520c3a020746f75722064652072c3b46c6520636520717527656c6c6520612074726f7576c3a92e280094bafdc505992c02696401770c7070616a686863796e676363280094bafdc505992c06696e64656e74017d00280094bafdc505992c036469720177046175746f8794bafdc505992c0309706172616772617068070094bafdc505a82d06040094bafdc505a92d62436861717565207072c3a973656e746174696f6e2065737420636f6e7369676ec3a9652064616e732063657420657370616365203a207175692c2071756f692c20c3a0207175692c2063652071756920656e206120c3a974c3a920726574656e752e280094bafdc505a82d02696401770c636f6e7267797a73706d7565280094bafdc505a82d06696e64656e74017d00280094bafdc505a82d036469720177046175746f8794bafdc505a82d0309706172616772617068070094bafdc5058a2e06040094bafdc5058b2e0b4f626a6563746966203a208694bafdc505962e04626f6c64027b7d8494bafdc505972e2536207072c3a973656e746174696f6e73206d696e696d756d20737572206c27616e6ec3a9658694bafdc505ba2e04626f6c64046e756c6c8494bafdc505bb2e012e280094bafdc5058a2e02696401770c786a717a716b617a62616270280094bafdc5058a2e06696e64656e74017d00280094bafdc5058a2e036469720177046175746f8794bafdc5058a2e030768656164696e67070094bafdc505c02e06040094bafdc505c12e0c4578706c6f69746174696f6e280094bafdc505c02e02696401770c617a646b626a766b776b7674280094bafdc505c02e06696e64656e74017d00280094bafdc505c02e036469720177046175746f280094bafdc505c02e056c6576656c017d028794bafdc505c02e0309706172616772617068070094bafdc505d22e06040094bafdc505d32e0e537572206c27616e6ec3a9652c208694bafdc505e02e04626f6c64027b7d8494bafdc505e12e406175206d6f696e732033206170706f727473206465206c61207665696c6c652072c3a9656c6c656d656e7420696e74c3a96772c3a9732061752070726f6a65748694bafdc5059e2f04626f6c64046e756c6c8494bafdc5059f2f3d2c206176656320706f75722063686163756e206c6120736f757263652064276f726967696e6520657420636520717527696c2061206368616e67c3a92e280094bafdc505d22e02696401770c677776666d636874747a6968280094bafdc505d22e06696e64656e74017d00280094bafdc505d22e036469720177046175746f8794bafdc505d22e030768656164696e67070094bafdc505df2f06040094bafdc505e02f17436f6d6d756e617574c3a97320746563686e6971756573280094bafdc505df2f02696401770c6a6d756f787162716b726a66280094bafdc505df2f06696e64656e74017d00280094bafdc505df2f036469720177046175746f280094bafdc505df2f056c6576656c017d028794bafdc505df2f0309706172616772617068070094bafdc505fb2f06040094bafdc505fc2f4e4c6520677569646520696e736372697420636520626c6f632064616e73206c276f626a6563746966206f626c696761746f69726520312c207061732064616e73206c276f626a656374696620422e280094bafdc505fb2f02696401770c6f6c6f676668697464727967280094bafdc505fb2f06696e64656e74017d00280094bafdc505fb2f036469720177046175746f8794bafdc505fb2f030a62756c6c65744c697374070094bafdc505ce3003086c6973744974656d070094bafdc505cf300309706172616772617068070094bafdc505d03006060094bafdc505d13004626f6c64027b7d8494bafdc505d2300e3220636f6d6d756e617574c3a9738694bafdc505df3004626f6c64046e756c6c8494bafdc505e03077203a20756e206573706163652064652064c3a976656c6f70706575727320416e64726f6964206f7269656e74c3a9206163636573736962696c6974c3a92c206574206c6120636f6d6d756e617574c3a9206427756e206465732072756e74696d6573206427696e66c3a972656e6365207375697669732e280094bafdc505d03002696401770c727373746d7373786e697477280094bafdc505d03006696e64656e74017d00280094bafdc505d030036469720177046175746f280094bafdc505cf30036469720177046175746f8794bafdc505cf3003086c6973744974656d070094bafdc505d7310309706172616772617068070094bafdc505d83106060094bafdc505d93104626f6c64027b7d8494bafdc505da31193520636f6e747269627574696f6e73207075626c69717565738694bafdc505f33104626f6c64046e756c6c8494bafdc505f431830120737572206c27616e6ec3a965203a20756e65207175657374696f6e20706f73c3a965206176656320736f6e20636f6e74657874652c20756e652072c3a9706f6e736520646f6e6ec3a9652c20756e20726170706f72742064652062756720646f63756d656e74c3a92c20756e207265746f7572206427657870c3a97269656e63652e280094bafdc505d83102696401770c636f66737872727772727971280094bafdc505d83106696e64656e74017d00280094bafdc505d831036469720177046175746f280094bafdc505d731036469720177046175746f8794bafdc505d73103086c6973744974656d070094bafdc505f6320309706172616772617068070094bafdc505f73206060094bafdc505f83204626f6c64027b7d8494bafdc505f9321e3120636f6e747269627574696f6e2065787465726e65206d696e696d756d8694bafdc505973304626f6c64046e756c6c8494bafdc5059833402c206dc3aa6d65206d6f646573746520e2809420756e20636f7272656374696620646520646f63756d656e746174696f6e2065737420726563657661626c652e280094bafdc505f73202696401770c6462746a69736b756b65646c280094bafdc505f73206696e64656e74017d00280094bafdc505f732036469720177046175746f280094bafdc505f632036469720177046175746f8794bafdc505f63203086c6973744974656d070094bafdc505da330309706172616772617068070094bafdc505db3306040094bafdc505dc3342506f75722063686163756e65203a206c65206c69656e2c206c6120646174652c206c6520636f6e74657874652c2063652071756920656e2065737420736f7274692e280094bafdc505db3302696401770c707361796e6d757969696e67280094bafdc505db3306696e64656e74017d00280094bafdc505db33036469720177046175746f280094bafdc505da33036469720177046175746f280094bafdc505ce30036469720177046175746f8794bafdc505ce300309706172616772617068070094bafdc505a43406040094bafdc505a5341744c3a96d61727261676520656e206e6f76656d6272652e280094bafdc505a43402696401770c686d6b6a6367736c77716173280094bafdc505a43406696e64656e74017d00280094bafdc505a434036469720177046175746f00	Projet KansOS · Technical Track Tech 4 · Objectif obligatoire 1\n14 octobre 2026\n\nÀ quoi elle sert\n\nLa veille sert à lever notre point dur : savoir quelle proportion des écrans d'une application tierce est assez décrite pour permettre un guidage fiable, et comment faire là où elle ne l'est pas.\n\nCe n'est pas un exercice documentaire. Chaque entrée du journal doit dire ce qu'elle change pour le projet, ou pourquoi elle ne change rien.\n\nRythme\n\n1 heure par personne et par semaine, placée librement — l'équipe est répartie sur quatre pays et n'a pas les mêmes emplois du temps.\n\nRestitution au point de synchro hebdomadaire du week-end, où chacun dit en deux minutes ce qu'il a trouvé.\n\nRépartition\n\nAlignée sur les trois composants. Chaque binôme suit aussi le sujet transverse qui relève de son composant, pour qu'aucun domaine ne reste sans responsable.\n\nComposant\n\nQui\n\nDomaines suivis\n\nLauncher\n\nElias + [ ]\n\narbre d'accessibilité Android, API launcher, politique Google Play, modèles exécutables sur appareil\n\nBackend\n\n[ ] + [ ]\n\nNestJS et Prisma, performance et observabilité, sécurité, chiffrement, RGPD et AI Act\n\nDashboard\n\n[ ] + [ ]\n\naccessibilité web (RGAA, WCAG), FALC, ergonomie cognitive, déploiement et ROM dégooglisées\n\nUne veille portée par une seule personne ne se diffuse pas : c'est pour ça qu'il y a deux personnes par composant, et que la restitution est hebdomadaire.\n\nSources suivies\n\nSource\n\nCe qu'elle apporte\n\nBinôme\n\nDocumentation Android — Accessibility\n\nréférence sur l'arbre d'accessibilité, les événements, les overlays\n\nLauncher\n\nGoogle Play — Developer Program Policy\n\ncontrainte de distribution. C'est la seule source qui peut invalider le produit du jour au lendemain\n\nLauncher\n\nAndroid Developers Blog, notes de version AOSP\n\nrestrictions nouvelles à chaque version majeure\n\nLauncher\n\nDépôts GitHub : androidx, llama.cpp, executorch\n\névolutions concrètes, releases, discussions d'issues\n\nLauncher\n\narXiv (cs.HC, cs.AI) et Hugging Face\n\nétat de l'art des agents d'interface et des modèles embarquables\n\nLauncher\n\nNestJS, Prisma — notes de version\n\névolutions de la stack, ruptures de compatibilité\n\nBackend\n\nCNIL — actualités et recommandations\n\ndonnées de santé, AIPD, article 9\n\nBackend\n\nAI Act — textes et lignes directrices\n\nobligations de transparence, article 50\n\nBackend\n\nRGAA et WCAG — notes de version\n\nréférentiel d'accessibilité de la console\n\nDashboard\n\n/e/OS, iodéOS, GrapheneOS — journaux de publication\n\nfaisabilité d'un déploiement sans services Google\n\nDashboard\n\nOutils\n\nOutil\n\nRôle\n\nMontrable en séance\n\nSuivi des releases GitHub sur les dépôts listés ci-dessus\n\nles nouveautés arrivent sans qu'on aille les chercher\n\nla liste des dépôts suivis\n\nCet espace Docmost\n\njournal, notes de lecture, comptes rendus de présentation\n\nl'espace lui-même\n\nAbonnements RSS aux blogs et flux arXiv\n\ncollecte passive\n\nla liste des abonnements\n\nLe suivi GitHub est le seul mécanisme automatique, et il est volontairement le plus simple possible : rien à héberger, rien à sauvegarder, rien qui tombe en panne.\n\nJournal de veille\n\nUne ligne par entrée, format fixe :\n\nDate\n\nSource\n\nCe qu'on a trouvé\n\nCe que ça change pour KansOS\n\nSuite donnée\n\nUne entrée sans conclusion ne compte pas. La colonne « suite donnée » contient soit une action, soit la raison explicite de l'inaction.\n\nObjectif : 20 entrées minimum sur l'année, étalées d'octobre à mai.\n\nEntrées déjà consignées\n\nDate\n\nSource\n\nCe qu'on a trouvé\n\nCe que ça change\n\nSuite donnée\n\n[date]\n\nGoogle Play Developer Program Policy\n\ndurcissement du 30/10/2025 sur les services d'accessibilité ; les launchers ne sont pas éligibles au drapeau isAccessibilityTool\n\nconfirme que le guidage passif est la seule voie distribuable\n\nintégré à la note de caractérisation ; POC de vérification de la déclaration Play ajouté\n\n[date]\n\nDocumentation Jetpack Compose\n\npas d'identifiant de vue stable sauf si l'application active testTagsAsResourceId\n\nidentifie la cause racine du point dur\n\nfonde le protocole de mesure de couverture\n\n[date]\n\narXiv:2509.26539 (Apple)\n\nFerret-UI Lite, 3 B, 28,0 % de réussite sur AndroidWorld\n\nun petit modèle embarquable est très loin d'être fiable seul\n\nécarte le modèle comme voie principale ; conservé comme recours\n\n[date]\n\nScores AndroidWorld agrégés\n\nHolo3.1-4B annoncé à 71,0 %, Holo3.1-35B à 79,3 % — chiffres auto-déclarés par l'éditeur\n\nmême au mieux, une action sur cinq est fausse : inacceptable sur une démarche bancaire\n\nargument retenu dans la note ; à revérifier si un harnais indépendant publie des résultats\n\n[date]\n\nML Kit GenAI\n\nBACKGROUND_USE_BLOCKED renvoyé depuis un service d'accessibilité\n\nGemini Nano est inutilisable pour notre cas\n\npiste abandonnée, raison consignée\n\nÀ faire avant envoi : dater ces cinq entrées, et en ajouter celles de la semaine en cours.\n\nPartage interne\n\nÀ partir de novembre : un créneau dédié dans le point de synchro hebdomadaire, une personne présente à tour de rôle ce qu'elle a trouvé.\n\nChaque présentation est consignée dans cet espace : qui, quoi, à qui, ce qui en a été retenu.\n\nObjectif : 6 présentations minimum sur l'année.\n\nExploitation\n\nSur l'année, au moins 3 apports de la veille réellement intégrés au projet, avec pour chacun la source d'origine et ce qu'il a changé.\n\nCommunautés techniques\n\nLe guide inscrit ce bloc dans l'objectif obligatoire 1, pas dans l'objectif B.\n\n2 communautés : un espace de développeurs Android orienté accessibilité, et la communauté d'un des runtimes d'inférence suivis.\n\n5 contributions publiques sur l'année : une question posée avec son contexte, une réponse donnée, un rapport de bug documenté, un retour d'expérience.\n\n1 contribution externe minimum, même modeste — un correctif de documentation est recevable.\n\nPour chacune : le lien, la date, le contexte, ce qui en est sorti.\n\nDémarrage en novembre.	'/e/os':367B '0':630B,663B '1':13B,83B,834B,883B '14':14B '2':840B '20':515B '2026':16B '2509.26539':621B '28':629B '3':627B,667B,801B '30/10/2025':550B '4':10B '5':859B '50':352B '6':789B '71':662B '79':666B '9':340B 'abandonne':724B 'abonn':428B,440B 'access':238B 'accessibilit':163B,188B,244B,362B,555B,715B,848B 'act':186B,343B 'action':506B,679B 'activ':603B 'actualit':332B 'agent':310B 'agreg':658B 'ai':185B,342B 'aill':404B 'aipd':338B 'ajout':588B,737B 'aligne':130B 'android':164B,237B,273B,846B 'androidworld':634B,657B 'androidx':289B 'anne':520B,794B,798B,864B 'annonc':660B 'aosp':279B 'api':165B 'appareil':173B 'appl':622B 'applic':36B,602B 'apport':234B,802B 'arbr':161B,242B 'argument':689B 'arriv':400B 'art':308B 'articl':339B,351B 'arxiv':299B,434B,620B 'assez':39B 'au':109B,270B,562B,676B,799B,808B 'aucun':149B 'aussi':138B 'auto':670B 'auto-declar':669B 'automatiqu':448B 'aux':430B 'avant':729B 'avec':810B,868B 'b':628B,839B 'backend':174B,330B,341B,353B 'background':707B 'bancair':688B 'binom':136B,235B 'bloc':829B 'block':709B 'blog':275B,431B 'bug':877B 'c':210B,258B 'ca':213B,486B,538B 'caracteris':580B 'cas':722B 'caus':607B 'ce':56B,69B,124B,231B,479B,484B,531B,536B,766B,782B,818B,828B,903B 'cell':738B 'ces':732B 'cet':412B,776B 'chacun':119B,812B,896B 'chang':72B,80B,487B,539B,822B 'chaqu':63B,135B,283B,771B 'chercher':406B 'chiffr':668B 'chiffrement':182B 'ci':396B 'ci-dessus':395B 'cinq':681B,733B 'cnil':331B 'cognit':194B 'collect':435B 'colonn':500B 'comm':649B,653B 'comment':47B 'communaut':823B,841B,851B 'compatibilit':329B 'compos':134B,146B,155B,221B,592B 'compt':419B,497B 'conclus':495B 'concret':293B 'confirm':565B 'conserv':652B 'consigne':528B,726B,774B 'consol':365B 'context':870B,902B 'contient':503B 'contraint':255B 'contribut':860B,884B 'correctif':890B 'cour':743B 'couvertur':618B 'creneau':751B 'cs.ai':301B 'cs.hc':300B 'd':34B,162B,243B,296B,311B,361B,374B,522B,554B,594B,642B,714B,815B,852B,856B,881B 'dan':691B,753B,775B,830B,836B 'dashboard':187B,366B,380B 'date':477B,529B,542B,589B,619B,655B,703B,900B 'dater':731B 'de':2A,111B,144B,256B,277B,306B,321B,324B,328B,336B,349B,358B,363B,371B,417B,421B,469B,511B,579B,582B,584B,596B,615B,617B,631B,739B,748B,756B,764B,803B,844B,876B,891B 'declar':586B,671B 'decrit':40B 'dedi':752B 'degooglise':198B 'deja':527B 'demarch':687B 'demarrag':908B 'deploiement':195B,376B 'depot':287B,393B,410B 'depui':711B 'des':32B,309B,314B,388B,409B,439B,701B,854B 'dessus':397B 'deux':122B,218B 'develop':252B,274B,545B 'developpeur':845B 'diffus':208B 'dire':68B 'directric':347B 'discuss':295B 'dispositif':1A 'distribu':574B 'distribut':257B 'dit':120B 'docmost':414B 'document':236B,590B,878B,892B 'documentair':62B 'doit':67B 'domain':150B,157B 'donne':335B,491B,502B,541B,873B 'drapeau':563B 'du':65B,106B,114B,268B,549B,609B 'dur':28B,611B 'durciss':548B 'ecart':646B 'ecran':33B 'editeur':674B 'elia':160B 'elig':561B 'ell':19B,51B,71B,78B,233B,768B 'embarqu':316B,638B 'emploi':105B 'en':121B,385B,466B,736B,742B,784B,905B,909B 'end':117B 'entre':64B,474B,493B,516B,526B,734B 'envoi':730B 'equip':93B 'ergonomi':193B 'espac':413B,424B,777B,843B 'est':38B,54B,58B,94B,211B,226B,259B,444B,451B,570B,639B,682B,718B,773B,893B,906B 'et':46B,87B,99B,176B,179B,184B,196B,222B,302B,313B,333B,345B,355B,432B,449B,735B,817B,849B 'etale':521B 'etat':305B 'ete':786B 'etr':643B 'even':246B 'evolut':292B,323B 'execut':171B 'executorch':291B 'exercic':61B 'experi':882B 'explicit':510B 'exploit':795B 'extern':885B 'face':304B 'fair':48B,728B 'faisabilit':373B 'falc':192B 'fauss':683B 'ferret':624B 'ferret-ui':623B 'fiabl':45B,644B 'fix':476B 'flux':433B 'fond':612B 'format':475B 'gemini':716B 'genai':706B 'github':288B,390B,443B 'googl':168B,250B,379B,543B 'grapheneo':369B 'guid':826B 'guidag':44B,568B 'harnai':698B 'hebdomadair':113B,227B,758B 'heberg':459B 'heur':84B 'holo3.1-35b':664B 'holo3.1-4b':659B 'hug':303B 'identifi':595B,605B 'il':126B,215B,450B,820B 'inaccept':684B 'inact':513B 'independ':699B 'infer':857B 'inscrit':827B 'integr':575B,807B 'interfac':312B 'intern':745B 'inutilis':719B 'invalid':265B 'iodeo':368B 'isaccessibilitytool':564B 'issu':297B 'jetpack':591B 'jour':269B 'journal':66B,415B,468B 'journaux':370B 'kanso':6B,489B 'kit':705B 'l':53B,92B,241B,307B,423B,512B,519B,601B,673B,793B,797B,831B,837B,863B 'la':21B,49B,224B,260B,325B,364B,407B,437B,499B,508B,571B,577B,585B,606B,692B,740B,804B,813B,850B,899B 'launcher':159B,166B,249B,272B,286B,298B,317B,557B 'le':74B,139B,266B,441B,445B,453B,567B,613B,647B,754B,825B,897B,901B 'lectur':418B 'lendemain':271B 'les':103B,132B,245B,247B,392B,398B,405B,552B,556B 'lever':25B 'librement':91B 'lien':898B 'lign':346B,472B 'list':394B,408B,438B 'lite':626B 'llama.cpp':290B 'loin':641B 'lui':426B 'lui-mem':425B 'mai':525B 'majeur':285B 'mecanism':447B 'meme':104B,427B,675B,887B 'mesur':616B 'mieux':677B 'minimum':517B,791B,886B 'minut':123B 'ml':704B 'model':170B,315B,637B,648B 'modest':888B 'moin':800B 'montrabl':384B 'n':57B,100B 'nano':717B 'ne':52B,79B,151B,206B,496B,558B 'nestj':175B,318B 'note':276B,320B,357B,416B,578B,693B 'notr':26B,721B 'nouveaut':399B 'nouvell':281B 'novembr':749B,910B 'objectif':11B,514B,788B,832B,838B 'oblig':348B 'obligatoir':12B,833B 'observabilit':180B 'octobr':15B,523B 'orient':847B 'origin':816B 'ou':50B,76B,118B 'outil':381B,382B 'overlay':248B 'pann':467B 'par':85B,88B,202B,220B,473B,672B 'partag':744B 'partir':747B 'pas':55B,59B,102B,209B,498B,560B,593B,835B 'passif':569B 'passiv':436B 'pay':98B 'perform':178B 'permettr':42B 'personn':86B,205B,219B,760B 'petit':636B 'peut':264B 'pist':723B 'place':90B 'play':169B,251B,544B,587B 'plus':454B 'poc':581B 'point':27B,110B,610B,755B 'polici':254B,547B 'politiqu':167B 'porte':201B 'pose':867B 'possibl':456B 'pour':41B,73B,147B,212B,488B,720B,811B,895B 'pourquoi':77B 'present':422B,761B,772B,790B 'principal':651B 'prisma':177B,319B 'produit':267B 'program':253B,546B 'projet':5B,75B,809B 'proport':31B 'protocol':614B 'publi':700B 'public':372B 'publiqu':861B 'qu':70B,125B,148B,214B,232B,402B,480B,532B,767B,819B 'quatr':97B 'que':223B,485B,537B,566B 'quell':30B 'question':866B 'qui':142B,156B,263B,464B,778B,781B,783B,904B 'quoi':18B,779B 'racin':608B 'raison':509B,725B 'rapport':875B 'recev':894B 'recommand':334B 'recour':654B 'reellement':806B 'refer':239B 'referentiel':360B 'releas':294B,389B 'relev':143B 'rendus':420B 'renvoy':710B 'reparti':95B 'repartit':129B 'repons':872B 'respons':154B 'rest':152B 'restitut':108B,225B 'restrict':280B 'resultat':702B 'retenu':690B,787B 'retour':880B 'reussit':632B 'reverifi':695B 'rgaa':190B,354B 'rgpd':183B 'rien':81B,457B,460B,463B 'role':383B,765B 'rom':197B 'rss':429B 'runtim':855B 'ruptur':327B 'rythm':82B 'san':153B,377B,401B,494B 'sant':337B 'sauf':599B 'sauvegard':462B 'savoir':29B 'score':656B 'se':207B 'seanc':386B 'securit':181B 'semain':89B,741B 'sert':20B,23B 'servic':378B,553B,713B 'seul':204B,261B,446B,572B,645B 'si':600B,696B 'simpl':455B 'soit':504B,507B 'son':145B,869B 'sont':559B 'sorti':907B 'sourc':228B,230B,262B,478B,530B,814B 'stabl':598B 'stack':326B 'suit':137B,490B,501B,540B 'suivi':158B,229B,387B,411B,442B,858B 'sujet':140B 'sur':96B,131B,172B,240B,391B,518B,551B,633B,680B,685B,792B,796B,862B 'synchro':112B,757B 'tech':9B 'technic':7B 'techniqu':824B 'technologiqu':4A 'temp':107B 'testtagsasresourceid':604B 'text':344B 'tierc':37B 'tomb':465B 'tour':763B 'track':8B 'transpar':350B 'transvers':141B 'tres':640B 'troi':133B 'trouv':128B,483B,535B,770B 'ui':625B 'un':43B,60B,375B,635B,697B,712B,750B,842B,853B,874B,879B,889B 'une':35B,199B,203B,471B,492B,505B,678B,686B,759B,865B,871B 'use':708B 'veill':3A,22B,200B,470B,805B 'verif':583B 'version':278B,284B,322B,359B 'voie':573B,650B 'volontair':452B 'vue':597B 'wcag':191B,356B 'web':189B 'week':116B 'week-end':115B 'y':216B	\N	01a12cf1-0bd0-70e9-87f3-436c4e3a4023	01a12cf1-0bd0-70e9-87f3-436c4e3a4023	\N	01a12d29-3a97-7210-ac78-1927a95f2edd	01a12cf1-0bd3-7a42-96f8-8cedaf38cf22	f	2026-10-11 23:14:01.443892+00	2026-10-11 23:14:01.888+00	\N	{01a12cf1-0bd0-70e9-87f3-436c4e3a4023}	f	0
01a12d10-e301-772b-b847-6b22997917de	c1bzfey8PO	Pitchs introduction	\N	\N	a07Ed	{"type": "doc", "content": [{"type": "codeBlock", "attrs": {"dir": "auto"}, "content": [{"text": "KansOS part d’un constat simple. Quand quelqu’un n’arrive pas à faire une démarche en ligne, on pense tout de suite qu’il lui manque des compétences numériques. En fait, quand on regarde les chiffres, les gens disent surtout qu’ils ont peur de se tromper, que le site est mal fait, ou qu’ils ne comprennent pas le langage administratif. Le problème vient des interfaces, pas des personnes. Donc nous, on ne cherche pas à former les gens, on adapte le téléphone. KansOS c’est un launcher Android simplifié, qu’un proche ou un éducateur configure depuis une interface web. On réduit ce qui est affiché, on encadre les contacts, on guide pas à pas dans les démarches. Et surtout, on retire ces adaptations au fur et à mesure que la personne devient autonome. Le but, c’est qu’elle finisse par ne plus avoir besoin de nous.", "type": "text"}]}, {"type": "codeBlock", "attrs": {"dir": "auto"}, "content": [{"text": "KansOS, je vous donne un exemple. Imaginez un adulte qui vit seul, accompagné quelques heures par semaine par un éducateur. Il doit prendre un rendez-vous médical en ligne. Il ouvre le site, il y a quinze boutons, il ne sait pas où cliquer, il a peur de se tromper, donc il attend le passage de l’éducateur. Résultat : il n’est pas autonome, et l’éducateur passe son temps à faire des choses à sa place. KansOS, c’est un téléphone Android adapté qui lui montre étape par étape où appuyer — sans le faire à sa place, parce que faire à sa place n’apprend rien. L’éducateur configure tout ça à distance depuis une interface web, et il peut réduire l’assistance quand il voit que ça passe. L’objectif c’est que la personne fasse seule ce qu’elle ne pouvait pas faire seule.", "type": "text"}]}, {"type": "codeBlock", "attrs": {"dir": "auto"}, "content": [{"text": "KansOS c’est un système en trois parties. D’abord un launcher Android : c’est l’écran d’accueil du téléphone, il n’affiche que ce qui est autorisé au niveau où en est la personne, avec de grandes cibles et des libellés simples. Ensuite un back-end, qui est le cœur du système : il traduit les intentions de l’aidant — un niveau d’autonomie par domaine, des contacts validés — en règles concrètes, versionnées et datées, que l’appareil télécharge et applique. Et un dashboard web, où l’aidant règle tout ça et répond aux demandes de la personne. La difficulté technique n’est pas dans le back-end, qui reste un CRUD avec un calcul de configuration. Elle est sur l’appareil : guider quelqu’un dans une application qu’on ne contrôle pas, en lisant l’arbre d’accessibilité qu’elle expose. C’est là qu’est notre point dur.", "type": "text"}]}, {"type": "codeBlock", "attrs": {"dir": "auto"}, "content": [{"text": "KansOS ressemble beaucoup à un contrôle parental, et c’est la première objection qu’on nous fait. La différence tient à trois mécanismes. Premier : la personne voit tout ce qui est configuré sur elle, et elle voit ce que son aidant voit. Ce n’est pas désactivable. Un contrôle parental marche justement parce que l’enfant ne voit pas la console ; nous c’est l’inverse. Deuxième : chaque règle a une date de fin. Si personne ne la reconduit, elle disparaît. Normalement l’inertie va vers le verrouillage — on restreint un jour par précaution et ça reste dix ans. Là le système desserre tout seul. Troisième : la personne peut faire des demandes — ajouter un contact, accéder à une application, passer un niveau. C’est le seul endroit où l’initiative vient d’elle. Sans ça, on ferait juste une télécommande.", "type": "text"}]}, {"type": "codeBlock", "attrs": {"dir": "auto"}, "content": [{"text": "KansOS c’est un téléphone Android qui accompagne vers l’autonomie des personnes qui ont besoin d’un tiers pour s’en servir. Mais l’intérêt technique du projet, il est sur un point précis. Quand la personne est bloquée dans une démarche, on veut lui montrer sur quel bouton appuyer, dans une application qu’on ne contrôle pas : Ameli, sa banque, France Identité. Pour ça on lit l’arbre d’accessibilité que l’application expose au système. Le problème, c’est que cet arbre est très inégalement rempli. En Jetpack Compose il n’y a pas d’identifiant stable, sauf si le développeur l’a activé. En Flutter il n’y en a aucun. Sur une interface dessinée en canvas, il n’y a rien du tout. Donc notre produit dépend d’une donnée produite par des tiers qui ne nous doivent rien. Savoir quelle proportion du parc applicatif est réellement guidable, c’est ce qui décide si le produit existe.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "guizqosfijjz", "dir": "auto", "indent": 0}, "content": []}]}	\\x012bc48dd3fe080007010764656661756c7403097061726167726170682100c48dd3fe0800026964012800c48dd3fe080006696e64656e74017d002800c48dd3fe0800036469720177046175746f0700c48dd3fe0800060100c48dd3fe080405a1c48dd3fe08010141c48dd3fe08000100b50641c48dd3fe080b0100b706c7c48dd3fe08c106c48dd3fe080b0309636f6465426c6f636b2800c48dd3fe08f90c036469720177046175746f0700c48dd3fe08f90c060400c48dd3fe08fb0cd6064b616e734f5320706172742064e28099756e20636f6e737461742073696d706c652e205175616e64207175656c7175e28099756e206ee280996172726976652070617320c3a020666169726520756e652064c3a96d617263686520656e206c69676e652c206f6e2070656e736520746f7574206465207375697465207175e28099696c206c7569206d616e7175652064657320636f6d70c3a974656e636573206e756dc3a97269717565732e20456e20666169742c207175616e64206f6e2072656761726465206c65732063686966667265732c206c65732067656e7320646973656e7420737572746f7574207175e28099696c73206f6e7420706575722064652073652074726f6d7065722c20717565206c65207369746520657374206d616c20666169742c206f75207175e28099696c73206e6520636f6d7072656e6e656e7420706173206c65206c616e676167652061646d696e69737472617469662e204c652070726f626cc3a86d65207669656e742064657320696e74657266616365732c207061732064657320706572736f6e6e65732e20446f6e63206e6f75732c206f6e206e6520636865726368652070617320c3a020666f726d6572206c65732067656e732c206f6e20616461707465206c652074c3a96cc3a970686f6e652e204b616e734f532063e2809965737420756e206c61756e6368657220416e64726f69642073696d706c696669c3a92c207175e28099756e2070726f636865206f7520756e20c3a9647563617465757220636f6e6669677572652064657075697320756e6520696e74657266616365207765622e204f6e2072c3a964756974206365207175692065737420616666696368c3a92c206f6e20656e6361647265206c657320636f6e74616374732c206f6e2067756964652070617320c3a0207061732064616e73206c65732064c3a96d6172636865732e20457420737572746f75742c206f6e20726574697265206365732061646170746174696f6e732061752066757220657420c3a0206d657375726520717565206c6120706572736f6e6e652064657669656e74206175746f6e6f6d652e204c65206275742c2063e28099657374207175e28099656c6c652066696e6973736520706172206e6520706c75732061766f6972206265736f696e206465206e6f75732e81c48dd3fe080903a1c48dd3fe080a01c7c48dd3fe08f90cc48dd3fe080b0309636f6465426c6f636b2800c48dd3fe08b313036469720177046175746f0700c48dd3fe08b313060400c48dd3fe08b513ad064b616e734f532c206a6520766f757320646f6e6e6520756e206578656d706c652e20496d6167696e657a20756e206164756c74652071756920766974207365756c2c206163636f6d7061676ec3a9207175656c7175657320686575726573207061722073656d61696e652070617220756e20c3a964756361746575722e20496c20646f6974207072656e64726520756e2072656e64657a2d766f7573206dc3a9646963616c20656e206c69676e652e20496c206f75767265206c6520736974652c20696c20792061207175696e7a6520626f75746f6e732c20696c206e65207361697420706173206fc3b920636c69717565722c20696c206120706575722064652073652074726f6d7065722c20646f6e6320696c20617474656e64206c652070617373616765206465206ce28099c3a964756361746575722e2052c3a973756c746174203a20696c206ee2809965737420706173206175746f6e6f6d652c206574206ce28099c3a9647563617465757220706173736520736f6e2074656d707320c3a0206661697265206465732063686f73657320c3a020736120706c6163652e204b616e734f532c2063e2809965737420756e2074c3a96cc3a970686f6e6520416e64726f6964206164617074c3a920717569206c7569206d6f6e74726520c3a9746170652070617220c3a974617065206fc3b9206170707579657220e280942073616e73206c6520666169726520c3a020736120706c6163652c2070617263652071756520666169726520c3a020736120706c616365206ee2809961707072656e64207269656e2e204ce28099c3a9647563617465757220636f6e66696775726520746f757420c3a76120c3a02064697374616e63652064657075697320756e6520696e74657266616365207765622c20657420696c20706575742072c3a96475697265206ce28099617373697374616e6365207175616e6420696c20766f69742071756520c3a7612070617373652e204ce280996f626a65637469662063e2809965737420717565206c6120706572736f6e6e65206661737365207365756c65206365207175e28099656c6c65206e6520706f757661697420706173206661697265207365756c652e81c48dd3fe08b11303a1c48dd3fe08b21301c7c48dd3fe08b313c48dd3fe080b0309636f6465426c6f636b2800c48dd3fe08bb19036469720177046175746f0700c48dd3fe08bb19060400c48dd3fe08bd19f3064b616e734f532063e2809965737420756e2073797374c3a86d6520656e2074726f697320706172746965732e2044e2809961626f726420756e206c61756e6368657220416e64726f6964203a2063e28099657374206ce28099c3a96372616e2064e280996163637565696c2064752074c3a96cc3a970686f6e652c20696c206ee2809961666669636865207175652063652071756920657374206175746f726973c3a9206175206e6976656175206fc3b920656e20657374206c6120706572736f6e6e652c2061766563206465206772616e646573206369626c657320657420646573206c6962656c6cc3a9732073696d706c65732e20456e737569746520756e206261636b2d656e642c2071756920657374206c652063c59375722064752073797374c3a86d65203a20696c2074726164756974206c657320696e74656e74696f6e73206465206ce28099616964616e7420e2809420756e206e69766561752064e280996175746f6e6f6d69652070617220646f6d61696e652c2064657320636f6e74616374732076616c6964c3a97320e2809420656e2072c3a8676c657320636f6e6372c3a87465732c2076657273696f6e6ec3a9657320657420646174c3a965732c20717565206ce28099617070617265696c2074c3a96cc3a9636861726765206574206170706c697175652e20457420756e2064617368626f617264207765622c206fc3b9206ce28099616964616e742072c3a8676c6520746f757420c3a7612065742072c3a9706f6e64206175782064656d616e646573206465206c6120706572736f6e6e652e204c6120646966666963756c74c3a920746563686e69717565206ee28099657374207061732064616e73206c65206261636b2d656e642c2071756920726573746520756e2043525544206176656320756e2063616c63756c20646520636f6e66696775726174696f6e2e20456c6c652065737420737572206ce28099617070617265696c203a20677569646572207175656c7175e28099756e2064616e7320756e65206170706c69636174696f6e207175e280996f6e206e6520636f6e7472c3b46c65207061732c20656e206c6973616e74206ce2809961726272652064e280996163636573736962696c6974c3a9207175e28099656c6c65206578706f73652e2043e28099657374206cc3a0207175e28099657374206e6f74726520706f696e74206475722e81c48dd3fe08b91903a1c48dd3fe08ba1901c7c48dd3fe08bb19c48dd3fe080b0309636f6465426c6f636b2800c48dd3fe08f31f036469720177046175746f0700c48dd3fe08f31f060400c48dd3fe08f51fd4064b616e734f532072657373656d626c652062656175636f757020c3a020756e20636f6e7472c3b46c6520706172656e74616c2c2065742063e28099657374206c61207072656d69c3a87265206f626a656374696f6e207175e280996f6e206e6f757320666169742e204c612064696666c3a972656e6365207469656e7420c3a02074726f6973206dc3a963616e69736d65732e205072656d696572203a206c6120706572736f6e6e6520766f697420746f7574206365207175692065737420636f6e6669677572c3a92073757220656c6c652c20657420656c6c6520766f69742063652071756520736f6e20616964616e7420766f69742e204365206ee28099657374207061732064c3a973616374697661626c652e20556e20636f6e7472c3b46c6520706172656e74616c206d6172636865206a757374656d656e7420706172636520717565206ce28099656e66616e74206e6520766f697420706173206c6120636f6e736f6c65203b206e6f75732063e28099657374206ce28099696e76657273652e204465757869c3a86d65203a206368617175652072c3a8676c65206120756e6520646174652064652066696e2e20536920706572736f6e6e65206e65206c61207265636f6e647569742c20656c6c652064697370617261c3ae742e204e6f726d616c656d656e74206ce28099696e65727469652076612076657273206c6520766572726f75696c6c61676520e28094206f6e20726573747265696e7420756e206a6f757220706172207072c3a963617574696f6e20657420c3a7612072657374652064697820616e732e204cc3a0206c652073797374c3a86d6520646573736572726520746f7574207365756c2e2054726f697369c3a86d65203a206c6120706572736f6e6e652070657574206661697265206465732064656d616e64657320e2809420616a6f7574657220756e20636f6e746163742c20616363c3a964657220c3a020756e65206170706c69636174696f6e2c2070617373657220756e206e69766561752e2043e28099657374206c65207365756c20656e64726f6974206fc3b9206ce28099696e6974696174697665207669656e742064e28099656c6c652e2053616e7320c3a7612c206f6e20666572616974206a7573746520756e652074c3a96cc3a9636f6d6d616e64652e81c48dd3fe08f11f03a8c48dd3fe08f21f01770c6775697a716f7366696a6a7ac1c48dd3fe08f31fc48dd3fe080b0100f006c1c48dd3fe08f31fc48dd3fe089f260100f206c7c48dd3fe08902dc48dd3fe089f260309636f6465426c6f636b2800c48dd3fe088334036469720177046175746f0700c48dd3fe088334060400c48dd3fe088534a6074b616e734f532063e2809965737420756e2074c3a96cc3a970686f6e6520416e64726f696420717569206163636f6d7061676e652076657273206ce280996175746f6e6f6d69652064657320706572736f6e6e657320717569206f6e74206265736f696e2064e28099756e20746965727320706f75722073e28099656e207365727669722e204d616973206ce28099696e74c3a972c3aa7420746563686e697175652064752070726f6a65742c20696c206573742073757220756e20706f696e74207072c3a96369732e205175616e64206c6120706572736f6e6e652065737420626c6f7175c3a9652064616e7320756e652064c3a96d61726368652c206f6e2076657574206c7569206d6f6e7472657220737572207175656c20626f75746f6e20617070757965722c2064616e7320756e65206170706c69636174696f6e207175e280996f6e206e6520636f6e7472c3b46c6520706173203a20416d656c692c2073612062616e7175652c204672616e6365204964656e746974c3a92e20506f757220c3a761206f6e206c6974206ce2809961726272652064e280996163636573736962696c6974c3a920717565206ce280996170706c69636174696f6e206578706f73652061752073797374c3a86d652e204c652070726f626cc3a86d652c2063e28099657374207175652063657420617262726520657374207472c3a87320696ec3a967616c656d656e742072656d706c692e20456e204a65747061636b20436f6d706f736520696c206ee28099792061207061732064e280996964656e74696669616e7420737461626c652c2073617566207369206c652064c3a976656c6f7070657572206ce2809961206163746976c3a92e20456e20466c757474657220696c206ee280997920656e206120617563756e2e2053757220756e6520696e746572666163652064657373696ec3a96520656e2063616e7661732c20696c206ee28099792061207269656e20647520746f75742e20446f6e63206e6f7472652070726f647569742064c3a970656e642064e28099756e6520646f6e6ec3a9652070726f6475697465207061722064657320746965727320717569206e65206e6f757320646f6976656e74207269656e2e205361766f6972207175656c6c652070726f706f7274696f6e2064752070617263206170706c696361746966206573742072c3a9656c6c656d656e74206775696461626c652c2063e28099657374206365207175692064c3a963696465207369206c652070726f64756974206578697374652e01c48dd3fe0807010105f40caf1304b71904ef1f049b26039f26e40d	KansOS part d’un constat simple. Quand quelqu’un n’arrive pas à faire une démarche en ligne, on pense tout de suite qu’il lui manque des compétences numériques. En fait, quand on regarde les chiffres, les gens disent surtout qu’ils ont peur de se tromper, que le site est mal fait, ou qu’ils ne comprennent pas le langage administratif. Le problème vient des interfaces, pas des personnes. Donc nous, on ne cherche pas à former les gens, on adapte le téléphone. KansOS c’est un launcher Android simplifié, qu’un proche ou un éducateur configure depuis une interface web. On réduit ce qui est affiché, on encadre les contacts, on guide pas à pas dans les démarches. Et surtout, on retire ces adaptations au fur et à mesure que la personne devient autonome. Le but, c’est qu’elle finisse par ne plus avoir besoin de nous.\n\nKansOS, je vous donne un exemple. Imaginez un adulte qui vit seul, accompagné quelques heures par semaine par un éducateur. Il doit prendre un rendez-vous médical en ligne. Il ouvre le site, il y a quinze boutons, il ne sait pas où cliquer, il a peur de se tromper, donc il attend le passage de l’éducateur. Résultat : il n’est pas autonome, et l’éducateur passe son temps à faire des choses à sa place. KansOS, c’est un téléphone Android adapté qui lui montre étape par étape où appuyer — sans le faire à sa place, parce que faire à sa place n’apprend rien. L’éducateur configure tout ça à distance depuis une interface web, et il peut réduire l’assistance quand il voit que ça passe. L’objectif c’est que la personne fasse seule ce qu’elle ne pouvait pas faire seule.\n\nKansOS c’est un système en trois parties. D’abord un launcher Android : c’est l’écran d’accueil du téléphone, il n’affiche que ce qui est autorisé au niveau où en est la personne, avec de grandes cibles et des libellés simples. Ensuite un back-end, qui est le cœur du système : il traduit les intentions de l’aidant — un niveau d’autonomie par domaine, des contacts validés — en règles concrètes, versionnées et datées, que l’appareil télécharge et applique. Et un dashboard web, où l’aidant règle tout ça et répond aux demandes de la personne. La difficulté technique n’est pas dans le back-end, qui reste un CRUD avec un calcul de configuration. Elle est sur l’appareil : guider quelqu’un dans une application qu’on ne contrôle pas, en lisant l’arbre d’accessibilité qu’elle expose. C’est là qu’est notre point dur.\n\nKansOS ressemble beaucoup à un contrôle parental, et c’est la première objection qu’on nous fait. La différence tient à trois mécanismes. Premier : la personne voit tout ce qui est configuré sur elle, et elle voit ce que son aidant voit. Ce n’est pas désactivable. Un contrôle parental marche justement parce que l’enfant ne voit pas la console ; nous c’est l’inverse. Deuxième : chaque règle a une date de fin. Si personne ne la reconduit, elle disparaît. Normalement l’inertie va vers le verrouillage — on restreint un jour par précaution et ça reste dix ans. Là le système desserre tout seul. Troisième : la personne peut faire des demandes — ajouter un contact, accéder à une application, passer un niveau. C’est le seul endroit où l’initiative vient d’elle. Sans ça, on ferait juste une télécommande.\n\nKansOS c’est un téléphone Android qui accompagne vers l’autonomie des personnes qui ont besoin d’un tiers pour s’en servir. Mais l’intérêt technique du projet, il est sur un point précis. Quand la personne est bloquée dans une démarche, on veut lui montrer sur quel bouton appuyer, dans une application qu’on ne contrôle pas : Ameli, sa banque, France Identité. Pour ça on lit l’arbre d’accessibilité que l’application expose au système. Le problème, c’est que cet arbre est très inégalement rempli. En Jetpack Compose il n’y a pas d’identifiant stable, sauf si le développeur l’a activé. En Flutter il n’y en a aucun. Sur une interface dessinée en canvas, il n’y a rien du tout. Donc notre produit dépend d’une donnée produite par des tiers qui ne nous doivent rien. Savoir quelle proportion du parc applicatif est réellement guidable, c’est ce qui décide si le produit existe.\n\n	'abord':311B 'acced':570B 'accessibilit':443B,666B 'accompagn':166B,602B 'accueil':320B 'activ':701B 'adapt':85B,129B,238B 'administratif':65B 'adult':162B 'affich':111B,325B 'aidant':363B,391B,495B 'ajout':567B 'ame':654B 'an':553B 'android':93B,237B,314B,600B 'appareil':381B,426B 'applic':432B,573B,648B,669B 'applicatif':744B 'appliqu':384B 'apprend':260B 'appuy':246B,645B 'arbr':441B,664B,679B 'arriv':13B 'assist':278B 'attend':207B 'au':130B,331B,671B 'aucun':709B 'autonom':139B,218B 'autonomi':367B,605B 'autoris':330B 'aux':397B 'avec':338B,417B 'avoir':150B 'back':349B,411B 'back-end':348B,410B 'banqu':656B 'beaucoup':457B 'besoin':151B,610B 'bloque':634B 'bouton':192B,644B 'c':89B,142B,233B,287B,303B,315B,447B,463B,517B,577B,596B,675B,748B 'ca':266B,283B,394B,550B,589B,660B 'calcul':419B 'canva':715B 'ce':108B,294B,327B,483B,492B,497B,750B 'ces':128B 'cet':678B 'chaqu':522B 'cherch':78B 'chiffr':39B 'chose':228B 'cibl':341B 'cliquer':198B 'coeur':354B 'compet':31B 'compos':686B 'comprenn':61B 'concret':375B 'configur':101B,264B,421B,486B 'consol':515B 'constat':7B 'contact':115B,371B,569B 'control':436B,460B,503B,652B 'crud':416B 'd':5B,310B,319B,366B,442B,586B,611B,665B,692B,727B 'dan':121B,408B,430B,635B,646B 'dashboard':387B 'date':378B,526B 'de':24B,48B,152B,202B,210B,339B,361B,399B,420B,527B 'decid':752B 'demand':398B,566B 'demarch':18B,123B,637B 'depend':726B 'depui':102B,269B 'des':30B,69B,72B,227B,343B,370B,565B,606B,732B 'desactiv':501B 'desserr':557B 'dessine':713B 'deuxiem':521B 'developpeur':698B 'devient':138B 'differ':473B 'difficult':403B 'disent':42B 'disparait':535B 'distanc':268B 'dix':552B 'doit':175B 'doivent':737B 'domain':369B 'donc':74B,205B,723B 'donn':157B 'donne':729B 'du':321B,355B,622B,721B,742B 'dur':454B 'ecran':318B 'educateur':100B,173B,212B,221B,263B 'ell':145B,296B,422B,445B,488B,490B,534B,587B 'en':19B,33B,182B,307B,334B,373B,438B,616B,684B,702B,707B,714B 'encadr':113B 'end':350B,412B 'endroit':581B 'enfant':510B 'ensuit':346B 'est':54B,90B,110B,143B,216B,234B,288B,304B,316B,329B,335B,352B,406B,423B,448B,451B,464B,485B,499B,518B,578B,597B,625B,633B,676B,680B,745B,749B 'et':124B,132B,219B,273B,342B,377B,383B,385B,395B,462B,489B,549B 'etap':242B,244B 'exempl':159B 'exist':756B 'expos':446B,670B 'fair':16B,226B,249B,255B,300B,564B 'fait':34B,56B,471B 'fass':292B 'ferait':591B 'fin':528B 'finiss':146B 'flutter':703B 'former':81B 'franc':657B 'fur':131B 'gen':41B,83B 'grand':340B 'guid':117B 'guidabl':747B 'guider':427B 'heur':168B 'identifi':693B 'identit':658B 'il':27B,45B,59B,174B,184B,188B,193B,199B,206B,214B,274B,280B,323B,357B,624B,687B,704B,716B 'imaginez':160B 'inegal':682B 'inerti':538B 'initi':584B 'intent':360B 'interet':620B 'interfac':70B,104B,271B,712B 'introduct':2A 'invers':520B 'je':155B 'jetpack':685B 'jour':546B 'just':592B 'justement':506B 'kanso':3B,88B,154B,232B,302B,455B,595B 'l':211B,220B,262B,277B,285B,317B,362B,380B,390B,425B,440B,509B,519B,537B,583B,604B,619B,663B,668B,699B 'la':136B,290B,336B,400B,402B,449B,465B,472B,479B,514B,532B,554B,561B,631B 'langag':64B 'launcher':92B,313B 'le':52B,63B,66B,86B,140B,186B,208B,248B,353B,409B,541B,555B,579B,673B,697B,754B 'les':38B,40B,82B,114B,122B,359B 'libell':344B 'lign':20B,183B 'lisant':439B 'lit':662B 'lui':28B,240B,640B 'mai':618B 'mal':55B 'manqu':29B 'march':505B 'mecanism':477B 'medic':181B 'mesur':134B 'montr':241B 'montrer':641B 'n':12B,215B,259B,324B,405B,498B,688B,705B,717B 'ne':60B,77B,148B,194B,297B,435B,511B,531B,651B,735B 'niveau':332B,365B,576B 'normal':536B 'notr':452B,724B 'nous':75B,153B,470B,516B,736B 'numeriqu':32B 'object':467B 'objectif':286B 'ont':46B,609B 'ou':57B,98B,197B,245B,333B,389B,582B 'ouvr':185B 'par':147B,169B,171B,243B,368B,547B,731B 'parc':253B,507B,743B 'parent':461B,504B 'part':4B 'parti':309B 'pas':14B,62B,71B,79B,118B,120B,196B,217B,299B,407B,437B,500B,513B,653B,691B 'pass':222B,284B 'passag':209B 'passer':574B 'pens':22B 'personn':73B,137B,291B,337B,401B,480B,530B,562B,607B,632B 'peur':47B,201B 'peut':275B,563B 'pitch':1A 'place':231B,252B,258B 'plus':149B 'point':453B,628B 'pour':614B,659B 'pouvait':298B 'precaut':548B 'preci':629B 'premier':466B,478B 'prendr':176B 'problem':67B,674B 'proch':97B 'produit':725B,730B,755B 'projet':623B 'proport':741B 'qu':26B,44B,58B,95B,144B,295B,433B,444B,450B,468B,649B 'quand':9B,35B,279B,630B 'que':51B,135B,254B,282B,289B,326B,379B,493B,508B,667B,677B 'quel':643B 'quell':740B 'quelqu':10B,167B,428B 'qui':109B,163B,239B,328B,351B,413B,484B,601B,608B,734B,751B 'quinz':191B 'reconduit':533B 'reduir':276B 'reduit':107B 'reellement':746B 'regard':37B 'regl':374B,392B,523B 'rempli':683B 'rendez':179B 'rendez-v':178B 'repond':396B 'ressembl':456B 'rest':414B,551B 'restreint':544B 'resultat':213B 'retir':127B 'rien':261B,720B,738B 'sa':230B,251B,257B,655B 'sait':195B 'san':247B,588B 'sauf':695B 'savoir':739B 'se':49B,203B 'semain':170B 'servir':617B 'seul':165B,293B,301B,559B,580B 'si':529B,696B,753B 'simpl':8B,345B 'simplifi':94B 'site':53B,187B 'son':223B,494B 'stabl':694B 'suit':25B 'sur':424B,487B,626B,642B,710B 'surtout':43B,125B 'system':306B,356B,556B,672B 'techniqu':404B,621B 'telecharg':382B 'telecommand':594B 'telephon':87B,236B,322B,599B 'temp':224B 'tient':474B 'tier':613B,733B 'tout':23B,265B,393B,482B,558B,722B 'traduit':358B 'tres':681B 'troi':308B,476B 'troisiem':560B 'tromper':50B,204B 'un':6B,11B,91B,96B,99B,158B,161B,172B,177B,235B,305B,312B,347B,364B,386B,415B,418B,429B,459B,502B,545B,568B,575B,598B,612B,627B 'une':17B,103B,270B,431B,525B,572B,593B,636B,647B,711B,728B 'va':539B 'valid':372B 'ver':540B,603B 'verrouillag':542B 'versionne':376B 'veut':639B 'vient':68B,585B 'vit':164B 'voit':281B,481B,491B,496B,512B 'vous':156B,180B 'web':105B,272B,388B 'y':189B,689B,706B,718B	\N	01a12cf1-0bd0-70e9-87f3-436c4e3a4023	01a12cf1-0bd0-70e9-87f3-436c4e3a4023	\N	01a12cf1-0bdd-72b8-9465-6c1e33f4a9c9	01a12cf1-0bd3-7a42-96f8-8cedaf38cf22	f	2026-10-11 22:24:03.839049+00	2026-10-11 22:25:37.175+00	\N	{01a12cf1-0bd0-70e9-87f3-436c4e3a4023}	f	0
01a12d16-3fd6-74cd-9bbc-0c82d20f72bb	2wMULvlhWj	Veille technologique	\N	\N	a1BtT	{"type": "doc", "content": [{"type": "paragraph", "attrs": {"id": "gwxlnilkfsud", "dir": "auto", "indent": 0}}]}	\\x0104e0bf94e1030007010764656661756c7403097061726167726170682800e0bf94e1030002696401770c6777786c6e696c6b667375642800e0bf94e1030006696e64656e74017d002800e0bf94e10300036469720177046175746f00		'technologiqu':2A 'veill':1A	\N	01a12cf1-0bd0-70e9-87f3-436c4e3a4023	01a12cf1-0bd0-70e9-87f3-436c4e3a4023	\N	01a12cf1-0bdd-72b8-9465-6c1e33f4a9c9	01a12cf1-0bd3-7a42-96f8-8cedaf38cf22	f	2026-10-11 22:29:55.285707+00	2026-10-11 22:34:04.421+00	\N	{01a12cf1-0bd0-70e9-87f3-436c4e3a4023}	f	0
01a12d29-b33c-7771-a510-a4f4d1590e6d	I7zExxA6XC	Compte rendu - Octobre 2, 2026	\N	\N	a05hN	{"type": "doc", "content": [{"type": "heading", "attrs": {"id": "nsaavdvqubfn", "dir": "auto", "level": 1, "indent": 0}, "content": [{"text": "Summary", "type": "text"}]}, {"type": "heading", "attrs": {"id": "cbpmpksgwkvb", "dir": "auto", "level": 3, "indent": 0}, "content": [{"text": "Action Items", "type": "text"}]}, {"type": "taskList", "attrs": {"dir": "auto"}, "content": [{"type": "taskItem", "attrs": {"dir": "auto", "checked": false}, "content": [{"type": "paragraph", "attrs": {"id": "ceyxjrufsfzy", "dir": "auto", "indent": 0}, "content": [{"text": " Team to read the Student Guide objectives carefully and know them precisely before the next meeting", "type": "text"}]}]}, {"type": "taskItem", "attrs": {"dir": "auto", "checked": false}, "content": [{"type": "paragraph", "attrs": {"id": "uudlesffojyr", "dir": "auto", "indent": 0}, "content": [{"text": " Team to prepare a clear action plan on each TRAC objective (what, how, when) for the next meeting", "type": "text"}]}]}, {"type": "taskItem", "attrs": {"dir": "auto", "checked": false}, "content": [{"type": "paragraph", "attrs": {"id": "jglenzjcqjko", "dir": "auto", "indent": 0}, "content": [{"text": " Team to prepare a more detailed work schedule/organization overview for the next meeting", "type": "text"}]}]}, {"type": "taskItem", "attrs": {"dir": "auto", "checked": false}, "content": [{"type": "paragraph", "attrs": {"id": "ndjstajctjhb", "dir": "auto", "indent": 0}, "content": [{"text": " Team to organize Veille Techno: dedicate ~1 hour/week per person to research, test tracks via POC, and document results", "type": "text"}]}]}, {"type": "taskItem", "attrs": {"dir": "auto", "checked": false}, "content": [{"type": "paragraph", "attrs": {"id": "lcupjqpiifyg", "dir": "auto", "indent": 0}, "content": [{"text": " Team to produce structured documentation (architecture diagrams, CI/CD, test plans, etc.) targeting different audiences (users, admins, researchers)", "type": "text"}]}]}, {"type": "taskItem", "attrs": {"dir": "auto", "checked": false}, "content": [{"type": "paragraph", "attrs": {"id": "vuomdzxwtful", "dir": "auto", "indent": 0}, "content": [{"text": " Team to measure, analyze, and iterate on performance — not just measure once", "type": "text"}]}]}, {"type": "taskItem", "attrs": {"dir": "auto", "checked": false}, "content": [{"type": "paragraph", "attrs": {"id": "xfgrimngfhso", "dir": "auto", "indent": 0}, "content": [{"text": " Team to ensure all members attend the weekly synchro point, not just 3–4", "type": "text"}]}]}, {"type": "taskItem", "attrs": {"dir": "auto", "checked": false}, "content": [{"type": "paragraph", "attrs": {"id": "kmhcizqlukyh", "dir": "auto", "indent": 0}, "content": [{"text": " Team to identify and document the project's \\"hard point\\" for Mandatory Objective 1", "type": "text"}]}]}, {"type": "taskItem", "attrs": {"dir": "auto", "checked": false}, "content": [{"type": "paragraph", "attrs": {"id": "zwmtjyerjvjr", "dir": "auto", "indent": 0}, "content": [{"text": " Team to prepare the meeting document (as done last time) for the next session", "type": "text"}]}]}, {"type": "taskItem", "attrs": {"dir": "auto", "checked": false}, "content": [{"type": "paragraph", "attrs": {"id": "cgprjuvhpgyd", "dir": "auto", "indent": 0}, "content": [{"text": " Next meeting scheduled for ", "type": "text"}, {"text": "Friday, October 16", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}, {"text": " (moved up from week of Oct 19 due to exam period)", "type": "text"}]}]}]}, {"type": "horizontalRule", "attrs": {"dir": "auto"}}, {"type": "heading", "attrs": {"id": "kmjhlswvxojt", "dir": "auto", "level": 3, "indent": 0}, "content": [{"text": "Project Overview", "type": "text"}]}, {"type": "bulletList", "attrs": {"dir": "auto"}, "content": [{"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "jeyzhzpqjzvn", "dir": "auto", "indent": 0}, "content": [{"text": "Project name:", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}, {"text": " Consoré — aimed at helping neurotypical people navigate digital life and achieve digital autonomy", "type": "text"}]}]}, {"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "aizjbmpiccvw", "dir": "auto", "indent": 0}, "content": [{"text": "Three main components:", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}, {"text": " Backend (API foundation), Dashboard (web interface for helpers), and Launcher (managed by Elias)", "type": "text"}]}]}, {"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "ixooamhxziqv", "dir": "auto", "indent": 0}, "content": [{"text": "Task management:", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}, {"text": " Using Jira (chosen over GitHub Projects based on prior project management experience, approved by DPR)", "type": "text"}]}]}, {"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "cyzmbahtxkxs", "dir": "auto", "indent": 0}, "content": [{"text": "Team locations:", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}, {"text": " Sweden (Elias), Berlin (Enzo), Dublin/Ireland (Lucas, Alexandre), Canada/Quebec (one member), with home schools in Montpellier and Paris", "type": "text"}]}]}]}, {"type": "heading", "attrs": {"id": "hbadxodjzvqe", "dir": "auto", "level": 3, "indent": 0}, "content": [{"text": "Attendance", "type": "text"}]}, {"type": "bulletList", "attrs": {"dir": "auto"}, "content": [{"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "oabjrywehewm", "dir": "auto", "indent": 0}, "content": [{"text": "Ibrahim was absent", "type": "text"}]}]}, {"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "aamidbbldkyo", "dir": "auto", "indent": 0}, "content": [{"text": "Alexandre was absent due to illness (uncertain if attending at all)", "type": "text"}]}]}, {"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "yadhwduzvsee", "dir": "auto", "indent": 0}, "content": [{"text": "Angel/Angèle arrived late", "type": "text"}]}]}]}, {"type": "heading", "attrs": {"id": "pvniofnazzui", "dir": "auto", "level": 3, "indent": 0}, "content": [{"text": "Progress Update", "type": "text"}]}, {"type": "bulletList", "attrs": {"dir": "auto"}, "content": [{"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "jjtfcejlvzgl", "dir": "auto", "indent": 0}, "content": [{"text": "All installation and minor corrections from the previous session have been completed", "type": "text"}]}]}, {"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "ervmktekisdw", "dir": "auto", "indent": 0}, "content": [{"text": "Current goal: build a solid foundation for each component — somewhere between a POC and MVP — before moving to sprints", "type": "text"}]}]}, {"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "euimpbvfomqh", "dir": "auto", "indent": 0}, "content": [{"text": "Code is being documented incrementally via PRs", "type": "text"}]}]}, {"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "ovkivndmcdkt", "dir": "auto", "indent": 0}, "content": [{"text": "Two complementary secondary tracks defined: ", "type": "text"}, {"text": "Track A", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}, {"text": " (secure technical environment) and ", "type": "text"}, {"text": "Track D", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}, {"text": " (measure, test, and optimize performance)", "type": "text"}]}]}]}, {"type": "heading", "attrs": {"id": "qigvrpjrbett", "dir": "auto", "level": 3, "indent": 0}, "content": [{"text": "Objectives Review (Student Guide)", "type": "text"}]}, {"type": "bulletList", "attrs": {"dir": "auto"}, "content": [{"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "mmgssvzzrgsf", "dir": "auto", "indent": 0}, "content": [{"text": "The supervisor noted the team was not sufficiently familiar with their formal TRAC objectives and stressed the need to know them precisely", "type": "text"}]}]}, {"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "gdzcgruglzko", "dir": "auto", "indent": 0}, "content": [{"text": "Mandatory Objective 1:", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}, {"text": " Organize and conduct a technological watch (Veille Techno) to identify and address the project's \\"hard point\\" — due end of October", "type": "text"}]}, {"type": "bulletList", "attrs": {"dir": "auto"}, "content": [{"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "etfafmusvwwu", "dir": "auto", "indent": 0}, "content": [{"text": "Team has not yet clearly identified the hard point", "type": "text"}]}]}, {"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "vbmaqpcmhpqd", "dir": "auto", "indent": 0}, "content": [{"text": "Approach: weekly research sessions → test tracks (POC) → document outcomes → determine if/how they integrate into the project", "type": "text"}]}]}, {"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "fdfwazjstgkh", "dir": "auto", "indent": 0}, "content": [{"text": "Documents must be produced and ready to justify the Veille Techno at the go/no-go", "type": "text"}]}]}]}]}, {"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "yuddjmweyhrm", "dir": "auto", "indent": 0}, "content": [{"text": "Mandatory Objective 2:", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}, {"text": " Structured, documented, and reliable architecture — includes architecture diagrams, CI/CD, test plans", "type": "text"}]}, {"type": "bulletList", "attrs": {"dir": "auto"}, "content": [{"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "czkxywlqjffu", "dir": "auto", "indent": 0}, "content": [{"text": "Documentation must be purpose-aware: distinguish between docs for users, admins, and researchers", "type": "text"}]}]}]}]}, {"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "dhcssbplwklp", "dir": "auto", "indent": 0}, "content": [{"text": "Complementary Objectives (A & D):", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}, {"text": " Match the two secondary tracks already chosen; for Track D, measurement must lead to analysis, modification, and re-measurement — not just a one-time metric", "type": "text"}]}]}, {"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "muverkqroatr", "dir": "auto", "indent": 0}, "content": [{"text": "The Student Guide also contains a list of required deliverables — team was reminded to consult it", "type": "text"}]}]}]}, {"type": "heading", "attrs": {"id": "crcycsdnmtil", "dir": "auto", "level": 3, "indent": 0}, "content": [{"text": "Working Methods & Team Organization", "type": "text"}]}, {"type": "bulletList", "attrs": {"dir": "auto"}, "content": [{"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "evhxmesxwirx", "dir": "auto", "indent": 0}, "content": [{"text": "Team works asynchronously with assigned tasks; code reviews are done by peers", "type": "text"}]}]}, {"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "bifqyrestvtg", "dir": "auto", "indent": 0}, "content": [{"text": "Occasional joint Discord work sessions are held; working hours are shared so others can join", "type": "text"}]}]}, {"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "rgoqypjsnyxg", "dir": "auto", "indent": 0}, "content": [{"text": "A weekly weekend synchro point already exists, but only 3–4 members typically attend", "type": "text"}]}]}, {"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "keubncfczuqg", "dir": "auto", "indent": 0}, "content": [{"text": "Supervisor emphasized the importance of a more rigid work framework given the fully remote, multi-country setup, and the natural tendency to deprioritize the project", "type": "text"}]}]}]}, {"type": "heading", "attrs": {"id": "wceqcjukpcnn", "dir": "auto", "level": 3, "indent": 0}, "content": [{"text": "Supervisor Feedback & Next Steps", "type": "text"}]}, {"type": "bulletList", "attrs": {"dir": "auto"}, "content": [{"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "bpbpdssfvybm", "dir": "auto", "indent": 0}, "content": [{"text": "The team jumped into tools (Jira) before explaining goals and direction — the supervisor asked for a clearer narrative: objective → approach → implementation", "type": "text"}]}]}, {"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "miwznpcdvfvx", "dir": "auto", "indent": 0}, "content": [{"text": "For the next meeting, the team should present: action plans per objective, a clearer work schedule, and demonstrate they know their objectives", "type": "text"}]}]}, {"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "lyarvzprxatq", "dir": "auto", "indent": 0}, "content": [{"text": "The supervisor is available for async questions via the existing Discord channel", "type": "text"}]}]}]}, {"type": "heading", "attrs": {"id": "vrroqtpssaes", "dir": "auto", "level": 1, "indent": 0}, "content": [{"text": "Transcript", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}]}, {"type": "paragraph", "attrs": {"id": "fhkhkljttfkx", "dir": "auto", "indent": 0}, "content": [{"text": "Hello? Can you hear me?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "yzmroviwngef", "dir": "auto", "indent": 0}, "content": [{"text": "I would have taken it off Discord. Oh wow, wait, why? Ah yes, you have to take it off Discord for that.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "oebkvhaorryk", "dir": "auto", "indent": 0}, "content": [{"text": "Hello. Hello.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "sbeompimdiam", "dir": "auto", "indent": 0}, "content": [{"text": "Up.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "omteqsaxjhcb", "dir": "auto", "indent": 0}, "content": [{"text": "Kavaizhu! Very well, thank you. Yes, I may have been connected a little early, you may have wanted to discuss before I arrived. No, but tell me. There's no problem, I'll take it quite well.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "czkgjecyxdnb", "dir": "auto", "indent": 0}, "content": [{"text": "No, you're about to do it.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "vbzitfcxfduj", "dir": "auto", "indent": 0}, "content": [{"text": "Don't worry. I saw that you sent me the document. In the conversation, the little preparation there? Thank you very much. It's very good, it allowed me to start filling things up.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "qsydtzxnxqhh", "dir": "auto", "indent": 0}, "content": [{"text": "Yes, that's it.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "qdtsyyaaglrt", "dir": "auto", "indent": 0}, "content": [{"text": "Let's see.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "kkpanpqrksgk", "dir": "auto", "indent": 0}, "content": [{"text": "It will save us a lot of time.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "chdticknbryr", "dir": "auto", "indent": 0}, "content": [{"text": "Thank you. Is the others here?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "logkknpadrof", "dir": "auto", "indent": 0}, "content": [{"text": "They haven't answered yet.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "vioilvvzsdag", "dir": "auto", "indent": 0}, "content": [{"text": "Okay. That's perfect.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "rkzdytosmvwk", "dir": "auto", "indent": 0}, "content": [{"text": "For now, there are only four. There's no Ibrahim, Angel... And Alexandra.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "wnnquudrgxai", "dir": "auto", "indent": 0}, "content": [{"text": "So Alexandre is busy. So, Alexandre, will you come back? No, Alexandre is not sure because he's sick. We don't know if he's coming or not. We're a bit waiting for it.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "oczznwfudaqr", "dir": "auto", "indent": 0}, "content": [{"text": "I'll let you know, and if he comes, you'll let me know.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "oybmnxzqtity", "dir": "auto", "indent": 0}, "content": [{"text": "Okay.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "jyiaeqrpmbur", "dir": "auto", "indent": 0}, "content": [{"text": "Angel Angèle will arrive in a minute.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "qesvhnkfrmmd", "dir": "auto", "indent": 0}, "content": [{"text": "Ibrahim won't arrive.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "horjpineyeme", "dir": "auto", "indent": 0}, "content": [{"text": "Brahim, I won't see you. Okay.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "hfkcdwpclufl", "dir": "auto", "indent": 0}, "content": [{"text": "I take this opportunity to make the adjustments. Oh, Boop, boop, boop. I think Ibrahim already liked it.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "vhmgeyrtzzlc", "dir": "auto", "indent": 0}, "content": [{"text": "Yeah. It's very possible.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "bvjystcxdtre", "dir": "auto", "indent": 0}, "content": [{"text": "My camera is not detected on Ubuntu, so I think I'll have to restart my computer.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "ntavdmobfucc", "dir": "auto", "indent": 0}, "content": [{"text": "Go ahead, we have time while I take care of that. So, indeed, Ibrahim, I don't have it. I have Elia, Sanjo, Angel, Lucas and Alexandre. OK. Well, Ibrahim, are we going to take it out of the meeting?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "blsrpuqwstjq", "dir": "auto", "indent": 0}, "content": [{"text": "This is Shri Mataji: Sh Okay.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "wrlllrwybzmi", "dir": "auto", "indent": 0}, "content": [{"text": "Sorry, I'm back with you. So where is Alexandre Paula? C'est tout. Okay. Great. So, we only miss Alexandre, since Angel is here. What I propose is that you start by reminding me in one sentence your project. the goal of the project, so that it allows us to be sure, to remember to remind me of your project and then talk about your progress and then we will work on the objectives. Is everyone okay?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "twioinvkqapn", "dir": "auto", "indent": 0}, "content": [{"text": "It's perfect.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "uwajzakkxwiu", "dir": "auto", "indent": 0}, "content": [{"text": "Where's the bucket?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "ygoajvndojnu", "dir": "auto", "indent": 0}, "content": [{"text": "Wait.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "ipfysmtrpvzn", "dir": "auto", "indent": 0}, "content": [{"text": "Okay, great. Wait, just a second.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "pnzpmhxpvdvi", "dir": "auto", "indent": 0}, "content": [{"text": "You just woke up, Angel. you It's 7:30, Pity. I went to bed at 3 or 4 o'clock.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "xusskevwqgrw", "dir": "auto", "indent": 0}, "content": [{"text": "Go ahead, I'm listening. Hello? I look at my loss. Great. Yeah, not very strong, but... Wow.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "ogfjjzbawxjg", "dir": "auto", "indent": 0}, "content": [{"text": "Is it better like that?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "koogadbppumk", "dir": "auto", "indent": 0}, "content": [{"text": "Yes, much better. Perfect.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "kpkkvrnfmiwo", "dir": "auto", "indent": 0}, "content": [{"text": "-Let's see it again soon.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "cimhdwnzyiyo", "dir": "auto", "indent": 0}, "content": [{"text": "No.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "yjjfdhjijkow", "dir": "auto", "indent": 0}, "content": [{"text": "If you want, I can do it.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "prhzmomqamgs", "dir": "auto", "indent": 0}, "content": [{"text": "Right. So, \\"Consoré\\" is a project aimed at helping neurotypical people We are going to have a sort of introduction to everything that is digital life. and all that is around us, rather digital autonomy. In a sentence...", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "lsaksirpuyap", "dir": "auto", "indent": 0}, "content": [{"text": "Okay.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "dpalmsminlio", "dir": "auto", "indent": 0}, "content": [{"text": "So, tell me about your progress.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "bipspnlgumpe", "dir": "auto", "indent": 0}, "content": [{"text": "to allow everyone to follow what everyone is doing. What else? People can addWe have the development of the backend, we have the development of the frontend, I don't know if Elias already started. We have the loader, I don't know. des jours. Do you have something to add?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "adcwipsgezjf", "dir": "auto", "indent": 0}, "content": [{"text": "Thank you.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "uqtosocjawqi", "dir": "auto", "indent": 0}, "content": [{"text": "you I will define it again, on the Jira side, we have finished all the installation and minor corrections that there were compared to the last time.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "llbyncjjilzt", "dir": "auto", "indent": 0}, "content": [{"text": "Your SUI seems really well prepared. I don't know, people, is there anything to add? Put yourself in my shoes, I just want to go do something else.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "qkfrvxfziwqr", "dir": "auto", "indent": 0}, "content": [{"text": "But wait, we were talking about Jira, but maybe we should put it back in context.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "fpxehcqhspxa", "dir": "auto", "indent": 0}, "content": [{"text": "Jira, what is it for? Why? Where is your project? I have a little trouble understanding.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "xiiwaqedonmj", "dir": "auto", "indent": 0}, "content": [{"text": "I will let Angèle talk about Jiraz, he is the one who is mainly busy.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "evwnxbfgppcc", "dir": "auto", "indent": 0}, "content": [{"text": "you Is this. Is it possible to share the screen so you can see better?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "mpojktpewqan", "dir": "auto", "indent": 0}, "content": [{"text": "Yes, of course.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "rywwbbwmxvma", "dir": "auto", "indent": 0}, "content": [{"text": "So I'll do that for you. But if you want, before talking to me about Jira, It would be nice to talk a little bit about what you have done, your goals, where you are going, to structure a little bit. I mean, you remind me of a guy who builds a car and you're explaining to me that you grind rubber but at the end of the day I understand that you want to make a tire. Okay.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "qevulbhlpiem", "dir": "auto", "indent": 0}, "content": [{"text": "So, we started with the technical work, as you know, and the last time, two weeks ago, we didn't really have any secondary tracks yet. We defined our two secondary tracks, A and D, We found it consistent with the technical treatment. a more secure technical environment, so to protect and ensure that this environment So, it's the secondary track A. and the D secondary track which is measure, test and optimize the performance of our in the project.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "gfxsmnlmgixe", "dir": "auto", "indent": 0}, "content": [{"text": "We did these two tracks in secondary school because we found it quite common with a technical project. And for the other tracks, maybe we can work on it too. We'll see because it's often communication tracks that we've seen. It's something that we'll have to come up with later. But for now, we don't find it really important to do the follow-up every two weeks. We preferred to take these tracks. So to do this, we use a follow-up tool called Jira.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "zgpzoupvrltk", "dir": "auto", "indent": 0}, "content": [{"text": "We didn't choose GitHub Project because Personally, I preferred to use Jira. It's a tool that I used a lot during my training in management of projects and others. That's why we started on Gira on this project and it was approved by our DPR. I'll show you what it looks like.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "lacvfbwhkonr", "dir": "auto", "indent": 0}, "content": [{"text": "So the giraffe is for the... It's for the complementary objective number 1.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "yewbeetoqrwq", "dir": "auto", "indent": 0}, "content": [{"text": "You It was about identifying the problem and it was about defining the architecture and having a sort of reliable architecture.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "vbbpzwbhzztq", "dir": "auto", "indent": 0}, "content": [{"text": "Also, that's it. But it's a kind of management tool, just for task development. It's quite basic. It's a bit like a GitHub project. Disqcc is a ticketing tool that allows you to organize yourself in a group. They can't worry about San Lucas.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "aneinfgacqjr", "dir": "auto", "indent": 0}, "content": [{"text": "you Okay.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "uxoivpmhjzws", "dir": "auto", "indent": 0}, "content": [{"text": "I'll quickly show you what it looks like.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "mtfippczvvbv", "dir": "auto", "indent": 0}, "content": [{"text": "I imagine you know me, but that's it. No, Lizzie. What matters to me is to understand that it's not so much the tool itself, Hmm? What matters to me is What have you done? Where are you going? What are the working methods? What are your objectives? How do you work? I don't care if you use Jira, GitHub, whatever you want. But today, we didn't even talk about where you're going, you're throwing Jira at me. Thank you. You see what I mean?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "jqbaousybvqt", "dir": "auto", "indent": 0}, "content": [{"text": "I think the first thing would be to say, well, here we are, we have such an objective to achieve. To achieve this objective, we have to do this, this, this and that. To do this, this and that, we are going to organize ourselves in such and such a way. And that's what we're going to put in place. Okay. So, you chose to help, that's good. It seems to me, given your project, it doesn't seem like a big deal.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "oerswbwbvkgm", "dir": "auto", "indent": 0}, "content": [{"text": "Then, actually, explain why. Well, very well. And then say, OK, now that we've chosen that, what are we going to put in place to meet the objectives? Thank you.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "jszdupeeslcc", "dir": "auto", "indent": 0}, "content": [{"text": ". For now, we haven't decided to go by a sprint system because we plan to go by sprints, but the current one, the one that will probably come soon. But personally, and even for the whole, we chose to do that because we all arrived in our country, settled in, we started classes and all. We don't all necessarily have the same availability and other things. And so, what we did was to have a The main task is to create a solid foundation.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "zskdeednjnuj", "dir": "auto", "indent": 0}, "content": [{"text": "A technical project, so at least having a MVP on each side, not necessarily a MVP, between the POC and the MVP, that is to say, something that works right to left everywhere a solid base is enough on each on for each part, so on the backend, the dashboard, the launcher, all these parts? Once this is done, during the coming month, we will set up sprints to work on it and then we will have a more regular follow-up on that.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "dbtupurzamhm", "dir": "auto", "indent": 0}, "content": [{"text": "So everyone must build a baseThat's it.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "ccdguetkhxqd", "dir": "auto", "indent": 0}, "content": [{"text": "Between POC and MVP, MVP is pretty good, I think. But it's a bit between the two.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "uurodcfmlyxj", "dir": "auto", "indent": 0}, "content": [{"text": "No, go ahead. So, that means you identified the parties? This is her. So what are these parties?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "zmzleahsemha", "dir": "auto", "indent": 0}, "content": [{"text": "So, we have some parts. We have the basin, so here there will be uh all our... like API and others, so it's kind of our foundation. And this... We have the dashboard, which is more superficial, it's the web part where the helpers will connect. It's a slightly separate part, whether it's a track or a backing track. Then we have the launcher, Elias is taking care of it for now. um, For now, it's three big parties that connect to each other.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "ugkwpjtppomy", "dir": "auto", "indent": 0}, "content": [{"text": "And then there might be other things that will come over it, but that's not right now. So, that's it. We're going to say that's three big parts for now.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "mcxdycbcmlsx", "dir": "auto", "indent": 0}, "content": [{"text": "Backend, Dashboard and Launcher. That's right. Oh That works. Okay. For now, on the mandatory objectives, you have advanced?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "gdmnswwjtcbq", "dir": "auto", "indent": 0}, "content": [{"text": "uh We continue when everyone works on our side, we document our part of the code. We try to make some PR issues, but each time the part of the code is a little documented at least. And we're trying to document it as best we can for now.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "cyrplhaqycmu", "dir": "auto", "indent": 0}, "content": [{"text": "Wait, we may not have understood. What are the mandatory objectives for you?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "qkntwnkehika", "dir": "auto", "indent": 0}, "content": [{"text": "the So Um But I don't.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "crrsxjxbpaor", "dir": "auto", "indent": 0}, "content": [{"text": "moi j'ai pas ce qui me dérange c'est là comment dira the approximate number of your answers I mean, the objectives of TRAC, mandatory, complementary and so on, it must be something precise. You don't have to tell me, I think the objectives are about that. I mean, tonight, the French team at the Stade de France, they know where they have to score the goal. yeah the wall foot rebound maybe we have to move the ball forward towards the oh shit You have a document Student Guide, okay?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "yxtkctkmtvxb", "dir": "auto", "indent": 0}, "content": [{"text": "In which there are objectives and you are told if you don't have the objective, you won't have your IP. You have to read them, know them. I tell you, what is your objective that we can... mandatory number one, you tell me, yeah, that's it. You should know it and you should have already started working on it. Okay? Huh? Knowing that the last time I made you notice that you hadn't read the guide and that you absolutely had to read it.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "xmlyoqfdmxeu", "dir": "auto", "indent": 0}, "content": [{"text": "Okay. Anyway. I'm a little annoying you there because if there is no one who moves you, you understand what I mean. We have to read together the objectives, that you are very clear with that and that you realize them. Do you have the document under your eyes? Uh, we. So it's Student Guide. So share it so that we can all agree on what we read.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "gmhjozsgqbvx", "dir": "auto", "indent": 0}, "content": [{"text": "Allez-y.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "yotcjjtqwrls", "dir": "auto", "indent": 0}, "content": [{"text": "You can do it. Go ahead.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "kfcqoijivptl", "dir": "auto", "indent": 0}, "content": [{"text": "Oh you I don't know how to do it.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "gontppvzkvdn", "dir": "auto", "indent": 0}, "content": [{"text": "I'll be right back while you share. I'm coming. Go ahead, go ahead.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "ztqtetmwgieg", "dir": "auto", "indent": 0}, "content": [{"text": "I was thereYeah.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "hyfemnicmwzh", "dir": "auto", "indent": 0}, "content": [{"text": "It's just that...", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "pavordwshtja", "dir": "auto", "indent": 0}, "content": [{"text": "Yeah, for the screen.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "vgpbhjkrewmx", "dir": "auto", "indent": 0}, "content": [{"text": "So that's not it.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "mwsrmzbimpiu", "dir": "auto", "indent": 0}, "content": [{"text": "That's the second one.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "jhicdwquomwr", "dir": "auto", "indent": 0}, "content": [{"text": "Perfect. What? That's the first objective. What?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "neyswqortllu", "dir": "auto", "indent": 0}, "content": [{"text": "And so... Before the end of October, we had the problem characterization. Yeah, hard point.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "jhdtxpopdkqv", "dir": "auto", "indent": 0}, "content": [{"text": "That's it. In French, the number one objective is to organize your technological wave and exploit it to lift the hard point. project Okay. What?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "obveykuxvqna", "dir": "auto", "indent": 0}, "content": [{"text": "Put it here.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "nusqvzamlfnh", "dir": "auto", "indent": 0}, "content": [{"text": "Key.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "eksteidxvqhg", "dir": "auto", "indent": 0}, "content": [{"text": "Hello.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "giodsqjulaqz", "dir": "auto", "indent": 0}, "content": [{"text": "Do you have an idea of what could be the hard part of your project today? Do you have an idea of how to make the Veil Techno?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "vqisydcxmmfi", "dir": "auto", "indent": 0}, "content": [{"text": "No, not really.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "gpnmuwpzildw", "dir": "auto", "indent": 0}, "content": [{"text": "I'm sorry. It's complicated to define. There's a visualizer There's a visualizer Okay, we're all...", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "cltbtxjlhkmk", "dir": "auto", "indent": 0}, "content": [{"text": "So, for the hard point, I can't help you. I could, but I don't want to. First, it's up to you to do it. Oh. Organizing this technology Thank you. Oh. To organize the technical day, what I advise youYeah. See? But You ask the questions. As usual, it's the old technology. How are we going to do it? How much time will we spend on it? What do we want to get out of it? How will she be able to help us in the project? Okay? Where does it integrate, etc.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "opwbehmyiypi", "dir": "auto", "indent": 0}, "content": [{"text": "So the idea is to say you are five, You will say, \\"OK, per week, everyone spends an hour of Veille Techno.\\" During this hour, we do research. At the end of this hour, Identify the tracks. Yes, we remove the track, we test it, we do a POC. Yes, it works. No, it doesn't work. We don't remember the track, we don't remember it for this reason. After the POC, is it useful? Is it not? If it's useful, where will it go in the project?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "pdmwqceftbyr", "dir": "auto", "indent": 0}, "content": [{"text": "All of this must be consigned, make documents Produce these documents because that's what we're asking you for. We're going to ask you to justify your technological advance. We're not going to ask you to do it, we're going to ask you to justify it.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "dadcblkplpot", "dir": "auto", "indent": 0}, "content": [{"text": "So, these documents, for example, Did they get you to do it?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "eptusjzcllpz", "dir": "auto", "indent": 0}, "content": [{"text": "All the weeks? We just keep them on the side to prove it.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "jybaremzpbwq", "dir": "auto", "indent": 0}, "content": [{"text": "Ah no, I mean, yes, we will discuss it together, that's the goal of our meetings, okay? So you can give them to us in advance and so on, that's the goal of our rendezvous. But above all, we're going to have to produce them on the day of the go-no-go. Thank you.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "gpuvxpoxkopr", "dir": "auto", "indent": 0}, "content": [{"text": "OK, so that's how you have to lead your your techno watch. You have to produce. Searching. Verify. Considere. Okay.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "imeilbijsvye", "dir": "auto", "indent": 0}, "content": [{"text": "Okay.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "vxfcesgojonx", "dir": "auto", "indent": 0}, "content": [{"text": "Let's go.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "sqwucikppakv", "dir": "auto", "indent": 0}, "content": [{"text": "to And for the second objective, which was also supposed to be at the end of October, So, the search for setups.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "jfflzzwfkttn", "dir": "auto", "indent": 0}, "content": [{"text": "So that in my opinion is not the second objective. You mix everything, you have to be super precise when you talk. That's not the second objective, we're still in the first one. What? Yes, if you tell me second objective, I think of second objective of TRAC. Your second goal is to Structured, documented, and reliable. Okay? So that's going to be everything that is architecture diagrams. documentation, CI/CD, test plan, etc.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "vyywlranysmk", "dir": "auto", "indent": 0}, "content": [{"text": "Chip. Okay. When we do doc, we ask ourselves why we did it, what we do, how we did it.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "loffrtiulqeq", "dir": "auto", "indent": 0}, "content": [{"text": "Okay.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "uebxcghxfvmb", "dir": "auto", "indent": 0}, "content": [{"text": "Okay? It's not the same as doing A tutorial? for a user, to do a man for an administrator or to do an article for a researcher. No doubt.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "lxzzbsmicnhy", "dir": "auto", "indent": 0}, "content": [{"text": "Look at that guy.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "wzglvwqpscrg", "dir": "auto", "indent": 0}, "content": [{"text": "So you think aboutYou think about the different types of docs. different types of people and how it matches.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "varvifgvixuv", "dir": "auto", "indent": 0}, "content": [{"text": "Okay, that works.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "adziqimbgcjp", "dir": "auto", "indent": 0}, "content": [{"text": "Is that good for you? -Same thing, on the complementary objectives, the two there. Measure, test, optimize. Okay. Same thing, reflection on What do we set up? What do we want to measure? Once we have measured it, we analyze it.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "vpmhpjbwspek", "dir": "auto", "indent": 0}, "content": [{"text": "I got it.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "dfakgsgqstab", "dir": "auto", "indent": 0}, "content": [{"text": "we modify and we reanalyze. It's not just that we measured it, we're happy. 1.12 meters, great. No. We measure something, we deduce performance problems or not, we say, \\"Here, we're going to modify this thing\\" and we measure again.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "bqpilncxthec", "dir": "auto", "indent": 0}, "content": [{"text": "There we go.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "yjdipjzwvcyg", "dir": "auto", "indent": 0}, "content": [{"text": "Okay, is that good for you?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "bthqvjrsjuod", "dir": "auto", "indent": 0}, "content": [{"text": "So So What the...", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "sjogajckmiti", "dir": "auto", "indent": 0}, "content": [{"text": "Wait what? Once again, you have to read the objectives and then tell yourself what to expect, what to expect as an output, what to do. For whom should I do it? Thank you. um In this document, you have the list of supplies to supply. Think about looking at it. Okay. Do you have any organization problems in the group? Given the distance, where are you currently?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "zsohbkwctjfa", "dir": "auto", "indent": 0}, "content": [{"text": "We have one in Germany, in Berlin, two in Ireland. Dukas and Alexandre are not there, in Germany we have Enzo, in Sweden we have Elias and I am in Canada.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "srtprhcxpuox", "dir": "auto", "indent": 0}, "content": [{"text": "Yes, that's it: Sweden, Berlin, Dublin and Quebec. And you are Epitech Montpellier?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "qszoeowesgrk", "dir": "auto", "indent": 0}, "content": [{"text": "Montpellier, in Paris.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "bddpzwuthtgj", "dir": "auto", "indent": 0}, "content": [{"text": "Yeah. Yeah, Montpellier, Paris, that's it?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "clliqglbxzaj", "dir": "auto", "indent": 0}, "content": [{"text": "Alexandre, he comes from Paris. That works.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "yyifrukigrgu", "dir": "auto", "indent": 0}, "content": [{"text": "OK. Before I forget, do you have an idea for the next meeting? So, theoretically, it should be the week of October 19th.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "ufxrsunhwevr", "dir": "auto", "indent": 0}, "content": [{"text": "I'm so serious. Ms. Exxon. We're all starting to have our final moments. In any case, this is the case for Alexandre-Emer. We are beginning to have our time for the definitive. And on October 19, It's not a test period for me, so I'll have a lot of free time. Okay. I would like to do less this week, because it's a week of exams, of mid-sessions. Thank you. I have an exam every day on this week.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "gpuadmsygqry", "dir": "auto", "indent": 0}, "content": [{"text": "So if we do Friday 16th, It's been two weeks instead of three. Hmm.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "pjxtxlwahzyd", "dir": "auto", "indent": 0}, "content": [{"text": "But I haven't done anything this week. I don't mind. Friday, 16, I'm fine. I'm fine with that too.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "orntwofrrpoo", "dir": "auto", "indent": 0}, "content": [{"text": "Pokemon was it?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "bwbgivzsaktu", "dir": "auto", "indent": 0}, "content": [{"text": "Yes, there is no problem.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "padtwptoirlu", "dir": "auto", "indent": 0}, "content": [{"text": "What?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "ssiwbwvcnaqp", "dir": "auto", "indent": 0}, "content": [{"text": "Yes, I think so.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "dgghtdqkqdxj", "dir": "auto", "indent": 0}, "content": [{"text": "We plan the arrival. Do you prepare the thing like last time? Thank you. Okay. Are you preparing for the meeting?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "otvnpznnsdfn", "dir": "auto", "indent": 0}, "content": [{"text": "It works.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "ojepcgiselqx", "dir": "auto", "indent": 0}, "content": [{"text": "The guest and everything, that's good?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "ginzxjuibdik", "dir": "auto", "indent": 0}, "content": [{"text": "It's good, we invite you both.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "egptvnzfmgyj", "dir": "auto", "indent": 0}, "content": [{"text": "What is it?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "zqyfvwlcxzdg", "dir": "auto", "indent": 0}, "content": [{"text": "It works, great. Okay, okay, okay. -Uh... Tuk, tuk, tuk. Okay. I would like to come back to your working methods. but How are you currently working together?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "lyjtkveziijz", "dir": "auto", "indent": 0}, "content": [{"text": "We all feel a bit at home, we have our tasks, we are assigned, we work on them. And then we do the reviews that are not done by other people. Or sometimes we do sessions together in We have a Discord and we get into it. We work from 2 to 3, and then he comes when he wants to work. Sometimes we do sessions like that.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "doaxqghdoegv", "dir": "auto", "indent": 0}, "content": [{"text": "We talked about it with Lucas to complete what he said. We try to put together mandatory meetings but most of the time we give our working hours that we are going to do and we try to see with people who can come etc.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "vxapsdlylejy", "dir": "auto", "indent": 0}, "content": [{"text": "It's to motivate. But then there are people who will have to work together because they will do similar tasks or in the same field. And in this case, we will try to send messages, either on Discord or even on WhatsApp to try to organize and find a time frame in which we will be able to work together.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "vrqkryykpuzi", "dir": "auto", "indent": 0}, "content": [{"text": "Thank you. Ok, we should add a synchro point, an abdominal one, I think. At the beginning. Hm? That is to say, Once a week, even if it's only 15 minutes, 20 minutes, half an hour, the whole group meets to say: \\"This is what we did this week on the OIB.\\" Not necessarily work sessions, but at least synchro points.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "vwxemlrqycuu", "dir": "auto", "indent": 0}, "content": [{"text": "Yeah, we already have one per week. We already know what to do.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "eizewnhhixrz", "dir": "auto", "indent": 0}, "content": [{"text": "Yeah, no, but do you hold on to it?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "tulsvpntzbwm", "dir": "auto", "indent": 0}, "content": [{"text": "Yes, we do it on weekends. I'm so convinced by the... Thank you. We are all available, so we can do it.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "kavdpoxgvois", "dir": "auto", "indent": 0}, "content": [{"text": "So there you have a synchro point. You have a synchro point, Hebdo? Bye.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "cekdtzbacszs", "dir": "auto", "indent": 0}, "content": [{"text": "We're not all in it. We're four in it, in general. Three, four in it. We should all be in it, that's the problem. Yeah, yeah. I understand, but... It's hard to manage to rally everyone at the same time, but it should be. I'm on the same campus as him, so I see him quite regularly. He doesn't share with everyone. I have news about what he's doing and if he advances on the IP. It's not ideal, but I think he had problems for the IP.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "ymbedabwwcfm", "dir": "auto", "indent": 0}, "content": [{"text": "his apartment and well, he's sick but I see it at least twice a week.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "fikcqsypsfqb", "dir": "auto", "indent": 0}, "content": [{"text": "Okay. Let's hope it doesn't count. So for the next time, I would really like you to offer me action plans. So, on the objectives.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "ojwfckqkustz", "dir": "auto", "indent": 0}, "content": [{"text": "okay Thank you.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "xpwhnnxptskv", "dir": "auto", "indent": 0}, "content": [{"text": "And maybe a point on your work organization?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "fkrjowfsoigg", "dir": "auto", "indent": 0}, "content": [{"text": "So, to be more precise, how do we work?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "fkzfodlpfzci", "dir": "auto", "indent": 0}, "content": [{"text": "Yeah, let's say you answer me because you say if I don't answer, he's going to leave every weekend, that's nice, but... I don't have the impression that there is a... When we are all at a distance, it is really important to have a framework of work that is a little more rigid than when we see each other. When we see each other, we can remember each other. Hmm. If I decide not to hang up or if for example a video conf I do not put my camera I can do a lot of things.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "tihglurgykal", "dir": "auto", "indent": 0}, "content": [{"text": "If I shout at you you can turn down the sound, etc. It's not the same as when you see yourself in real life. If we are in a room and I start to hit you hard, you will feel very It's different from if you're on a screen and you're rolling on it. Well, it's the same for you, actually. It's the same between you. So, in a lesser extent, but you feel less pressure, there will always be something more important or more interesting to do than the IP, which is quite normal.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "wbzvhtwhoqsp", "dir": "auto", "indent": 0}, "content": [{"text": "So it's important to remember very regularly that you have to do the IP, knowing that it is not the most important thing in a life. That's not what I'm saying. Of course, but it has its importance and so it's important to remember it regularly, okay?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "wvyblduqfurb", "dir": "auto", "indent": 0}, "content": [{"text": "Okay.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "bnafsumxvmzg", "dir": "auto", "indent": 0}, "content": [{"text": "Thank you. Voilà.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "qgpflkfphuio", "dir": "auto", "indent": 0}, "content": [{"text": "Okay.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "fpjbbqrfbacw", "dir": "auto", "indent": 0}, "content": [{"text": "To the best of their ability, once again. It's not the most important thing in a life, but it's important.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "ozxmvklugrec", "dir": "auto", "indent": 0}, "content": [{"text": "Thank you. So, I would like a point on your work schedule a little more provided, okay? Thank you. No, sir. It works, we're not bad here. And then above all, I insist, an action plan on the objectives, a clear vision. Michael? Where do we want to go?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "azxwfuwgcfek", "dir": "auto", "indent": 0}, "content": [{"text": "Okay.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "vpwtmqeaaxbb", "dir": "auto", "indent": 0}, "content": [{"text": "How do we want to do it? And when? We will do it. Cheers. Okay. OK. Yeah.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "fykvssypkkhv", "dir": "auto", "indent": 0}, "content": [{"text": "Okay?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "qnhiahxsqsgi", "dir": "auto", "indent": 0}, "content": [{"text": "Yeah.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "gzcqbkjmmndu", "dir": "auto", "indent": 0}, "content": [{"text": "Do you have any questions? Complaints, comments, criticisms, do not hesitate.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "gbiuptwczlyg", "dir": "auto", "indent": 0}, "content": [{"text": "No, so... I don't have that many complaints. On the contrary, I like the fact that that things are said suddenly because it allows us to move forward more than we think, which is not going directly. I prefer to serve.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "obzdinuxdxkg", "dir": "auto", "indent": 0}, "content": [{"text": "So the big interest is that I'm just here to help you. So... We can tell each other things. I won't write you down. There's no note. So, we can say things to each other. On the contrary. It's the main thing. Okay? My goal is that you do your best.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "dfcdhkktphpl", "dir": "auto", "indent": 0}, "content": [{"text": "Thank you.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "ggcgxdxebpjg", "dir": "auto", "indent": 0}, "content": [{"text": "Thank you anyway.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "xtxvbvrmeued", "dir": "auto", "indent": 0}, "content": [{"text": "Okay, that's my only goal. Okay. So you do a loop on all the objectives If you need, you can send me a message from time to time to tell me: \\"We saw this, what do you think about it?\\" It doesn't cause me any problem. Okay.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "wlyukqnktodj", "dir": "auto", "indent": 0}, "content": [{"text": "On this channel?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "meckakrisgdz", "dir": "auto", "indent": 0}, "content": [{"text": "Yes, on this channel. We keep this room, so we have all the history there. If we start talking 5 or 6 times, we can't get out of it. Okay?", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "jcdxqlmizkqn", "dir": "auto", "indent": 0}, "content": [{"text": "Okay.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "daynvnlpalsz", "dir": "auto", "indent": 0}, "content": [{"text": "Okay.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "qkguipnjupmn", "dir": "auto", "indent": 0}, "content": [{"text": "Okay, perfect.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "harnunnhtbgo", "dir": "auto", "indent": 0}, "content": [{"text": "If you don't have any other questions, that's good for me. Okay.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "bqpjhxammvin", "dir": "auto", "indent": 0}, "content": [{"text": "I don't think we can.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "zzobqvvlhobv", "dir": "auto", "indent": 0}, "content": [{"text": "We'll plan it.", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "krxbirmgnvez", "dir": "auto", "indent": 0}, "content": [{"text": "Okay, it works. Thank you. And of course, don't hesitate. rightThank you.", "type": "text"}]}, {"type": "bulletList", "attrs": {"dir": "auto"}, "content": [{"type": "listItem", "attrs": {"dir": "auto"}, "content": [{"type": "paragraph", "attrs": {"id": "pvecfwgvhfov", "dir": "auto", "indent": 0}}]}]}, {"type": "paragraph", "attrs": {"id": "txdzmiyyvpth", "dir": "auto", "indent": 0}, "content": [{"text": "Have a good day. Thank you. you", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "breyitelarnb", "dir": "auto", "indent": 0}}, {"type": "paragraph", "attrs": {"id": "yhfpdiapsggy", "dir": "auto", "indent": 0}, "content": []}]}	\\x020ba993a781030087a4d7a7a402bcc80103097061726167726170682100a993a7810300026964012800a993a781030006696e64656e74017d002800a993a7810300036469720177046175746fa8a993a781030101770c627265796974656c61726e6287a993a781030003097061726167726170682800a993a781030502696401770c7968667064696170736767792800a993a781030506696e64656e74017d002800a993a7810305036469720177046175746f0700a993a7810305060100a993a781030904e20ba4d7a7a4020001010764656661756c7401000b87a4d7a7a40200030768656164696e670700a4d7a7a4020c060400a4d7a7a4020d0c416374696f6e204974656d732800a4d7a7a4020c02696401770c6362706d706b7367776b76622800a4d7a7a4020c06696e64656e74017d002800a4d7a7a4020c036469720177046175746f2800a4d7a7a4020c056c6576656c017d0387a4d7a7a4020c03087461736b4c6973740700a4d7a7a4021e03087461736b4974656d0700a4d7a7a4021f03097061726167726170680700a4d7a7a40220060400a4d7a7a4022164205465616d20746f2072656164207468652053747564656e74204775696465206f626a65637469766573206361726566756c6c7920616e64206b6e6f77207468656d20707265636973656c79206265666f726520746865206e657874206d656574696e672800a4d7a7a4022002696401770c636579786a72756673667a792800a4d7a7a4022006696e64656e74017d002800a4d7a7a40220036469720177046175746f2800a4d7a7a4021f036469720177046175746f2800a4d7a7a4021f07636865636b6564017987a4d7a7a4021f03087461736b4974656d0700a4d7a7a4028b0103097061726167726170680700a4d7a7a4028c01060400a4d7a7a4028d0162205465616d20746f2070726570617265206120636c65617220616374696f6e20706c616e206f6e20656163682054524143206f626a6563746976652028776861742c20686f772c207768656e2920666f7220746865206e657874206d656574696e672800a4d7a7a4028c0102696401770c7575646c657366666f6a79722800a4d7a7a4028c0106696e64656e74017d002800a4d7a7a4028c01036469720177046175746f2800a4d7a7a4028b01036469720177046175746f2800a4d7a7a4028b0107636865636b6564017987a4d7a7a4028b0103087461736b4974656d0700a4d7a7a402f50103097061726167726170680700a4d7a7a402f601060400a4d7a7a402f70159205465616d20746f20707265706172652061206d6f72652064657461696c656420776f726b207363686564756c652f6f7267616e697a6174696f6e206f7665727669657720666f7220746865206e657874206d656574696e672800a4d7a7a402f60102696401770c6a676c656e7a6a63716a6b6f2800a4d7a7a402f60106696e64656e74017d002800a4d7a7a402f601036469720177046175746f2800a4d7a7a402f501036469720177046175746f2800a4d7a7a402f50107636865636b6564017987a4d7a7a402f50103087461736b4974656d0700a4d7a7a402d60203097061726167726170680700a4d7a7a402d702060400a4d7a7a402d80278205465616d20746f206f7267616e697a65205665696c6c6520546563686e6f3a206465646963617465207e3120686f75722f7765656b2070657220706572736f6e20746f2072657365617263682c207465737420747261636b732076696120504f432c20616e6420646f63756d656e7420726573756c74732800a4d7a7a402d70202696401770c6e646a7374616a63746a68622800a4d7a7a402d70206696e64656e74017d002800a4d7a7a402d702036469720177046175746f2800a4d7a7a402d602036469720177046175746f2800a4d7a7a402d60207636865636b6564017987a4d7a7a402d60203087461736b4974656d0700a4d7a7a402d60303097061726167726170680700a4d7a7a402d703060400a4d7a7a402d8039501205465616d20746f2070726f64756365207374727563747572656420646f63756d656e746174696f6e2028617263686974656374757265206469616772616d732c2043492f43442c207465737420706c616e732c206574632e2920746172676574696e6720646966666572656e742061756469656e636573202875736572732c2061646d696e732c207265736561726368657273292800a4d7a7a402d70302696401770c6c6375706a717069696679672800a4d7a7a402d70306696e64656e74017d002800a4d7a7a402d703036469720177046175746f2800a4d7a7a402d603036469720177046175746f2800a4d7a7a402d60307636865636b6564017987a4d7a7a402d60303087461736b4974656d0700a4d7a7a402f30403097061726167726170680700a4d7a7a402f404060400a4d7a7a402f5044f205465616d20746f206d6561737572652c20616e616c797a652c20616e642069746572617465206f6e20706572666f726d616e636520e28094206e6f74206a757374206d656173757265206f6e63652800a4d7a7a402f40402696401770c76756f6d647a78777466756c2800a4d7a7a402f40406696e64656e74017d002800a4d7a7a402f404036469720177046175746f2800a4d7a7a402f304036469720177046175746f2800a4d7a7a402f30407636865636b6564017987a4d7a7a402f30403087461736b4974656d0700a4d7a7a402c80503097061726167726170680700a4d7a7a402c905060400a4d7a7a402ca054b205465616d20746f20656e7375726520616c6c206d656d6265727320617474656e6420746865207765656b6c792073796e6368726f20706f696e742c206e6f74206a7573742033e28093342800a4d7a7a402c90502696401770c78666772696d6e676668736f2800a4d7a7a402c90506696e64656e74017d002800a4d7a7a402c905036469720177046175746f2800a4d7a7a402c805036469720177046175746f2800a4d7a7a402c80507636865636b6564017987a4d7a7a402c80503087461736b4974656d0700a4d7a7a402990603097061726167726170680700a4d7a7a4029a06060400a4d7a7a4029b0653205465616d20746f206964656e7469667920616e6420646f63756d656e74207468652070726f6a656374277320226861726420706f696e742220666f72204d616e6461746f7279204f626a65637469766520312800a4d7a7a4029a0602696401770c6b6d6863697a716c756b79682800a4d7a7a4029a0606696e64656e74017d002800a4d7a7a4029a06036469720177046175746f2800a4d7a7a4029906036469720177046175746f2800a4d7a7a402990607636865636b6564017987a4d7a7a402990603087461736b4974656d0700a4d7a7a402f40603097061726167726170680700a4d7a7a402f506060400a4d7a7a402f6064e205465616d20746f207072657061726520746865206d656574696e6720646f63756d656e742028617320646f6e65206c6173742074696d652920666f7220746865206e6578742073657373696f6e2800a4d7a7a402f50602696401770c7a776d746a7965726a766a722800a4d7a7a402f50606696e64656e74017d002800a4d7a7a402f506036469720177046175746f2800a4d7a7a402f406036469720177046175746f2800a4d7a7a402f40607636865636b6564017987a4d7a7a402f40603087461736b4974656d0700a4d7a7a402ca0703097061726167726170680700a4d7a7a402cb07060400a4d7a7a402cc071c204e657874206d656574696e67207363686564756c656420666f722086a4d7a7a402e80704626f6c64027b7d84a4d7a7a402e907124672696461792c204f63746f62657220313686a4d7a7a402fb0704626f6c64046e756c6c84a4d7a7a402fc073220286d6f7665642075702066726f6d207765656b206f66204f63742031392064756520746f206578616d20706572696f64292800a4d7a7a402cb0702696401770c636770726a757668706779642800a4d7a7a402cb0706696e64656e74017d002800a4d7a7a402cb07036469720177046175746f2800a4d7a7a402ca07036469720177046175746f2800a4d7a7a402ca0707636865636b656401792800a4d7a7a4021e036469720177046175746f87a4d7a7a4021e030e686f72697a6f6e74616c52756c652800a4d7a7a402b508036469720177046175746f87a4d7a7a402b508030768656164696e670700a4d7a7a402b708060400a4d7a7a402b8081050726f6a656374204f766572766965772800a4d7a7a402b70802696401770c6b6d6a686c737776786f6a742800a4d7a7a402b70806696e64656e74017d002800a4d7a7a402b708036469720177046175746f2800a4d7a7a402b708056c6576656c017d0387a4d7a7a402b708030a62756c6c65744c6973740700a4d7a7a402cd0803086c6973744974656d0700a4d7a7a402ce0803097061726167726170680700a4d7a7a402cf08060600a4d7a7a402d00804626f6c64027b7d84a4d7a7a402d1080d50726f6a656374206e616d653a86a4d7a7a402de0804626f6c64046e756c6c84a4d7a7a402df086520436f6e736f72c3a920e280942061696d65642061742068656c70696e67206e6575726f7479706963616c2070656f706c65206e61766967617465206469676974616c206c69666520616e642061636869657665206469676974616c206175746f6e6f6d792800a4d7a7a402cf0802696401770c6a65797a687a70716a7a766e2800a4d7a7a402cf0806696e64656e74017d002800a4d7a7a402cf08036469720177046175746f2800a4d7a7a402ce08036469720177046175746f87a4d7a7a402ce0803086c6973744974656d0700a4d7a7a402c60903097061726167726170680700a4d7a7a402c709060600a4d7a7a402c80904626f6c64027b7d84a4d7a7a402c909165468726565206d61696e20636f6d706f6e656e74733a86a4d7a7a402df0904626f6c64046e756c6c84a4d7a7a402e00961204261636b656e64202841504920666f756e646174696f6e292c2044617368626f617264202877656220696e7465726661636520666f722068656c70657273292c20616e64204c61756e6368657220286d616e6167656420627920456c696173292800a4d7a7a402c70902696401770c61697a6a626d7069636376772800a4d7a7a402c70906696e64656e74017d002800a4d7a7a402c709036469720177046175746f2800a4d7a7a402c609036469720177046175746f87a4d7a7a402c60903086c6973744974656d0700a4d7a7a402c60a03097061726167726170680700a4d7a7a402c70a060600a4d7a7a402c80a04626f6c64027b7d84a4d7a7a402c90a105461736b206d616e6167656d656e743a86a4d7a7a402d90a04626f6c64046e756c6c84a4d7a7a402da0a67205573696e67204a697261202863686f73656e206f766572204769744875622050726f6a65637473206261736564206f6e207072696f722070726f6a656374206d616e6167656d656e7420657870657269656e63652c20617070726f76656420627920445052292800a4d7a7a402c70a02696401770c69786f6f616d68787a6971762800a4d7a7a402c70a06696e64656e74017d002800a4d7a7a402c70a036469720177046175746f2800a4d7a7a402c60a036469720177046175746f87a4d7a7a402c60a03086c6973744974656d0700a4d7a7a402c60b03097061726167726170680700a4d7a7a402c70b060600a4d7a7a402c80b04626f6c64027b7d84a4d7a7a402c90b0f5465616d206c6f636174696f6e733a86a4d7a7a402d80b04626f6c64046e756c6c84a4d7a7a402d90b89012053776564656e2028456c696173292c204265726c696e2028456e7a6f292c204475626c696e2f4972656c616e6420284c756361732c20416c6578616e647265292c2043616e6164612f51756562656320286f6e65206d656d626572292c207769746820686f6d65207363686f6f6c7320696e204d6f6e7470656c6c69657220616e642050617269732800a4d7a7a402c70b02696401770c63797a6d62616874786b78732800a4d7a7a402c70b06696e64656e74017d002800a4d7a7a402c70b036469720177046175746f2800a4d7a7a402c60b036469720177046175746f2800a4d7a7a402cd08036469720177046175746f87a4d7a7a402cd08030768656164696e670700a4d7a7a402e80c060400a4d7a7a402e90c0a417474656e64616e63652800a4d7a7a402e80c02696401770c68626164786f646a7a7671652800a4d7a7a402e80c06696e64656e74017d002800a4d7a7a402e80c036469720177046175746f2800a4d7a7a402e80c056c6576656c017d0387a4d7a7a402e80c030a62756c6c65744c6973740700a4d7a7a402f80c03086c6973744974656d0700a4d7a7a402f90c03097061726167726170680700a4d7a7a402fa0c060400a4d7a7a402fb0c124962726168696d2077617320616273656e742800a4d7a7a402fa0c02696401770c6f61626a727977656865776d2800a4d7a7a402fa0c06696e64656e74017d002800a4d7a7a402fa0c036469720177046175746f2800a4d7a7a402f90c036469720177046175746f87a4d7a7a402f90c03086c6973744974656d0700a4d7a7a402920d03097061726167726170680700a4d7a7a402930d060400a4d7a7a402940d43416c6578616e6472652077617320616273656e742064756520746f20696c6c6e6573732028756e6365727461696e20696620617474656e64696e6720617420616c6c292800a4d7a7a402930d02696401770c61616d696462626c646b796f2800a4d7a7a402930d06696e64656e74017d002800a4d7a7a402930d036469720177046175746f2800a4d7a7a402920d036469720177046175746f87a4d7a7a402920d03086c6973744974656d0700a4d7a7a402dc0d03097061726167726170680700a4d7a7a402dd0d060400a4d7a7a402de0d1a416e67656c2f416e67c3a86c652061727269766564206c6174652800a4d7a7a402dd0d02696401770c796164687764757a767365652800a4d7a7a402dd0d06696e64656e74017d002800a4d7a7a402dd0d036469720177046175746f2800a4d7a7a402dc0d036469720177046175746f2800a4d7a7a402f80c036469720177046175746f87a4d7a7a402f80c030768656164696e670700a4d7a7a402fd0d060400a4d7a7a402fe0d0f50726f6772657373205570646174652800a4d7a7a402fd0d02696401770c70766e696f666e617a7a75692800a4d7a7a402fd0d06696e64656e74017d002800a4d7a7a402fd0d036469720177046175746f2800a4d7a7a402fd0d056c6576656c017d0387a4d7a7a402fd0d030a62756c6c65744c6973740700a4d7a7a402920e03086c6973744974656d0700a4d7a7a402930e03097061726167726170680700a4d7a7a402940e060400a4d7a7a402950e54416c6c20696e7374616c6c6174696f6e20616e64206d696e6f7220636f7272656374696f6e732066726f6d207468652070726576696f75732073657373696f6e2068617665206265656e20636f6d706c657465642800a4d7a7a402940e02696401770c6a6a746663656a6c767a676c2800a4d7a7a402940e06696e64656e74017d002800a4d7a7a402940e036469720177046175746f2800a4d7a7a402930e036469720177046175746f87a4d7a7a402930e03086c6973744974656d0700a4d7a7a402ee0e03097061726167726170680700a4d7a7a402ef0e060400a4d7a7a402f00e7a43757272656e7420676f616c3a206275696c64206120736f6c696420666f756e646174696f6e20666f72206561636820636f6d706f6e656e7420e2809420736f6d657768657265206265747765656e206120504f4320616e64204d565020e28094206265666f7265206d6f76696e6720746f20737072696e74732800a4d7a7a402ef0e02696401770c6572766d6b74656b697364772800a4d7a7a402ef0e06696e64656e74017d002800a4d7a7a402ef0e036469720177046175746f2800a4d7a7a402ee0e036469720177046175746f87a4d7a7a402ee0e03086c6973744974656d0700a4d7a7a402eb0f03097061726167726170680700a4d7a7a402ec0f060400a4d7a7a402ed0f2e436f6465206973206265696e6720646f63756d656e74656420696e6372656d656e74616c6c7920766961205052732800a4d7a7a402ec0f02696401770c6575696d706276666f6d71682800a4d7a7a402ec0f06696e64656e74017d002800a4d7a7a402ec0f036469720177046175746f2800a4d7a7a402eb0f036469720177046175746f87a4d7a7a402eb0f03086c6973744974656d0700a4d7a7a402a01003097061726167726170680700a4d7a7a402a110060400a4d7a7a402a2102c54776f20636f6d706c656d656e74617279207365636f6e6461727920747261636b7320646566696e65643a2086a4d7a7a402ce1004626f6c64027b7d84a4d7a7a402cf1007547261636b204186a4d7a7a402d61004626f6c64046e756c6c84a4d7a7a402d71024202873656375726520746563686e6963616c20656e7669726f6e6d656e742920616e642086a4d7a7a402fb1004626f6c64027b7d84a4d7a7a402fc1007547261636b204486a4d7a7a402831104626f6c64046e756c6c84a4d7a7a40284112a20286d6561737572652c20746573742c20616e64206f7074696d697a6520706572666f726d616e6365292800a4d7a7a402a11002696401770c6f766b69766e646d63646b742800a4d7a7a402a11006696e64656e74017d002800a4d7a7a402a110036469720177046175746f2800a4d7a7a402a010036469720177046175746f2800a4d7a7a402920e036469720177046175746f87a4d7a7a402920e030768656164696e670700a4d7a7a402b411060400a4d7a7a402b511214f626a6563746976657320526576696577202853747564656e74204775696465292800a4d7a7a402b41102696401770c7169677672706a72626574742800a4d7a7a402b41106696e64656e74017d002800a4d7a7a402b411036469720177046175746f2800a4d7a7a402b411056c6576656c017d0387a4d7a7a402b411030a62756c6c65744c6973740700a4d7a7a402db1103086c6973744974656d0700a4d7a7a402dc1103097061726167726170680700a4d7a7a402dd11060400a4d7a7a402de118a015468652073757065727669736f72206e6f74656420746865207465616d20776173206e6f742073756666696369656e746c792066616d696c696172207769746820746865697220666f726d616c2054524143206f626a6563746976657320616e6420737472657373656420746865206e65656420746f206b6e6f77207468656d20707265636973656c792800a4d7a7a402dd1102696401770c6d6d677373767a7a726773662800a4d7a7a402dd1106696e64656e74017d002800a4d7a7a402dd11036469720177046175746f2800a4d7a7a402dc11036469720177046175746f87a4d7a7a402dc1103086c6973744974656d0700a4d7a7a402ed1203097061726167726170680700a4d7a7a402ee12060600a4d7a7a402ef1204626f6c64027b7d84a4d7a7a402f012164d616e6461746f7279204f626a65637469766520313a86a4d7a7a402861304626f6c64046e756c6c84a4d7a7a40287138501204f7267616e697a6520616e6420636f6e64756374206120746563686e6f6c6f676963616c20776174636820285665696c6c6520546563686e6f2920746f206964656e7469667920616e642061646472657373207468652070726f6a656374277320226861726420706f696e742220e280942064756520656e64206f66204f63746f6265722800a4d7a7a402ee1202696401770c67647a63677275676c7a6b6f2800a4d7a7a402ee1206696e64656e74017d002800a4d7a7a402ee12036469720177046175746f87a4d7a7a402ee12030a62756c6c65744c6973740700a4d7a7a4028e1403086c6973744974656d0700a4d7a7a4028f1403097061726167726170680700a4d7a7a4029014060400a4d7a7a4029114325465616d20686173206e6f742079657420636c6561726c79206964656e74696669656420746865206861726420706f696e742800a4d7a7a402901402696401770c65746661666d7573767777752800a4d7a7a402901406696e64656e74017d002800a4d7a7a4029014036469720177046175746f2800a4d7a7a4028f14036469720177046175746f87a4d7a7a4028f1403086c6973744974656d0700a4d7a7a402c81403097061726167726170680700a4d7a7a402c914060400a4d7a7a402ca148301417070726f6163683a207765656b6c792072657365617263682073657373696f6e7320e28692207465737420747261636b732028504f432920e2869220646f63756d656e74206f7574636f6d657320e286922064657465726d696e652069662f686f77207468657920696e7465677261746520696e746f207468652070726f6a6563742800a4d7a7a402c91402696401770c76626d617170636d687071642800a4d7a7a402c91406696e64656e74017d002800a4d7a7a402c914036469720177046175746f2800a4d7a7a402c814036469720177046175746f87a4d7a7a402c81403086c6973744974656d0700a4d7a7a402cc1503097061726167726170680700a4d7a7a402cd15060400a4d7a7a402ce1551446f63756d656e7473206d7573742062652070726f647563656420616e6420726561647920746f206a75737469667920746865205665696c6c6520546563686e6f2061742074686520676f2f6e6f2d676f2800a4d7a7a402cd1502696401770c66646677617a6a7374676b682800a4d7a7a402cd1506696e64656e74017d002800a4d7a7a402cd15036469720177046175746f2800a4d7a7a402cc15036469720177046175746f2800a4d7a7a4028e14036469720177046175746f2800a4d7a7a402ed12036469720177046175746f87a4d7a7a402ed1203086c6973744974656d0700a4d7a7a402a61603097061726167726170680700a4d7a7a402a716060600a4d7a7a402a81604626f6c64027b7d84a4d7a7a402a916164d616e6461746f7279204f626a65637469766520323a86a4d7a7a402bf1604626f6c64046e756c6c84a4d7a7a402c0166820537472756374757265642c20646f63756d656e7465642c20616e642072656c6961626c652061726368697465637475726520e2809420696e636c7564657320617263686974656374757265206469616772616d732c2043492f43442c207465737420706c616e732800a4d7a7a402a71602696401770c797564646a6d77657968726d2800a4d7a7a402a71606696e64656e74017d002800a4d7a7a402a716036469720177046175746f87a4d7a7a402a716030a62756c6c65744c6973740700a4d7a7a402aa1703086c6973744974656d0700a4d7a7a402ab1703097061726167726170680700a4d7a7a402ac17060400a4d7a7a402ad1760446f63756d656e746174696f6e206d75737420626520707572706f73652d61776172653a2064697374696e6775697368206265747765656e20646f637320666f722075736572732c2061646d696e732c20616e642072657365617263686572732800a4d7a7a402ac1702696401770c637a6b7879776c716a6666752800a4d7a7a402ac1706696e64656e74017d002800a4d7a7a402ac17036469720177046175746f2800a4d7a7a402ab17036469720177046175746f2800a4d7a7a402aa17036469720177046175746f2800a4d7a7a402a616036469720177046175746f87a4d7a7a402a61603086c6973744974656d0700a4d7a7a402941803097061726167726170680700a4d7a7a4029518060600a4d7a7a402961804626f6c64027b7d84a4d7a7a402971821436f6d706c656d656e74617279204f626a6563746976657320284120262044293a86a4d7a7a402b81804626f6c64046e756c6c84a4d7a7a402b9189f01204d61746368207468652074776f207365636f6e6461727920747261636b7320616c72656164792063686f73656e3b20666f7220547261636b20442c206d6561737572656d656e74206d757374206c65616420746f20616e616c797369732c206d6f64696669636174696f6e2c20616e642072652d6d6561737572656d656e7420e28094206e6f74206a7573742061206f6e652d74696d65206d65747269632800a4d7a7a402951802696401770c646863737362706c776b6c702800a4d7a7a402951806696e64656e74017d002800a4d7a7a4029518036469720177046175746f2800a4d7a7a4029418036469720177046175746f87a4d7a7a402941803086c6973744974656d0700a4d7a7a402db1903097061726167726170680700a4d7a7a402dc19060400a4d7a7a402dd19635468652053747564656e7420477569646520616c736f20636f6e7461696e732061206c697374206f662072657175697265642064656c6976657261626c657320e28094207465616d207761732072656d696e64656420746f20636f6e73756c742069742800a4d7a7a402dc1902696401770c6d757665726b71726f6174722800a4d7a7a402dc1906696e64656e74017d002800a4d7a7a402dc19036469720177046175746f2800a4d7a7a402db19036469720177046175746f2800a4d7a7a402db11036469720177046175746f87a4d7a7a402db11030768656164696e670700a4d7a7a402c41a060400a4d7a7a402c51a23576f726b696e67204d6574686f64732026205465616d204f7267616e697a6174696f6e2800a4d7a7a402c41a02696401770c637263796373646e6d74696c2800a4d7a7a402c41a06696e64656e74017d002800a4d7a7a402c41a036469720177046175746f2800a4d7a7a402c41a056c6576656c017d0387a4d7a7a402c41a030a62756c6c65744c6973740700a4d7a7a402ed1a03086c6973744974656d0700a4d7a7a402ee1a03097061726167726170680700a4d7a7a402ef1a060400a4d7a7a402f01a4d5465616d20776f726b73206173796e6368726f6e6f75736c7920776974682061737369676e6564207461736b733b20636f646520726576696577732061726520646f6e652062792070656572732800a4d7a7a402ef1a02696401770c657668786d657378776972782800a4d7a7a402ef1a06696e64656e74017d002800a4d7a7a402ef1a036469720177046175746f2800a4d7a7a402ee1a036469720177046175746f87a4d7a7a402ee1a03086c6973744974656d0700a4d7a7a402c21b03097061726167726170680700a4d7a7a402c31b060400a4d7a7a402c41b5c4f63636173696f6e616c206a6f696e7420446973636f726420776f726b2073657373696f6e73206172652068656c643b20776f726b696e6720686f757273206172652073686172656420736f206f74686572732063616e206a6f696e2800a4d7a7a402c31b02696401770c6269667179726573747674672800a4d7a7a402c31b06696e64656e74017d002800a4d7a7a402c31b036469720177046175746f2800a4d7a7a402c21b036469720177046175746f87a4d7a7a402c21b03086c6973744974656d0700a4d7a7a402a51c03097061726167726170680700a4d7a7a402a61c060400a4d7a7a402a71c5641207765656b6c79207765656b656e642073796e6368726f20706f696e7420616c7265616479206578697374732c20627574206f6e6c792033e2809334206d656d62657273207479706963616c6c7920617474656e642800a4d7a7a402a61c02696401770c72676f7179706a736e7978672800a4d7a7a402a61c06696e64656e74017d002800a4d7a7a402a61c036469720177046175746f2800a4d7a7a402a51c036469720177046175746f87a4d7a7a402a51c03086c6973744974656d0700a4d7a7a402801d03097061726167726170680700a4d7a7a402811d060400a4d7a7a402821da50153757065727669736f7220656d70686173697a65642074686520696d706f7274616e6365206f662061206d6f726520726967696420776f726b206672616d65776f726b20676976656e207468652066756c6c792072656d6f74652c206d756c74692d636f756e7472792073657475702c20616e6420746865206e61747572616c2074656e64656e637920746f2064657072696f726974697a65207468652070726f6a6563742800a4d7a7a402811d02696401770c6b6575626e6366637a7571672800a4d7a7a402811d06696e64656e74017d002800a4d7a7a402811d036469720177046175746f2800a4d7a7a402801d036469720177046175746f2800a4d7a7a402ed1a036469720177046175746f87a4d7a7a402ed1a030768656164696e670700a4d7a7a402ad1e060400a4d7a7a402ae1e2053757065727669736f7220466565646261636b2026204e6578742053746570732800a4d7a7a402ad1e02696401770c77636571636a756b70636e6e2800a4d7a7a402ad1e06696e64656e74017d002800a4d7a7a402ad1e036469720177046175746f2800a4d7a7a402ad1e056c6576656c017d0387a4d7a7a402ad1e030a62756c6c65744c6973740700a4d7a7a402d31e03086c6973744974656d0700a4d7a7a402d41e03097061726167726170680700a4d7a7a402d51e060400a4d7a7a402d61ea301546865207465616d206a756d70656420696e746f20746f6f6c7320284a69726129206265666f7265206578706c61696e696e6720676f616c7320616e6420646972656374696f6e20e28094207468652073757065727669736f722061736b656420666f72206120636c6561726572206e61727261746976653a206f626a65637469766520e2869220617070726f61636820e2869220696d706c656d656e746174696f6e2800a4d7a7a402d51e02696401770c62706270647373667679626d2800a4d7a7a402d51e06696e64656e74017d002800a4d7a7a402d51e036469720177046175746f2800a4d7a7a402d41e036469720177046175746f87a4d7a7a402d41e03086c6973744974656d0700a4d7a7a402f81f03097061726167726170680700a4d7a7a402f91f060400a4d7a7a402fa1f8e01466f7220746865206e657874206d656574696e672c20746865207465616d2073686f756c642070726573656e743a20616374696f6e20706c616e7320706572206f626a6563746976652c206120636c656172657220776f726b207363686564756c652c20616e642064656d6f6e7374726174652074686579206b6e6f77207468656972206f626a656374697665732800a4d7a7a402f91f02696401770c6d69777a6e706364766676782800a4d7a7a402f91f06696e64656e74017d002800a4d7a7a402f91f036469720177046175746f2800a4d7a7a402f81f036469720177046175746f87a4d7a7a402f81f03086c6973744974656d0700a4d7a7a4028d2103097061726167726170680700a4d7a7a4028e21060400a4d7a7a4028f21505468652073757065727669736f7220697320617661696c61626c6520666f72206173796e63207175657374696f6e732076696120746865206578697374696e6720446973636f7264206368616e6e656c2800a4d7a7a4028e2102696401770c6c796172767a7072786174712800a4d7a7a4028e2106696e64656e74017d002800a4d7a7a4028e21036469720177046175746f2800a4d7a7a4028d21036469720177046175746f2800a4d7a7a402d31e036469720177046175746f81a4d7a7a402d31e01000981a4d7a7a402e52101000e87a4d7a7a402ef2103097061726167726170680700a4d7a7a402fe21060400a4d7a7a402ff211748656c6c6f3f2043616e20796f752068656172206d653f2800a4d7a7a402fe2102696401770c66686b686b6c6a7474666b782800a4d7a7a402fe2106696e64656e74017d002800a4d7a7a402fe21036469720177046175746f87a4d7a7a402fe2103097061726167726170680700a4d7a7a4029a22060400a4d7a7a4029b22674920776f756c6420686176652074616b656e206974206f666620446973636f72642e204f6820776f772c20776169742c207768793f204168207965732c20796f75206861766520746f2074616b65206974206f666620446973636f726420666f7220746861742e2800a4d7a7a4029a2202696401770c797a6d726f7669776e6765662800a4d7a7a4029a2206696e64656e74017d002800a4d7a7a4029a22036469720177046175746f87a4d7a7a4029a2203097061726167726170680700a4d7a7a4028623060400a4d7a7a40287230d48656c6c6f2e2048656c6c6f2e2800a4d7a7a402862302696401770c6f65626b7668616f7272796b2800a4d7a7a402862306696e64656e74017d002800a4d7a7a4028623036469720177046175746f87a4d7a7a402862303097061726167726170680700a4d7a7a4029823060400a4d7a7a40299230355702e2800a4d7a7a402982302696401770c7362656f6d70696d6469616d2800a4d7a7a402982306696e64656e74017d002800a4d7a7a4029823036469720177046175746f87a4d7a7a402982303097061726167726170680700a4d7a7a402a023060400a4d7a7a402a123bd014b617661697a68752120566572792077656c6c2c207468616e6b20796f752e205965732c2049206d61792068617665206265656e20636f6e6e65637465642061206c6974746c65206561726c792c20796f75206d617920686176652077616e74656420746f2064697363757373206265666f7265204920617272697665642e204e6f2c206275742074656c6c206d652e2054686572652773206e6f2070726f626c656d2c2049276c6c2074616b652069742071756974652077656c6c2e2800a4d7a7a402a02302696401770c6f6d7465717361786a6863622800a4d7a7a402a02306696e64656e74017d002800a4d7a7a402a023036469720177046175746f87a4d7a7a402a02303097061726167726170680700a4d7a7a402e224060400a4d7a7a402e3241a4e6f2c20796f752772652061626f757420746f20646f2069742e2800a4d7a7a402e22402696401770c637a6b676a65637978646e622800a4d7a7a402e22406696e64656e74017d002800a4d7a7a402e224036469720177046175746f87a4d7a7a402e22403097061726167726170680700a4d7a7a4028125060400a4d7a7a4028225b301446f6e277420776f7272792e204920736177207468617420796f752073656e74206d652074686520646f63756d656e742e20496e2074686520636f6e766572736174696f6e2c20746865206c6974746c65207072657061726174696f6e2074686572653f205468616e6b20796f752076657279206d7563682e2049742773207665727920676f6f642c20697420616c6c6f776564206d6520746f2073746172742066696c6c696e67207468696e67732075702e2800a4d7a7a402812502696401770c76627a69746663786664756a2800a4d7a7a402812506696e64656e74017d002800a4d7a7a4028125036469720177046175746f87a4d7a7a402812503097061726167726170680700a4d7a7a402b926060400a4d7a7a402ba260f5965732c207468617427732069742e2800a4d7a7a402b92602696401770c71737964747a786e787168682800a4d7a7a402b92606696e64656e74017d002800a4d7a7a402b926036469720177046175746f87a4d7a7a402b92603097061726167726170680700a4d7a7a402cd26060400a4d7a7a402ce260a4c65742773207365652e2800a4d7a7a402cd2602696401770c7164747379796161676c72742800a4d7a7a402cd2606696e64656e74017d002800a4d7a7a402cd26036469720177046175746f87a4d7a7a402cd2603097061726167726170680700a4d7a7a402dc26060400a4d7a7a402dd261e49742077696c6c20736176652075732061206c6f74206f662074696d652e2800a4d7a7a402dc2602696401770c6b6b70616e7071726b73676b2800a4d7a7a402dc2606696e64656e74017d002800a4d7a7a402dc26036469720177046175746f87a4d7a7a402dc2603097061726167726170680700a4d7a7a402ff26060400a4d7a7a40280271e5468616e6b20796f752e20497320746865206f746865727320686572653f2800a4d7a7a402ff2602696401770c6368647469636b6e627279722800a4d7a7a402ff2606696e64656e74017d002800a4d7a7a402ff26036469720177046175746f87a4d7a7a402ff2603097061726167726170680700a4d7a7a402a227060400a4d7a7a402a3271a5468657920686176656e277420616e737765726564207965742e2800a4d7a7a402a22702696401770c6c6f676b6b6e706164726f662800a4d7a7a402a22706696e64656e74017d002800a4d7a7a402a227036469720177046175746f87a4d7a7a402a22703097061726167726170680700a4d7a7a402c127060400a4d7a7a402c227154f6b61792e2054686174277320706572666563742e2800a4d7a7a402c12702696401770c76696f696c76767a736461672800a4d7a7a402c12706696e64656e74017d002800a4d7a7a402c127036469720177046175746f87a4d7a7a402c12703097061726167726170680700a4d7a7a402db27060400a4d7a7a402dc2749466f72206e6f772c20746865726520617265206f6e6c7920666f75722e2054686572652773206e6f204962726168696d2c20416e67656c2e2e2e20416e6420416c6578616e6472612e2800a4d7a7a402db2702696401770c726b7a6479746f736d76776b2800a4d7a7a402db2706696e64656e74017d002800a4d7a7a402db27036469720177046175746f87a4d7a7a402db2703097061726167726170680700a4d7a7a402a928060400a4d7a7a402aa28a601536f20416c6578616e64726520697320627573792e20536f2c20416c6578616e6472652c2077696c6c20796f7520636f6d65206261636b3f204e6f2c20416c6578616e647265206973206e6f74207375726520626563617573652068652773207369636b2e20576520646f6e2774206b6e6f77206966206865277320636f6d696e67206f72206e6f742e2057652772652061206269742077616974696e6720666f722069742e2800a4d7a7a402a92802696401770c776e6e7175756472677861692800a4d7a7a402a92806696e64656e74017d002800a4d7a7a402a928036469720177046175746f87a4d7a7a402a92803097061726167726170680700a4d7a7a402d429060400a4d7a7a402d5293749276c6c206c657420796f75206b6e6f772c20616e6420696620686520636f6d65732c20796f75276c6c206c6574206d65206b6e6f772e2800a4d7a7a402d42902696401770c6f637a7a6e776675646171722800a4d7a7a402d42906696e64656e74017d002800a4d7a7a402d429036469720177046175746f87a4d7a7a402d42903097061726167726170680700a4d7a7a402902a060400a4d7a7a402912a054f6b61792e2800a4d7a7a402902a02696401770c6f79626d6e787a71746974792800a4d7a7a402902a06696e64656e74017d002800a4d7a7a402902a036469720177046175746f87a4d7a7a402902a03097061726167726170680700a4d7a7a4029a2a060400a4d7a7a4029b2a26416e67656c20416e67c3a86c652077696c6c2061727269766520696e2061206d696e7574652e2800a4d7a7a4029a2a02696401770c6a796961657172706d6275722800a4d7a7a4029a2a06696e64656e74017d002800a4d7a7a4029a2a036469720177046175746f87a4d7a7a4029a2a03097061726167726170680700a4d7a7a402c42a060400a4d7a7a402c52a154962726168696d20776f6e2774206172726976652e2800a4d7a7a402c42a02696401770c71657376686e6b66726d6d642800a4d7a7a402c42a06696e64656e74017d002800a4d7a7a402c42a036469720177046175746f87a4d7a7a402c42a03097061726167726170680700a4d7a7a402de2a060400a4d7a7a402df2a1e42726168696d2c204920776f6e27742073656520796f752e204f6b61792e2800a4d7a7a402de2a02696401770c686f726a70696e6579656d652800a4d7a7a402de2a06696e64656e74017d002800a4d7a7a402de2a036469720177046175746f87a4d7a7a402de2a03097061726167726170680700a4d7a7a402812b060400a4d7a7a402822b68492074616b652074686973206f70706f7274756e69747920746f206d616b65207468652061646a7573746d656e74732e204f682c20426f6f702c20626f6f702c20626f6f702e2049207468696e6b204962726168696d20616c7265616479206c696b65642069742e2800a4d7a7a402812b02696401770c68666b63647770636c75666c2800a4d7a7a402812b06696e64656e74017d002800a4d7a7a402812b036469720177046175746f87a4d7a7a402812b03097061726167726170680700a4d7a7a402ee2b060400a4d7a7a402ef2b19596561682e2049742773207665727920706f737369626c652e2800a4d7a7a402ee2b02696401770c76686d67657972747a7a6c632800a4d7a7a402ee2b06696e64656e74017d002800a4d7a7a402ee2b036469720177046175746f87a4d7a7a402ee2b03097061726167726170680700a4d7a7a4028c2c060400a4d7a7a4028d2c514d792063616d657261206973206e6f74206465746563746564206f6e205562756e74752c20736f2049207468696e6b2049276c6c206861766520746f2072657374617274206d7920636f6d70757465722e2800a4d7a7a4028c2c02696401770c62766a7973746378647472652800a4d7a7a4028c2c06696e64656e74017d002800a4d7a7a4028c2c036469720177046175746f87a4d7a7a4028c2c03097061726167726170680700a4d7a7a402e22c060400a4d7a7a402e32cc601476f2061686561642c20776520686176652074696d65207768696c6520492074616b652063617265206f6620746861742e20536f2c20696e646565642c204962726168696d2c204920646f6e277420686176652069742e2049206861766520456c69612c2053616e6a6f2c20416e67656c2c204c7563617320616e6420416c6578616e6472652e204f4b2e2057656c6c2c204962726168696d2c2061726520776520676f696e6720746f2074616b65206974206f7574206f6620746865206d656574696e673f2800a4d7a7a402e22c02696401770c6e746176646d6f62667563632800a4d7a7a402e22c06696e64656e74017d002800a4d7a7a402e22c036469720177046175746f87a4d7a7a402e22c03097061726167726170680700a4d7a7a402ad2e060400a4d7a7a402ae2e1d546869732069732053687269204d6174616a693a205368204f6b61792e2800a4d7a7a402ad2e02696401770c626c73727075717773746a712800a4d7a7a402ad2e06696e64656e74017d002800a4d7a7a402ad2e036469720177046175746f87a4d7a7a402ad2e03097061726167726170680700a4d7a7a402cf2e060400a4d7a7a402d02e8f03536f7272792c2049276d206261636b207769746820796f752e20536f20776865726520697320416c6578616e647265205061756c613f20432765737420746f75742e204f6b61792e2047726561742e20536f2c207765206f6e6c79206d69737320416c6578616e6472652c2073696e636520416e67656c20697320686572652e205768617420492070726f706f7365206973207468617420796f752073746172742062792072656d696e64696e67206d6520696e206f6e652073656e74656e636520796f75722070726f6a6563742e2074686520676f616c206f66207468652070726f6a6563742c20736f207468617420697420616c6c6f777320757320746f20626520737572652c20746f2072656d656d62657220746f2072656d696e64206d65206f6620796f75722070726f6a65637420616e64207468656e2074616c6b2061626f757420796f75722070726f677265737320616e64207468656e2077652077696c6c20776f726b206f6e20746865206f626a656374697665732e2049732065766572796f6e65206f6b61793f2800a4d7a7a402cf2e02696401770c77726c6c6c727779627a6d692800a4d7a7a402cf2e06696e64656e74017d002800a4d7a7a402cf2e036469720177046175746f87a4d7a7a402cf2e03097061726167726170680700a4d7a7a402e331060400a4d7a7a402e4310d4974277320706572666563742e2800a4d7a7a402e33102696401770c7477696f696e766b7161706e2800a4d7a7a402e33106696e64656e74017d002800a4d7a7a402e331036469720177046175746f87a4d7a7a402e33103097061726167726170680700a4d7a7a402f531060400a4d7a7a402f631135768657265277320746865206275636b65743f2800a4d7a7a402f53102696401770c7577616a7a616b6b787769752800a4d7a7a402f53106696e64656e74017d002800a4d7a7a402f531036469720177046175746f87a4d7a7a402f53103097061726167726170680700a4d7a7a4028d32060400a4d7a7a4028e3205576169742e2800a4d7a7a4028d3202696401770c79676f616a766e646f6a6e752800a4d7a7a4028d3206696e64656e74017d002800a4d7a7a4028d32036469720177046175746f87a4d7a7a4028d3203097061726167726170680700a4d7a7a4029732060400a4d7a7a4029832214f6b61792c2067726561742e20576169742c206a7573742061207365636f6e642e2800a4d7a7a402973202696401770c69706679736d747270767a6e2800a4d7a7a402973206696e64656e74017d002800a4d7a7a4029732036469720177046175746f87a4d7a7a402973203097061726167726170680700a4d7a7a402bd32060400a4d7a7a402be324e596f75206a75737420776f6b652075702c20416e67656c2e20796f75204974277320373a33302c20506974792e20492077656e7420746f206265642061742033206f722034206f27636c6f636b2e2800a4d7a7a402bd3202696401770c706e7a706d687870766476692800a4d7a7a402bd3206696e64656e74017d002800a4d7a7a402bd32036469720177046175746f87a4d7a7a402bd3203097061726167726170680700a4d7a7a4029033060400a4d7a7a40291335c476f2061686561642c2049276d206c697374656e696e672e2048656c6c6f3f2049206c6f6f6b206174206d79206c6f73732e2047726561742e20596561682c206e6f742076657279207374726f6e672c206275742e2e2e20576f772e2800a4d7a7a402903302696401770c787573736b657677716772772800a4d7a7a402903306696e64656e74017d002800a4d7a7a4029033036469720177046175746f87a4d7a7a402903303097061726167726170680700a4d7a7a402f133060400a4d7a7a402f23317497320697420626574746572206c696b6520746861743f2800a4d7a7a402f13302696401770c6f67666a6a7a626177786a672800a4d7a7a402f13306696e64656e74017d002800a4d7a7a402f133036469720177046175746f87a4d7a7a402f13303097061726167726170680700a4d7a7a4028d34060400a4d7a7a4028e341a5965732c206d756368206265747465722e20506572666563742e2800a4d7a7a4028d3402696401770c6b6f6f676164627070756d6b2800a4d7a7a4028d3406696e64656e74017d002800a4d7a7a4028d34036469720177046175746f87a4d7a7a4028d3403097061726167726170680700a4d7a7a402ac34060400a4d7a7a402ad34192d4c657427732073656520697420616761696e20736f6f6e2e2800a4d7a7a402ac3402696401770c6b706b6b76726e666d69776f2800a4d7a7a402ac3406696e64656e74017d002800a4d7a7a402ac34036469720177046175746f87a4d7a7a402ac3403097061726167726170680700a4d7a7a402ca34060400a4d7a7a402cb34034e6f2e2800a4d7a7a402ca3402696401770c63696d6864776e7a7969796f2800a4d7a7a402ca3406696e64656e74017d002800a4d7a7a402ca34036469720177046175746f87a4d7a7a402ca3403097061726167726170680700a4d7a7a402d234060400a4d7a7a402d33419496620796f752077616e742c20492063616e20646f2069742e2800a4d7a7a402d23402696401770c796a6a6664686a696a6b6f772800a4d7a7a402d23406696e64656e74017d002800a4d7a7a402d234036469720177046175746f87a4d7a7a402d23403097061726167726170680700a4d7a7a402f034060400a4d7a7a402f134dc0152696768742e20536f2c2022436f6e736f72c3a92220697320612070726f6a6563742061696d65642061742068656c70696e67206e6575726f7479706963616c2070656f706c652057652061726520676f696e6720746f2068617665206120736f7274206f6620696e74726f64756374696f6e20746f2065766572797468696e672074686174206973206469676974616c206c6966652e20616e6420616c6c20746861742069732061726f756e642075732c20726174686572206469676974616c206175746f6e6f6d792e20496e20612073656e74656e63652e2e2e2800a4d7a7a402f03402696401770c7072687a6d6f6d71616d67732800a4d7a7a402f03406696e64656e74017d002800a4d7a7a402f034036469720177046175746f87a4d7a7a402f03403097061726167726170680700a4d7a7a402d036060400a4d7a7a402d136054f6b61792e2800a4d7a7a402d03602696401770c6c73616b73697270757961702800a4d7a7a402d03606696e64656e74017d002800a4d7a7a402d036036469720177046175746f87a4d7a7a402d03603097061726167726170680700a4d7a7a402da36060400a4d7a7a402db3620536f2c2074656c6c206d652061626f757420796f75722070726f67726573732e2800a4d7a7a402da3602696401770c6470616c6d736d696e6c696f2800a4d7a7a402da3606696e64656e74017d002800a4d7a7a402da36036469720177046175746f87a4d7a7a402da3603097061726167726170680700a4d7a7a402ff36060400a4d7a7a40280378f02746f20616c6c6f772065766572796f6e6520746f20666f6c6c6f7720776861742065766572796f6e6520697320646f696e672e205768617420656c73653f2050656f706c652063616e20616464576520686176652074686520646576656c6f706d656e74206f6620746865206261636b656e642c20776520686176652074686520646576656c6f706d656e74206f66207468652066726f6e74656e642c204920646f6e2774206b6e6f7720696620456c69617320616c726561647920737461727465642e205765206861766520746865206c6f616465722c204920646f6e2774206b6e6f772e20646573206a6f7572732e20446f20796f75206861766520736f6d657468696e6720746f206164643f2800a4d7a7a402ff3602696401770c62697073706e6c67756d70652800a4d7a7a402ff3606696e64656e74017d002800a4d7a7a402ff36036469720177046175746f87a4d7a7a402ff3603097061726167726170680700a4d7a7a4029339060400a4d7a7a40294390a5468616e6b20796f752e2800a4d7a7a402933902696401770c6164637769707367657a6a662800a4d7a7a402933906696e64656e74017d002800a4d7a7a4029339036469720177046175746f87a4d7a7a402933903097061726167726170680700a4d7a7a402a239060400a4d7a7a402a3399401796f7520492077696c6c20646566696e6520697420616761696e2c206f6e20746865204a69726120736964652c20776520686176652066696e697368656420616c6c2074686520696e7374616c6c6174696f6e20616e64206d696e6f7220636f7272656374696f6e732074686174207468657265207765726520636f6d706172656420746f20746865206c6173742074696d652e2800a4d7a7a402a23902696401770c7571746f736f636a617771692800a4d7a7a402a23906696e64656e74017d002800a4d7a7a402a239036469720177046175746f87a4d7a7a402a23903097061726167726170680700a4d7a7a402bb3a060400a4d7a7a402bc3a9301596f757220535549207365656d73207265616c6c792077656c6c2070726570617265642e204920646f6e2774206b6e6f772c2070656f706c652c20697320746865726520616e797468696e6720746f206164643f2050757420796f757273656c6620696e206d792073686f65732c2049206a7573742077616e7420746f20676f20646f20736f6d657468696e6720656c73652e2800a4d7a7a402bb3a02696401770c6c6c62796e636a6a696c7a742800a4d7a7a402bb3a06696e64656e74017d002800a4d7a7a402bb3a036469720177046175746f87a4d7a7a402bb3a03097061726167726170680700a4d7a7a402d33b060400a4d7a7a402d43b5142757420776169742c20776520776572652074616c6b696e672061626f7574204a6972612c20627574206d617962652077652073686f756c6420707574206974206261636b20696e20636f6e746578742e2800a4d7a7a402d33b02696401770c716b66727678667a697771722800a4d7a7a402d33b06696e64656e74017d002800a4d7a7a402d33b036469720177046175746f87a4d7a7a402d33b03097061726167726170680700a4d7a7a402a93c060400a4d7a7a402aa3c584a6972612c207768617420697320697420666f723f205768793f20576865726520697320796f75722070726f6a6563743f204920686176652061206c6974746c652074726f75626c6520756e6465727374616e64696e672e2800a4d7a7a402a93c02696401770c6670786568637168737078612800a4d7a7a402a93c06696e64656e74017d002800a4d7a7a402a93c036469720177046175746f87a4d7a7a402a93c03097061726167726170680700a4d7a7a402863d060400a4d7a7a402873d46492077696c6c206c657420416e67c3a86c652074616c6b2061626f7574204a6972617a2c20686520697320746865206f6e652077686f206973206d61696e6c7920627573792e2800a4d7a7a402863d02696401770c78696977617165646f6e6d6a2800a4d7a7a402863d06696e64656e74017d002800a4d7a7a402863d036469720177046175746f87a4d7a7a402863d03097061726167726170680700a4d7a7a402d03d060400a4d7a7a402d13d46796f7520497320746869732e20497320697420706f737369626c6520746f207368617265207468652073637265656e20736f20796f752063616e20736565206265747465723f2800a4d7a7a402d03d02696401770c6576776e78626667707063632800a4d7a7a402d03d06696e64656e74017d002800a4d7a7a402d03d036469720177046175746f87a4d7a7a402d03d03097061726167726170680700a4d7a7a4029b3e060400a4d7a7a4029c3e0f5965732c206f6620636f757273652e2800a4d7a7a4029b3e02696401770c6d706f6a6b7470657771616e2800a4d7a7a4029b3e06696e64656e74017d002800a4d7a7a4029b3e036469720177046175746f87a4d7a7a4029b3e03097061726167726170680700a4d7a7a402af3e060400a4d7a7a402b03ef302536f2049276c6c20646f207468617420666f7220796f752e2042757420696620796f752077616e742c206265666f72652074616c6b696e6720746f206d652061626f7574204a6972612c20497420776f756c64206265206e69636520746f2074616c6b2061206c6974746c65206269742061626f7574207768617420796f75206861766520646f6e652c20796f757220676f616c732c20776865726520796f752061726520676f696e672c20746f207374727563747572652061206c6974746c65206269742e2049206d65616e2c20796f752072656d696e64206d65206f662061206775792077686f206275696c647320612063617220616e6420796f75277265206578706c61696e696e6720746f206d65207468617420796f75206772696e6420727562626572206275742061742074686520656e64206f662074686520646179204920756e6465727374616e64207468617420796f752077616e7420746f206d616b65206120746972652e204f6b61792e2800a4d7a7a402af3e02696401770c727977776262776d78766d612800a4d7a7a402af3e06696e64656e74017d002800a4d7a7a402af3e036469720177046175746f87a4d7a7a402af3e03097061726167726170680700a4d7a7a402a741060400a4d7a7a402a841c203536f2c207765207374617274656420776974682074686520746563686e6963616c20776f726b2c20617320796f75206b6e6f772c20616e6420746865206c6173742074696d652c2074776f207765656b732061676f2c207765206469646e2774207265616c6c79206861766520616e79207365636f6e6461727920747261636b73207965742e20576520646566696e6564206f75722074776f207365636f6e6461727920747261636b732c204120616e6420442c20576520666f756e6420697420636f6e73697374656e7420776974682074686520746563686e6963616c2074726561746d656e742e2061206d6f72652073656375726520746563686e6963616c20656e7669726f6e6d656e742c20736f20746f2070726f7465637420616e6420656e737572652074686174207468697320656e7669726f6e6d656e7420536f2c206974277320746865207365636f6e6461727920747261636b20412e20616e64207468652044207365636f6e6461727920747261636b207768696368206973206d6561737572652c207465737420616e64206f7074696d697a652074686520706572666f726d616e6365206f66206f757220696e207468652070726f6a6563742e2800a4d7a7a402a74102696401770c716576756c62686c7069656d2800a4d7a7a402a74106696e64656e74017d002800a4d7a7a402a741036469720177046175746f87a4d7a7a402a74103097061726167726170680700a4d7a7a402ee44060400a4d7a7a402ef44c1035765206469642074686573652074776f20747261636b7320696e207365636f6e64617279207363686f6f6c206265636175736520776520666f756e6420697420717569746520636f6d6d6f6e2077697468206120746563686e6963616c2070726f6a6563742e20416e6420666f7220746865206f7468657220747261636b732c206d617962652077652063616e20776f726b206f6e20697420746f6f2e205765276c6c2073656520626563617573652069742773206f6674656e20636f6d6d756e69636174696f6e20747261636b732074686174207765277665207365656e2e204974277320736f6d657468696e672074686174207765276c6c206861766520746f20636f6d652075702077697468206c617465722e2042757420666f72206e6f772c20776520646f6e27742066696e64206974207265616c6c7920696d706f7274616e7420746f20646f2074686520666f6c6c6f772d75702065766572792074776f207765656b732e2057652070726566657272656420746f2074616b6520746865736520747261636b732e20536f20746f20646f20746869732c20776520757365206120666f6c6c6f772d757020746f6f6c2063616c6c6564204a6972612e2800a4d7a7a402ee4402696401770c676678736d6e6c6d676978652800a4d7a7a402ee4406696e64656e74017d002800a4d7a7a402ee44036469720177046175746f87a4d7a7a402ee4403097061726167726170680700a4d7a7a402b448060400a4d7a7a402b54893025765206469646e27742063686f6f7365204769744875622050726f6a656374206265636175736520506572736f6e616c6c792c20492070726566657272656420746f20757365204a6972612e2049742773206120746f6f6c2074686174204920757365642061206c6f7420647572696e67206d7920747261696e696e6720696e206d616e6167656d656e74206f662070726f6a6563747320616e64206f74686572732e20546861742773207768792077652073746172746564206f6e2047697261206f6e20746869732070726f6a65637420616e642069742077617320617070726f766564206279206f7572204450522e2049276c6c2073686f7720796f752077686174206974206c6f6f6b73206c696b652e2800a4d7a7a402b44802696401770c7a67707a6f757076726c746b2800a4d7a7a402b44806696e64656e74017d002800a4d7a7a402b448036469720177046175746f87a4d7a7a402b44803097061726167726170680700a4d7a7a402cc4a060400a4d7a7a402cd4a4b536f20746865206769726166666520697320666f72207468652e2e2e204974277320666f722074686520636f6d706c656d656e74617279206f626a656374697665206e756d62657220312e2800a4d7a7a402cc4a02696401770c6c616376666277686b6f6e722800a4d7a7a402cc4a06696e64656e74017d002800a4d7a7a402cc4a036469720177046175746f87a4d7a7a402cc4a03097061726167726170680700a4d7a7a4029c4b060400a4d7a7a4029d4b7f596f75204974207761732061626f7574206964656e74696679696e67207468652070726f626c656d20616e64206974207761732061626f757420646566696e696e67207468652061726368697465637475726520616e6420686176696e67206120736f7274206f662072656c6961626c65206172636869746563747572652e2800a4d7a7a4029c4b02696401770c796577626565746f717277712800a4d7a7a4029c4b06696e64656e74017d002800a4d7a7a4029c4b036469720177046175746f87a4d7a7a4029c4b03097061726167726170680700a4d7a7a402a04c060400a4d7a7a402a14cf101416c736f2c207468617427732069742e2042757420697427732061206b696e64206f66206d616e6167656d656e7420746f6f6c2c206a75737420666f72207461736b20646576656c6f706d656e742e20497427732071756974652062617369632e2049742773206120626974206c696b652061204769744875622070726f6a6563742e204469737163632069732061207469636b6574696e6720746f6f6c207468617420616c6c6f777320796f7520746f206f7267616e697a6520796f757273656c6620696e20612067726f75702e20546865792063616e277420776f7272792061626f75742053616e204c756361732e2800a4d7a7a402a04c02696401770c766262707a7762687a7a74712800a4d7a7a402a04c06696e64656e74017d002800a4d7a7a402a04c036469720177046175746f87a4d7a7a402a04c03097061726167726170680700a4d7a7a402964e060400a4d7a7a402974e09796f75204f6b61792e2800a4d7a7a402964e02696401770c616e65696e66676163716a722800a4d7a7a402964e06696e64656e74017d002800a4d7a7a402964e036469720177046175746f87a4d7a7a402964e03097061726167726170680700a4d7a7a402a44e060400a4d7a7a402a54e2949276c6c20717569636b6c792073686f7720796f752077686174206974206c6f6f6b73206c696b652e2800a4d7a7a402a44e02696401770c75786f6976706d686a7a77732800a4d7a7a402a44e06696e64656e74017d002800a4d7a7a402a44e036469720177046175746f87a4d7a7a402a44e03097061726167726170680700a4d7a7a402d24e060400a4d7a7a402d34eb7034920696d6167696e6520796f75206b6e6f77206d652c20627574207468617427732069742e204e6f2c204c697a7a69652e2057686174206d61747465727320746f206d6520697320746f20756e6465727374616e6420746861742069742773206e6f7420736f206d7563682074686520746f6f6c20697473656c662c20486d6d3f2057686174206d61747465727320746f206d652069732057686174206861766520796f7520646f6e653f2057686572652061726520796f7520676f696e673f2057686174206172652074686520776f726b696e67206d6574686f64733f20576861742061726520796f7572206f626a656374697665733f20486f7720646f20796f7520776f726b3f204920646f6e2774206361726520696620796f7520757365204a6972612c204769744875622c20776861746576657220796f752077616e742e2042757420746f6461792c207765206469646e2774206576656e2074616c6b2061626f757420776865726520796f7527726520676f696e672c20796f75277265207468726f77696e67204a697261206174206d652e205468616e6b20796f752e20596f752073656520776861742049206d65616e3f2800a4d7a7a402d24e02696401770c6d7466697070637a767662762800a4d7a7a402d24e06696e64656e74017d002800a4d7a7a402d24e036469720177046175746f87a4d7a7a402d24e03097061726167726170680700a4d7a7a4028e52060400a4d7a7a4028f52970349207468696e6b20746865206669727374207468696e6720776f756c6420626520746f207361792c2077656c6c2c2068657265207765206172652c2077652068617665207375636820616e206f626a65637469766520746f20616368696576652e20546f20616368696576652074686973206f626a6563746976652c207765206861766520746f20646f20746869732c20746869732c207468697320616e6420746861742e20546f20646f20746869732c207468697320616e6420746861742c2077652061726520676f696e6720746f206f7267616e697a65206f757273656c76657320696e207375636820616e6420737563682061207761792e20416e6420746861742773207768617420776527726520676f696e6720746f2070757420696e20706c6163652e204f6b61792e20536f2c20796f752063686f736520746f2068656c702c2074686174277320676f6f642e204974207365656d7320746f206d652c20676976656e20796f75722070726f6a6563742c20697420646f65736e2774207365656d206c696b65206120626967206465616c2e2800a4d7a7a4028e5202696401770c6a7162616f757379627671742800a4d7a7a4028e5206696e64656e74017d002800a4d7a7a4028e52036469720177046175746f87a4d7a7a4028e5203097061726167726170680700a4d7a7a402aa55060400a4d7a7a402ab55a0015468656e2c2061637475616c6c792c206578706c61696e207768792e2057656c6c2c20766572792077656c6c2e20416e64207468656e207361792c204f4b2c206e6f7720746861742077652776652063686f73656e20746861742c20776861742061726520776520676f696e6720746f2070757420696e20706c61636520746f206d65657420746865206f626a656374697665733f205468616e6b20796f752e2800a4d7a7a402aa5502696401770c6f65727377627762766b676d2800a4d7a7a402aa5506696e64656e74017d002800a4d7a7a402aa55036469720177046175746f87a4d7a7a402aa5503097061726167726170680700a4d7a7a402cf56060400a4d7a7a402d056b5032e20466f72206e6f772c20776520686176656e2774206465636964656420746f20676f206279206120737072696e742073797374656d206265636175736520776520706c616e20746f20676f20627920737072696e74732c20627574207468652063757272656e74206f6e652c20746865206f6e6520746861742077696c6c2070726f6261626c7920636f6d6520736f6f6e2e2042757420706572736f6e616c6c792c20616e64206576656e20666f72207468652077686f6c652c2077652063686f736520746f20646f2074686174206265636175736520776520616c6c206172726976656420696e206f757220636f756e7472792c20736574746c656420696e2c207765207374617274656420636c617373657320616e6420616c6c2e20576520646f6e277420616c6c206e65636573736172696c792068617665207468652073616d6520617661696c6162696c69747920616e64206f74686572207468696e67732e20416e6420736f2c2077686174207765206469642077617320746f2068617665206120546865206d61696e207461736b20697320746f20637265617465206120736f6c696420666f756e646174696f6e2e2800a4d7a7a402cf5602696401770c6a737a6475706565736c63632800a4d7a7a402cf5606696e64656e74017d002800a4d7a7a402cf56036469720177046175746f87a4d7a7a402cf5603097061726167726170680700a4d7a7a402895a060400a4d7a7a4028a5aa8034120746563686e6963616c2070726f6a6563742c20736f206174206c6561737420686176696e672061204d5650206f6e206561636820736964652c206e6f74206e65636573736172696c792061204d56502c206265747765656e2074686520504f4320616e6420746865204d56502c207468617420697320746f207361792c20736f6d657468696e67207468617420776f726b7320726967687420746f206c6566742065766572797768657265206120736f6c6964206261736520697320656e6f756768206f6e2065616368206f6e20666f72206561636820706172742c20736f206f6e20746865206261636b656e642c207468652064617368626f6172642c20746865206c61756e636865722c20616c6c2074686573652070617274733f204f6e6365207468697320697320646f6e652c20647572696e672074686520636f6d696e67206d6f6e74682c2077652077696c6c2073657420757020737072696e747320746f20776f726b206f6e20697420616e64207468656e2077652077696c6c20686176652061206d6f726520726567756c617220666f6c6c6f772d7570206f6e20746861742e2800a4d7a7a402895a02696401770c7a736b646565646e6a6e756a2800a4d7a7a402895a06696e64656e74017d002800a4d7a7a402895a036469720177046175746f87a4d7a7a402895a03097061726167726170680700a4d7a7a402b65d060400a4d7a7a402b75d27536f2065766572796f6e65206d757374206275696c64206120626173655468617427732069742e2800a4d7a7a402b65d02696401770c646274757075727a616d686d2800a4d7a7a402b65d06696e64656e74017d002800a4d7a7a402b65d036469720177046175746f87a4d7a7a402b65d03097061726167726170680700a4d7a7a402e25d060400a4d7a7a402e35d514265747765656e20504f4320616e64204d56502c204d56502069732070726574747920676f6f642c2049207468696e6b2e204275742069742773206120626974206265747765656e207468652074776f2e2800a4d7a7a402e25d02696401770c636364677565746b687871642800a4d7a7a402e25d06696e64656e74017d002800a4d7a7a402e25d036469720177046175746f87a4d7a7a402e25d03097061726167726170680700a4d7a7a402b85e060400a4d7a7a402b95e604e6f2c20676f2061686561642e20536f2c2074686174206d65616e7320796f75206964656e7469666965642074686520706172746965733f2054686973206973206865722e20536f20776861742061726520746865736520706172746965733f2800a4d7a7a402b85e02696401770c7575726f6463666d6c79786a2800a4d7a7a402b85e06696e64656e74017d002800a4d7a7a402b85e036469720177046175746f87a4d7a7a402b85e03097061726167726170680700a4d7a7a4029d5f060400a4d7a7a4029e5fba03536f2c207765206861766520736f6d652070617274732e20576520686176652074686520626173696e2c20736f20686572652074686572652077696c6c20626520756820616c6c206f75722e2e2e206c696b652041504920616e64206f74686572732c20736f2069742773206b696e64206f66206f757220666f756e646174696f6e2e20416e6420746869732e2e2e2057652068617665207468652064617368626f6172642c207768696368206973206d6f726520737570657266696369616c2c206974277320746865207765622070617274207768657265207468652068656c706572732077696c6c20636f6e6e6563742e2049742773206120736c696768746c7920736570617261746520706172742c20776865746865722069742773206120747261636b206f722061206261636b696e6720747261636b2e205468656e207765206861766520746865206c61756e636865722c20456c6961732069732074616b696e672063617265206f6620697420666f72206e6f772e20756d2c20466f72206e6f772c2069742773207468726565206269672070617274696573207468617420636f6e6e65637420746f2065616368206f746865722e2800a4d7a7a4029d5f02696401770c7a6d7a6c65616873656d68612800a4d7a7a4029d5f06696e64656e74017d002800a4d7a7a4029d5f036469720177046175746f87a4d7a7a4029d5f03097061726167726170680700a4d7a7a402dc62060400a4d7a7a402dd629801416e64207468656e207468657265206d69676874206265206f74686572207468696e677320746861742077696c6c20636f6d65206f7665722069742c2062757420746861742773206e6f74207269676874206e6f772e20536f2c207468617427732069742e20576527726520676f696e6720746f20736179207468617427732074687265652062696720706172747320666f72206e6f772e2800a4d7a7a402dc6202696401770c75676b77706a7470706f6d792800a4d7a7a402dc6206696e64656e74017d002800a4d7a7a402dc62036469720177046175746f87a4d7a7a402dc6203097061726167726170680700a4d7a7a402f963060400a4d7a7a402fa637c4261636b656e642c2044617368626f61726420616e64204c61756e636865722e205468617427732072696768742e204f68205468617420776f726b732e204f6b61792e20466f72206e6f772c206f6e20746865206d616e6461746f7279206f626a656374697665732c20796f75206861766520616476616e6365643f2800a4d7a7a402f96302696401770c6d637864796362636d6c73782800a4d7a7a402f96306696e64656e74017d002800a4d7a7a402f963036469720177046175746f87a4d7a7a402f96303097061726167726170680700a4d7a7a402fa64060400a4d7a7a402fb64ec01756820576520636f6e74696e7565207768656e2065766572796f6e6520776f726b73206f6e206f757220736964652c20776520646f63756d656e74206f75722070617274206f662074686520636f64652e2057652074727920746f206d616b6520736f6d65205052206973737565732c2062757420656163682074696d65207468652070617274206f662074686520636f64652069732061206c6974746c6520646f63756d656e746564206174206c656173742e20416e6420776527726520747279696e6720746f20646f63756d656e7420697420617320626573742077652063616e20666f72206e6f772e2800a4d7a7a402fa6402696401770c67646d6e7377776a746362712800a4d7a7a402fa6406696e64656e74017d002800a4d7a7a402fa64036469720177046175746f87a4d7a7a402fa6403097061726167726170680700a4d7a7a402eb66060400a4d7a7a402ec664c576169742c207765206d6179206e6f74206861766520756e64657273746f6f642e20576861742061726520746865206d616e6461746f7279206f626a6563746976657320666f7220796f753f2800a4d7a7a402eb6602696401770c637972706c68617179636d752800a4d7a7a402eb6606696e64656e74017d002800a4d7a7a402eb66036469720177046175746f87a4d7a7a402eb6603097061726167726170680700a4d7a7a402bc67060400a4d7a7a402bd671674686520536f20556d20427574204920646f6e27742e2800a4d7a7a402bc6702696401770c716b6e74776e6b6568696b612800a4d7a7a402bc6706696e64656e74017d002800a4d7a7a402bc67036469720177046175746f87a4d7a7a402bc6703097061726167726170680700a4d7a7a402d767060400a4d7a7a402d867e6036d6f69206a2761692070617320636520717569206d652064c3a972616e6765206327657374206cc3a020636f6d6d656e7420646972612074686520617070726f78696d617465206e756d626572206f6620796f757220616e73776572732049206d65616e2c20746865206f626a65637469766573206f6620545241432c206d616e6461746f72792c20636f6d706c656d656e7461727920616e6420736f206f6e2c206974206d75737420626520736f6d657468696e6720707265636973652e20596f7520646f6e2774206861766520746f2074656c6c206d652c2049207468696e6b20746865206f626a65637469766573206172652061626f757420746861742e2049206d65616e2c20746f6e696768742c20746865204672656e6368207465616d20617420746865205374616465206465204672616e63652c2074686579206b6e6f772077686572652074686579206861766520746f2073636f72652074686520676f616c2e2079656168207468652077616c6c20666f6f74207265626f756e64206d61796265207765206861766520746f206d6f7665207468652062616c6c20666f727761726420746f776172647320746865206f68207368697420596f752068617665206120646f63756d656e742053747564656e742047756964652c206f6b61793f2800a4d7a7a402d76702696401770c63727273786a786270616f722800a4d7a7a402d76706696e64656e74017d002800a4d7a7a402d767036469720177046175746f87a4d7a7a402d76703097061726167726170680700a4d7a7a402c06b060400a4d7a7a402c16bb403496e20776869636820746865726520617265206f626a6563746976657320616e6420796f752061726520746f6c6420696620796f7520646f6e2774206861766520746865206f626a6563746976652c20796f7520776f6e2774206861766520796f75722049502e20596f75206861766520746f2072656164207468656d2c206b6e6f77207468656d2e20492074656c6c20796f752c207768617420697320796f7572206f626a65637469766520746861742077652063616e2e2e2e206d616e6461746f7279206e756d626572206f6e652c20796f752074656c6c206d652c20796561682c207468617427732069742e20596f752073686f756c64206b6e6f7720697420616e6420796f752073686f756c64206861766520616c7265616479207374617274656420776f726b696e67206f6e2069742e204f6b61793f204875683f204b6e6f77696e67207468617420746865206c6173742074696d652049206d61646520796f75206e6f74696365207468617420796f75206861646e277420726561642074686520677569646520616e64207468617420796f75206162736f6c7574656c792068616420746f20726561642069742e2800a4d7a7a402c06b02696401770c7978746b63746b6d747678622800a4d7a7a402c06b06696e64656e74017d002800a4d7a7a402c06b036469720177046175746f87a4d7a7a402c06b03097061726167726170680700a4d7a7a402f96e060400a4d7a7a402fa6ed8024f6b61792e20416e797761792e2049276d2061206c6974746c6520616e6e6f79696e6720796f752074686572652062656361757365206966207468657265206973206e6f206f6e652077686f206d6f76657320796f752c20796f7520756e6465727374616e6420776861742049206d65616e2e205765206861766520746f207265616420746f67657468657220746865206f626a656374697665732c207468617420796f7520617265207665727920636c6561722077697468207468617420616e64207468617420796f75207265616c697a65207468656d2e20446f20796f7520686176652074686520646f63756d656e7420756e64657220796f757220657965733f2055682c2077652e20536f20697427732053747564656e742047756964652e20536f20736861726520697420736f20746861742077652063616e20616c6c206167726565206f6e207768617420776520726561642e2800a4d7a7a402f96e02696401770c786d6c796f7166646d7865752800a4d7a7a402f96e06696e64656e74017d002800a4d7a7a402f96e036469720177046175746f87a4d7a7a402f96e03097061726167726170680700a4d7a7a402d671060400a4d7a7a402d77108416c6c657a2d792e2800a4d7a7a402d67102696401770c676d686a6f7a7367716276782800a4d7a7a402d67106696e64656e74017d002800a4d7a7a402d671036469720177046175746f87a4d7a7a402d67103097061726167726170680700a4d7a7a402e371060400a4d7a7a402e47118596f752063616e20646f2069742e20476f2061686561642e2800a4d7a7a402e37102696401770c796f74636a6a747177726c732800a4d7a7a402e37106696e64656e74017d002800a4d7a7a402e371036469720177046175746f87a4d7a7a402e37103097061726167726170680700a4d7a7a4028072060400a4d7a7a4028172214f6820796f75204920646f6e2774206b6e6f7720686f7720746f20646f2069742e2800a4d7a7a402807202696401770c6b6663716f696a697670746c2800a4d7a7a402807206696e64656e74017d002800a4d7a7a4028072036469720177046175746f87a4d7a7a402807203097061726167726170680700a4d7a7a402a672060400a4d7a7a402a7724349276c6c206265207269676874206261636b207768696c6520796f752073686172652e2049276d20636f6d696e672e20476f2061686561642c20676f2061686561642e2800a4d7a7a402a67202696401770c676f6e747070767a6b76646e2800a4d7a7a402a67206696e64656e74017d002800a4d7a7a402a672036469720177046175746f87a4d7a7a402a67203097061726167726170680700a4d7a7a402ee72060400a4d7a7a402ef72104920776173207468657265596561682e2800a4d7a7a402ee7202696401770c7a74717465746d77676965672800a4d7a7a402ee7206696e64656e74017d002800a4d7a7a402ee72036469720177046175746f87a4d7a7a402ee7203097061726167726170680700a4d7a7a4028373060400a4d7a7a40284731149742773206a75737420746861742e2e2e2800a4d7a7a402837302696401770c687966656d6e69636d777a682800a4d7a7a402837306696e64656e74017d002800a4d7a7a4028373036469720177046175746f87a4d7a7a402837303097061726167726170680700a4d7a7a4029973060400a4d7a7a4029a7315596561682c20666f72207468652073637265656e2e2800a4d7a7a402997302696401770c7061766f7264777368746a612800a4d7a7a402997306696e64656e74017d002800a4d7a7a4029973036469720177046175746f87a4d7a7a402997303097061726167726170680700a4d7a7a402b373060400a4d7a7a402b47311536f20746861742773206e6f742069742e2800a4d7a7a402b37302696401770c76677062686a6b7265776d782800a4d7a7a402b37306696e64656e74017d002800a4d7a7a402b373036469720177046175746f87a4d7a7a402b37303097061726167726170680700a4d7a7a402c973060400a4d7a7a402ca731654686174277320746865207365636f6e64206f6e652e2800a4d7a7a402c97302696401770c6d7773726d7a62696d7069752800a4d7a7a402c97306696e64656e74017d002800a4d7a7a402c973036469720177046175746f87a4d7a7a402c97303097061726167726170680700a4d7a7a402e473060400a4d7a7a402e57330506572666563742e20576861743f2054686174277320746865206669727374206f626a6563746976652e20576861743f2800a4d7a7a402e47302696401770c6a686963647771756f6d77722800a4d7a7a402e47306696e64656e74017d002800a4d7a7a402e473036469720177046175746f87a4d7a7a402e47303097061726167726170680700a4d7a7a4029974060400a4d7a7a4029a745b416e6420736f2e2e2e204265666f72652074686520656e64206f66204f63746f6265722c20776520686164207468652070726f626c656d20636861726163746572697a6174696f6e2e20596561682c206861726420706f696e742e2800a4d7a7a402997402696401770c6e65797377716f72746c6c752800a4d7a7a402997406696e64656e74017d002800a4d7a7a4029974036469720177046175746f87a4d7a7a402997403097061726167726170680700a4d7a7a402f974060400a4d7a7a402fa7490015468617427732069742e20496e204672656e63682c20746865206e756d626572206f6e65206f626a65637469766520697320746f206f7267616e697a6520796f757220746563686e6f6c6f676963616c207761766520616e64206578706c6f697420697420746f206c69667420746865206861726420706f696e742e2070726f6a656374204f6b61792e20576861743f2800a4d7a7a402f97402696401770c6a68647478706f70646b71762800a4d7a7a402f97406696e64656e74017d002800a4d7a7a402f974036469720177046175746f87a4d7a7a402f97403097061726167726170680700a4d7a7a4028e76060400a4d7a7a4028f760c50757420697420686572652e2800a4d7a7a4028e7602696401770c6f627665796b757876716e612800a4d7a7a4028e7606696e64656e74017d002800a4d7a7a4028e76036469720177046175746f87a4d7a7a4028e7603097061726167726170680700a4d7a7a4029f76060400a4d7a7a402a076044b65792e2800a4d7a7a4029f7602696401770c6e757371767a616d6c666e682800a4d7a7a4029f7606696e64656e74017d002800a4d7a7a4029f76036469720177046175746f87a4d7a7a4029f7603097061726167726170680700a4d7a7a402a876060400a4d7a7a402a9760648656c6c6f2e2800a4d7a7a402a87602696401770c656b737465696478767168672800a4d7a7a402a87606696e64656e74017d002800a4d7a7a402a876036469720177046175746f87a4d7a7a402a87603097061726167726170680700a4d7a7a402b376060400a4d7a7a402b4767d446f20796f75206861766520616e2069646561206f66207768617420636f756c642062652074686520686172642070617274206f6620796f75722070726f6a65637420746f6461793f20446f20796f75206861766520616e2069646561206f6620686f7720746f206d616b6520746865205665696c20546563686e6f3f2800a4d7a7a402b37602696401770c67696f6473716a756c61717a2800a4d7a7a402b37606696e64656e74017d002800a4d7a7a402b376036469720177046175746f87a4d7a7a402b37603097061726167726170680700a4d7a7a402b577060400a4d7a7a402b6770f4e6f2c206e6f74207265616c6c792e2800a4d7a7a402b57702696401770c76716973796463786d6d66692800a4d7a7a402b57706696e64656e74017d002800a4d7a7a402b577036469720177046175746f87a4d7a7a402b57703097061726167726170680700a4d7a7a402c977060400a4d7a7a402ca776349276d20736f7272792e204974277320636f6d706c69636174656420746f20646566696e652e205468657265277320612076697375616c697a6572205468657265277320612076697375616c697a6572204f6b61792c20776527726520616c6c2e2e2e2800a4d7a7a402c97702696401770c67706e6d7577707a696c64772800a4d7a7a402c97706696e64656e74017d002800a4d7a7a402c977036469720177046175746f87a4d7a7a402c97703097061726167726170680700a4d7a7a402b178060400a4d7a7a402b278c203536f2c20666f7220746865206861726420706f696e742c20492063616e27742068656c7020796f752e204920636f756c642c20627574204920646f6e27742077616e7420746f2e2046697273742c206974277320757020746f20796f7520746f20646f2069742e204f682e204f7267616e697a696e67207468697320746563686e6f6c6f6779205468616e6b20796f752e204f682e20546f206f7267616e697a652074686520746563686e6963616c206461792c207768617420492061647669736520796f75596561682e205365653f2042757420596f752061736b20746865207175657374696f6e732e20417320757375616c2c206974277320746865206f6c6420746563686e6f6c6f67792e20486f772061726520776520676f696e6720746f20646f2069743f20486f77206d7563682074696d652077696c6c207765207370656e64206f6e2069743f205768617420646f2077652077616e7420746f20676574206f7574206f662069743f20486f772077696c6c207368652062652061626c6520746f2068656c7020757320696e207468652070726f6a6563743f204f6b61793f20576865726520646f657320697420696e746567726174652c206574632e2800a4d7a7a402b17802696401770c636c746274786a6c686b6d6b2800a4d7a7a402b17806696e64656e74017d002800a4d7a7a402b178036469720177046175746f87a4d7a7a402b17803097061726167726170680700a4d7a7a402f87b060400a4d7a7a402f97bae03536f20746865206964656120697320746f2073617920796f752061726520666976652c20596f752077696c6c207361792c20224f4b2c20706572207765656b2c2065766572796f6e65207370656e647320616e20686f7572206f66205665696c6c6520546563686e6f2e2220447572696e67207468697320686f75722c20776520646f2072657365617263682e2041742074686520656e64206f66207468697320686f75722c204964656e746966792074686520747261636b732e205965732c2077652072656d6f76652074686520747261636b2c20776520746573742069742c20776520646f206120504f432e205965732c20697420776f726b732e204e6f2c20697420646f65736e277420776f726b2e20576520646f6e27742072656d656d6265722074686520747261636b2c20776520646f6e27742072656d656d62657220697420666f72207468697320726561736f6e2e2041667465722074686520504f432c2069732069742075736566756c3f204973206974206e6f743f20496620697427732075736566756c2c2077686572652077696c6c20697420676f20696e207468652070726f6a6563743f2800a4d7a7a402f87b02696401770c6f70776265686d79697970692800a4d7a7a402f87b06696e64656e74017d002800a4d7a7a402f87b036469720177046175746f87a4d7a7a402f87b03097061726167726170680700a4d7a7a402ab7f060400a4d7a7a402ac7ff801416c6c206f662074686973206d75737420626520636f6e7369676e65642c206d616b6520646f63756d656e74732050726f6475636520746865736520646f63756d656e747320626563617573652074686174277320776861742077652772652061736b696e6720796f7520666f722e20576527726520676f696e6720746f2061736b20796f7520746f206a75737469667920796f757220746563686e6f6c6f676963616c20616476616e63652e205765277265206e6f7420676f696e6720746f2061736b20796f7520746f20646f2069742c20776527726520676f696e6720746f2061736b20796f7520746f206a7573746966792069742e2800a4d7a7a402ab7f02696401770c70646d7771636566746279722800a4d7a7a402ab7f06696e64656e74017d002800a4d7a7a402ab7f036469720177046175746f87a4d7a7a402ab7f03097061726167726170680700a4d7a7a402a88101060400a4d7a7a402a981013c536f2c20746865736520646f63756d656e74732c20666f72206578616d706c652c2044696420746865792067657420796f7520746f20646f2069743f2800a4d7a7a402a8810102696401770c64616463626c6b706c706f742800a4d7a7a402a8810106696e64656e74017d002800a4d7a7a402a88101036469720177046175746f87a4d7a7a402a8810103097061726167726170680700a4d7a7a402e98101060400a4d7a7a402ea810139416c6c20746865207765656b733f205765206a757374206b656570207468656d206f6e20746865207369646520746f2070726f76652069742e2800a4d7a7a402e9810102696401770c65707475736a7a636c6c707a2800a4d7a7a402e9810106696e64656e74017d002800a4d7a7a402e98101036469720177046175746f87a4d7a7a402e9810103097061726167726170680700a4d7a7a402a78201060400a4d7a7a402a8820185024168206e6f2c2049206d65616e2c207965732c2077652077696c6c206469736375737320697420746f6765746865722c207468617427732074686520676f616c206f66206f7572206d656574696e67732c206f6b61793f20536f20796f752063616e2067697665207468656d20746f20757320696e20616476616e636520616e6420736f206f6e2c207468617427732074686520676f616c206f66206f75722072656e64657a766f75732e204275742061626f766520616c6c2c20776527726520676f696e6720746f206861766520746f2070726f64756365207468656d206f6e2074686520646179206f662074686520676f2d6e6f2d676f2e205468616e6b20796f752e2800a4d7a7a402a7820102696401770c6a79626172656d7a706277712800a4d7a7a402a7820106696e64656e74017d002800a4d7a7a402a78201036469720177046175746f87a4d7a7a402a7820103097061726167726170680700a4d7a7a402b18401060400a4d7a7a402b28401734f4b2c20736f2074686174277320686f7720796f75206861766520746f206c65616420796f757220796f757220746563686e6f2077617463682e20596f75206861766520746f2070726f647563652e20536561726368696e672e205665726966792e20436f6e7369646572652e204f6b61792e2800a4d7a7a402b1840102696401770c6770757678706f786b6f70722800a4d7a7a402b1840106696e64656e74017d002800a4d7a7a402b18401036469720177046175746f87a4d7a7a402b1840103097061726167726170680700a4d7a7a402a98501060400a4d7a7a402aa8501054f6b61792e2800a4d7a7a402a9850102696401770c696d65696c62696a737679652800a4d7a7a402a9850106696e64656e74017d002800a4d7a7a402a98501036469720177046175746f87a4d7a7a402a9850103097061726167726170680700a4d7a7a402b38501060400a4d7a7a402b48501094c6574277320676f2e2800a4d7a7a402b3850102696401770c767866636573676f6a6f6e782800a4d7a7a402b3850106696e64656e74017d002800a4d7a7a402b38501036469720177046175746f87a4d7a7a402b3850103097061726167726170680700a4d7a7a402c18501060400a4d7a7a402c2850170746f20416e6420666f7220746865207365636f6e64206f626a6563746976652c2077686963682077617320616c736f20737570706f73656420746f2062652061742074686520656e64206f66204f63746f6265722c20536f2c207468652073656172636820666f72207365747570732e2800a4d7a7a402c1850102696401770c7371777563696b7070616b762800a4d7a7a402c1850106696e64656e74017d002800a4d7a7a402c18501036469720177046175746f87a4d7a7a402c1850103097061726167726170680700a4d7a7a402b68601060400a4d7a7a402b78601ab03536f207468617420696e206d79206f70696e696f6e206973206e6f7420746865207365636f6e64206f626a6563746976652e20596f75206d69782065766572797468696e672c20796f75206861766520746f2062652073757065722070726563697365207768656e20796f752074616c6b2e20546861742773206e6f7420746865207365636f6e64206f626a6563746976652c207765277265207374696c6c20696e20746865206669727374206f6e652e20576861743f205965732c20696620796f752074656c6c206d65207365636f6e64206f626a6563746976652c2049207468696e6b206f66207365636f6e64206f626a656374697665206f6620545241432e20596f7572207365636f6e6420676f616c20697320746f20537472756374757265642c20646f63756d656e7465642c20616e642072656c6961626c652e204f6b61793f20536f2074686174277320676f696e6720746f2062652065766572797468696e67207468617420697320617263686974656374757265206469616772616d732e20646f63756d656e746174696f6e2c2043492f43442c207465737420706c616e2c206574632e2800a4d7a7a402b6860102696401770c6a66666c7a7a77666b74746e2800a4d7a7a402b6860106696e64656e74017d002800a4d7a7a402b68601036469720177046175746f87a4d7a7a402b6860103097061726167726170680700a4d7a7a402e68901060400a4d7a7a402e7890156436869702e204f6b61792e205768656e20776520646f20646f632c2077652061736b206f757273656c76657320776879207765206469642069742c207768617420776520646f2c20686f77207765206469642069742e2800a4d7a7a402e6890102696401770c767979776c72616e79736d6b2800a4d7a7a402e6890106696e64656e74017d002800a4d7a7a402e68901036469720177046175746f87a4d7a7a402e6890103097061726167726170680700a4d7a7a402c18a01060400a4d7a7a402c28a01054f6b61792e2800a4d7a7a402c18a0102696401770c6c6f6666727469756c7165712800a4d7a7a402c18a0106696e64656e74017d002800a4d7a7a402c18a01036469720177046175746f87a4d7a7a402c18a0103097061726167726170680700a4d7a7a402cb8a01060400a4d7a7a402cc8a0189014f6b61793f2049742773206e6f74207468652073616d6520617320646f696e672041207475746f7269616c3f20666f72206120757365722c20746f20646f2061206d616e20666f7220616e2061646d696e6973747261746f72206f7220746f20646f20616e2061727469636c6520666f72206120726573656172636865722e204e6f20646f7562742e2800a4d7a7a402cb8a0102696401770c756562786367687866766d622800a4d7a7a402cb8a0106696e64656e74017d002800a4d7a7a402cb8a01036469720177046175746f87a4d7a7a402cb8a0103097061726167726170680700a4d7a7a402d98b01060400a4d7a7a402da8b01114c6f6f6b2061742074686174206775792e2800a4d7a7a402d98b0102696401770c6c787a7a62736d69636e68792800a4d7a7a402d98b0106696e64656e74017d002800a4d7a7a402d98b01036469720177046175746f87a4d7a7a402d98b0103097061726167726170680700a4d7a7a402ef8b01060400a4d7a7a402f08b016c536f20796f75207468696e6b2061626f7574596f75207468696e6b2061626f75742074686520646966666572656e74207479706573206f6620646f63732e20646966666572656e74207479706573206f662070656f706c6520616e6420686f77206974206d6174636865732e2800a4d7a7a402ef8b0102696401770c777a676c76777170736372672800a4d7a7a402ef8b0106696e64656e74017d002800a4d7a7a402ef8b01036469720177046175746f87a4d7a7a402ef8b0103097061726167726170680700a4d7a7a402e08c01060400a4d7a7a402e18c01114f6b61792c207468617420776f726b732e2800a4d7a7a402e08c0102696401770c7661727669666776697875762800a4d7a7a402e08c0106696e64656e74017d002800a4d7a7a402e08c01036469720177046175746f87a4d7a7a402e08c0103097061726167726170680700a4d7a7a402f68c01060400a4d7a7a402f78c01e3014973207468617420676f6f6420666f7220796f753f202d53616d65207468696e672c206f6e2074686520636f6d706c656d656e74617279206f626a656374697665732c207468652074776f2074686572652e204d6561737572652c20746573742c206f7074696d697a652e204f6b61792e2053616d65207468696e672c207265666c656374696f6e206f6e205768617420646f207765207365742075703f205768617420646f2077652077616e7420746f206d6561737572653f204f6e63652077652068617665206d656173757265642069742c20776520616e616c797a652069742e2800a4d7a7a402f68c0102696401770c61647a6971696d6267636a702800a4d7a7a402f68c0106696e64656e74017d002800a4d7a7a402f68c01036469720177046175746f87a4d7a7a402f68c0103097061726167726170680700a4d7a7a402de8e01060400a4d7a7a402df8e01094920676f742069742e2800a4d7a7a402de8e0102696401770c76706d68706a62777370656b2800a4d7a7a402de8e0106696e64656e74017d002800a4d7a7a402de8e01036469720177046175746f87a4d7a7a402de8e0103097061726167726170680700a4d7a7a402ec8e01060400a4d7a7a402ed8e01e7017765206d6f6469667920616e64207765207265616e616c797a652e2049742773206e6f74206a7573742074686174207765206d656173757265642069742c2077652772652068617070792e20312e3132206d65746572732c2067726561742e204e6f2e205765206d65617375726520736f6d657468696e672c2077652064656475636520706572666f726d616e63652070726f626c656d73206f72206e6f742c207765207361792c2022486572652c20776527726520676f696e6720746f206d6f646966792074686973207468696e672220616e64207765206d65617375726520616761696e2e2800a4d7a7a402ec8e0102696401770c6466616b67736771737461622800a4d7a7a402ec8e0106696e64656e74017d002800a4d7a7a402ec8e01036469720177046175746f87a4d7a7a402ec8e0103097061726167726170680700a4d7a7a402d89001060400a4d7a7a402d990010c546865726520776520676f2e2800a4d7a7a402d8900102696401770c627170696c6e6378746865632800a4d7a7a402d8900106696e64656e74017d002800a4d7a7a402d89001036469720177046175746f87a4d7a7a402d8900103097061726167726170680700a4d7a7a402e99001060400a4d7a7a402ea90011b4f6b61792c206973207468617420676f6f6420666f7220796f753f2800a4d7a7a402e9900102696401770c796a6469706a7a77766379672800a4d7a7a402e9900106696e64656e74017d002800a4d7a7a402e99001036469720177046175746f87a4d7a7a402e9900103097061726167726170680700a4d7a7a402899101060400a4d7a7a4028a910111536f20536f2057686174207468652e2e2e2800a4d7a7a40289910102696401770c62746871766a72736a756f642800a4d7a7a40289910106696e64656e74017d002800a4d7a7a402899101036469720177046175746f87a4d7a7a40289910103097061726167726170680700a4d7a7a4029f9101060400a4d7a7a402a09101ea025761697420776861743f204f6e636520616761696e2c20796f75206861766520746f207265616420746865206f626a6563746976657320616e64207468656e2074656c6c20796f757273656c66207768617420746f206578706563742c207768617420746f2065787065637420617320616e206f75747075742c207768617420746f20646f2e20466f722077686f6d2073686f756c64204920646f2069743f205468616e6b20796f752e20756d20496e207468697320646f63756d656e742c20796f75206861766520746865206c697374206f6620737570706c69657320746f20737570706c792e205468696e6b2061626f7574206c6f6f6b696e672061742069742e204f6b61792e20446f20796f75206861766520616e79206f7267616e697a6174696f6e2070726f626c656d7320696e207468652067726f75703f20476976656e207468652064697374616e63652c2077686572652061726520796f752063757272656e746c793f2800a4d7a7a4029f910102696401770c736a6f67616a636b6d6974692800a4d7a7a4029f910106696e64656e74017d002800a4d7a7a4029f9101036469720177046175746f87a4d7a7a4029f910103097061726167726170680700a4d7a7a4028e9401060400a4d7a7a4028f94019a0157652068617665206f6e6520696e204765726d616e792c20696e204265726c696e2c2074776f20696e204972656c616e642e2044756b617320616e6420416c6578616e64726520617265206e6f742074686572652c20696e204765726d616e79207765206861766520456e7a6f2c20696e2053776564656e207765206861766520456c69617320616e64204920616d20696e2043616e6164612e2800a4d7a7a4028e940102696401770c7a736f68626b7763746a66612800a4d7a7a4028e940106696e64656e74017d002800a4d7a7a4028e9401036469720177046175746f87a4d7a7a4028e940103097061726167726170680700a4d7a7a402ad9501060400a4d7a7a402ae9501535965732c207468617427732069743a2053776564656e2c204265726c696e2c204475626c696e20616e64205175656265632e20416e6420796f75206172652045706974656368204d6f6e7470656c6c6965723f2800a4d7a7a402ad950102696401770c737274707268637870756f782800a4d7a7a402ad950106696e64656e74017d002800a4d7a7a402ad9501036469720177046175746f87a4d7a7a402ad950103097061726167726170680700a4d7a7a402859601060400a4d7a7a402869601164d6f6e7470656c6c6965722c20696e2050617269732e2800a4d7a7a40285960102696401770c71737a6f656f77657367726b2800a4d7a7a40285960106696e64656e74017d002800a4d7a7a402859601036469720177046175746f87a4d7a7a40285960103097061726167726170680700a4d7a7a402a09601060400a4d7a7a402a196012a596561682e20596561682c204d6f6e7470656c6c6965722c2050617269732c207468617427732069743f2800a4d7a7a402a0960102696401770c626464707a7775746874676a2800a4d7a7a402a0960106696e64656e74017d002800a4d7a7a402a09601036469720177046175746f87a4d7a7a402a0960103097061726167726170680700a4d7a7a402cf9601060400a4d7a7a402d096012b416c6578616e6472652c20686520636f6d65732066726f6d2050617269732e205468617420776f726b732e2800a4d7a7a402cf960102696401770c636c6c6971676c62787a616a2800a4d7a7a402cf960106696e64656e74017d002800a4d7a7a402cf9601036469720177046175746f87a4d7a7a402cf960103097061726167726170680700a4d7a7a402ff9601060400a4d7a7a402809701784f4b2e204265666f7265204920666f726765742c20646f20796f75206861766520616e206964656120666f7220746865206e657874206d656574696e673f20536f2c207468656f7265746963616c6c792c2069742073686f756c6420626520746865207765656b206f66204f63746f62657220313974682e2800a4d7a7a402ff960102696401770c7979696672756b69677267752800a4d7a7a402ff960106696e64656e74017d002800a4d7a7a402ff9601036469720177046175746f87a4d7a7a402ff960103097061726167726170680700a4d7a7a402fc9701060400a4d7a7a402fd97018d0349276d20736f20736572696f75732e204d732e204578786f6e2e20576527726520616c6c207374617274696e6720746f2068617665206f75722066696e616c206d6f6d656e74732e20496e20616e7920636173652c207468697320697320746865206361736520666f7220416c6578616e6472652d456d65722e2057652061726520626567696e6e696e6720746f2068617665206f75722074696d6520666f722074686520646566696e69746976652e20416e64206f6e204f63746f6265722031392c2049742773206e6f742061207465737420706572696f6420666f72206d652c20736f2049276c6c20686176652061206c6f74206f6620667265652074696d652e204f6b61792e204920776f756c64206c696b6520746f20646f206c6573732074686973207765656b2c206265636175736520697427732061207765656b206f66206578616d732c206f66206d69642d73657373696f6e732e205468616e6b20796f752e2049206861766520616e206578616d20657665727920646179206f6e2074686973207765656b2e2800a4d7a7a402fc970102696401770c7566787273756e68776576722800a4d7a7a402fc970106696e64656e74017d002800a4d7a7a402fc9701036469720177046175746f87a4d7a7a402fc970103097061726167726170680700a4d7a7a4028e9b01060400a4d7a7a4028f9b0143536f20696620776520646f2046726964617920313674682c2049742773206265656e2074776f207765656b7320696e7374656164206f662074687265652e20486d6d2e2800a4d7a7a4028e9b0102696401770c67707561646d7379677172792800a4d7a7a4028e9b0106696e64656e74017d002800a4d7a7a4028e9b01036469720177046175746f87a4d7a7a4028e9b0103097061726167726170680700a4d7a7a402d69b01060400a4d7a7a402d79b0162427574204920686176656e277420646f6e6520616e797468696e672074686973207765656b2e204920646f6e2774206d696e642e204672696461792c2031362c2049276d2066696e652e2049276d2066696e652077697468207468617420746f6f2e2800a4d7a7a402d69b0102696401770c706a7874786c7761687a79642800a4d7a7a402d69b0106696e64656e74017d002800a4d7a7a402d69b01036469720177046175746f87a4d7a7a402d69b0103097061726167726170680700a4d7a7a402bd9c01060400a4d7a7a402be9c010f506f6b656d6f6e207761732069743f2800a4d7a7a402bd9c0102696401770c6f726e74776f667272706f6f2800a4d7a7a402bd9c0106696e64656e74017d002800a4d7a7a402bd9c01036469720177046175746f87a4d7a7a402bd9c0103097061726167726170680700a4d7a7a402d19c01060400a4d7a7a402d29c01195965732c207468657265206973206e6f2070726f626c656d2e2800a4d7a7a402d19c0102696401770c6277626769767a73616b74752800a4d7a7a402d19c0106696e64656e74017d002800a4d7a7a402d19c01036469720177046175746f87a4d7a7a402d19c0103097061726167726170680700a4d7a7a402ef9c01060400a4d7a7a402f09c0105576861743f2800a4d7a7a402ef9c0102696401770c706164747770746f69726c752800a4d7a7a402ef9c0106696e64656e74017d002800a4d7a7a402ef9c01036469720177046175746f87a4d7a7a402ef9c0103097061726167726170680700a4d7a7a402f99c01060400a4d7a7a402fa9c01105965732c2049207468696e6b20736f2e2800a4d7a7a402f99c0102696401770c73736977627776636e6171702800a4d7a7a402f99c0106696e64656e74017d002800a4d7a7a402f99c01036469720177046175746f87a4d7a7a402f99c0103097061726167726170680700a4d7a7a4028e9d01060400a4d7a7a4028f9d0171576520706c616e20746865206172726976616c2e20446f20796f75207072657061726520746865207468696e67206c696b65206c6173742074696d653f205468616e6b20796f752e204f6b61792e2041726520796f7520707265706172696e6720666f7220746865206d656574696e673f2800a4d7a7a4028e9d0102696401770c646767687464716b7164786a2800a4d7a7a4028e9d0106696e64656e74017d002800a4d7a7a4028e9d01036469720177046175746f87a4d7a7a4028e9d0103097061726167726170680700a4d7a7a402849e01060400a4d7a7a402859e0109497420776f726b732e2800a4d7a7a402849e0102696401770c6f74766e707a6e6e7364666e2800a4d7a7a402849e0106696e64656e74017d002800a4d7a7a402849e01036469720177046175746f87a4d7a7a402849e0103097061726167726170680700a4d7a7a402929e01060400a4d7a7a402939e012654686520677565737420616e642065766572797468696e672c2074686174277320676f6f643f2800a4d7a7a402929e0102696401770c6f6a657063676973656c71782800a4d7a7a402929e0106696e64656e74017d002800a4d7a7a402929e01036469720177046175746f87a4d7a7a402929e0103097061726167726170680700a4d7a7a402bd9e01060400a4d7a7a402be9e011e4974277320676f6f642c20776520696e7669746520796f7520626f74682e2800a4d7a7a402bd9e0102696401770c67696e7a786a75696264696b2800a4d7a7a402bd9e0106696e64656e74017d002800a4d7a7a402bd9e01036469720177046175746f87a4d7a7a402bd9e0103097061726167726170680700a4d7a7a402e09e01060400a4d7a7a402e19e010b576861742069732069743f2800a4d7a7a402e09e0102696401770c65677074766e7a666d67796a2800a4d7a7a402e09e0106696e64656e74017d002800a4d7a7a402e09e01036469720177046175746f87a4d7a7a402e09e0103097061726167726170680700a4d7a7a402f09e01060400a4d7a7a402f19e019d01497420776f726b732c2067726561742e204f6b61792c206f6b61792c206f6b61792e202d55682e2e2e2054756b2c2074756b2c2074756b2e204f6b61792e204920776f756c64206c696b6520746f20636f6d65206261636b20746f20796f757220776f726b696e67206d6574686f64732e2062757420486f772061726520796f752063757272656e746c7920776f726b696e6720746f6765746865723f2800a4d7a7a402f09e0102696401770c7a71796676776c63787a64672800a4d7a7a402f09e0106696e64656e74017d002800a4d7a7a402f09e01036469720177046175746f87a4d7a7a402f09e0103097061726167726170680700a4d7a7a40292a001060400a4d7a7a40293a001bd02576520616c6c206665656c20612062697420617420686f6d652c2077652068617665206f7572207461736b732c207765206172652061737369676e65642c20776520776f726b206f6e207468656d2e20416e64207468656e20776520646f207468652072657669657773207468617420617265206e6f7420646f6e65206279206f746865722070656f706c652e204f7220736f6d6574696d657320776520646f2073657373696f6e7320746f67657468657220696e2057652068617665206120446973636f726420616e642077652067657420696e746f2069742e20576520776f726b2066726f6d203220746f20332c20616e64207468656e20686520636f6d6573207768656e2068652077616e747320746f20776f726b2e20536f6d6574696d657320776520646f2073657373696f6e73206c696b6520746861742e2800a4d7a7a40292a00102696401770c6c796a746b76657a69696a7a2800a4d7a7a40292a00106696e64656e74017d002800a4d7a7a40292a001036469720177046175746f87a4d7a7a40292a00103097061726167726170680700a4d7a7a402d4a201060400a4d7a7a402d5a201d80157652074616c6b65642061626f75742069742077697468204c7563617320746f20636f6d706c657465207768617420686520736169642e2057652074727920746f2070757420746f676574686572206d616e6461746f7279206d656574696e677320627574206d6f7374206f66207468652074696d652077652067697665206f757220776f726b696e6720686f75727320746861742077652061726520676f696e6720746f20646f20616e642077652074727920746f2073656520776974682070656f706c652077686f2063616e20636f6d65206574632e2800a4d7a7a402d4a20102696401770c646f6178716768646f6567762800a4d7a7a402d4a20106696e64656e74017d002800a4d7a7a402d4a201036469720177046175746f87a4d7a7a402d4a20103097061726167726170680700a4d7a7a402b1a401060400a4d7a7a402b2a401ad024974277320746f206d6f7469766174652e20427574207468656e207468657265206172652070656f706c652077686f2077696c6c206861766520746f20776f726b20746f676574686572206265636175736520746865792077696c6c20646f2073696d696c6172207461736b73206f7220696e207468652073616d65206669656c642e20416e6420696e207468697320636173652c2077652077696c6c2074727920746f2073656e64206d657373616765732c20656974686572206f6e20446973636f7264206f72206576656e206f6e20576861747341707020746f2074727920746f206f7267616e697a6520616e642066696e6420612074696d65206672616d6520696e2077686963682077652077696c6c2062652061626c6520746f20776f726b20746f6765746865722e2800a4d7a7a402b1a40102696401770c7678617073646c796c656a792800a4d7a7a402b1a40106696e64656e74017d002800a4d7a7a402b1a401036469720177046175746f87a4d7a7a402b1a40103097061726167726170680700a4d7a7a402e3a601060400a4d7a7a402e4a601b9025468616e6b20796f752e204f6b2c2077652073686f756c642061646420612073796e6368726f20706f696e742c20616e206162646f6d696e616c206f6e652c2049207468696e6b2e2041742074686520626567696e6e696e672e20486d3f205468617420697320746f207361792c204f6e63652061207765656b2c206576656e2069662069742773206f6e6c79203135206d696e757465732c203230206d696e757465732c2068616c6620616e20686f75722c207468652077686f6c652067726f7570206d6565747320746f207361793a2022546869732069732077686174207765206469642074686973207765656b206f6e20746865204f49422e22204e6f74206e65636573736172696c7920776f726b2073657373696f6e732c20627574206174206c656173742073796e6368726f20706f696e74732e2800a4d7a7a402e3a60102696401770c7672716b7279796b70757a692800a4d7a7a402e3a60106696e64656e74017d002800a4d7a7a402e3a601036469720177046175746f87a4d7a7a402e3a60103097061726167726170680700a4d7a7a402a1a901060400a4d7a7a402a2a9013f596561682c20776520616c72656164792068617665206f6e6520706572207765656b2e20576520616c7265616479206b6e6f77207768617420746f20646f2e2800a4d7a7a402a1a90102696401770c767778656d6c7271796375752800a4d7a7a402a1a90106696e64656e74017d002800a4d7a7a402a1a901036469720177046175746f87a4d7a7a402a1a90103097061726167726170680700a4d7a7a402e5a901060400a4d7a7a402e6a90123596561682c206e6f2c2062757420646f20796f7520686f6c64206f6e20746f2069743f2800a4d7a7a402e5a90102696401770c65697a65776e68686978727a2800a4d7a7a402e5a90106696e64656e74017d002800a4d7a7a402e5a901036469720177046175746f87a4d7a7a402e5a90103097061726167726170680700a4d7a7a4028daa01060400a4d7a7a4028eaa01675965732c20776520646f206974206f6e207765656b656e64732e2049276d20736f20636f6e76696e636564206279207468652e2e2e205468616e6b20796f752e2057652061726520616c6c20617661696c61626c652c20736f2077652063616e20646f2069742e2800a4d7a7a4028daa0102696401770c74756c7376706e747a62776d2800a4d7a7a4028daa0106696e64656e74017d002800a4d7a7a4028daa01036469720177046175746f87a4d7a7a4028daa0103097061726167726170680700a4d7a7a402f9aa01060400a4d7a7a402faaa0148536f20746865726520796f75206861766520612073796e6368726f20706f696e742e20596f75206861766520612073796e6368726f20706f696e742c20486562646f3f204279652e2800a4d7a7a402f9aa0102696401770c6b617664706f7867766f69732800a4d7a7a402f9aa0106696e64656e74017d002800a4d7a7a402f9aa01036469720177046175746f87a4d7a7a402f9aa0103097061726167726170680700a4d7a7a402c6ab01060400a4d7a7a402c7ab01b1035765277265206e6f7420616c6c20696e2069742e20576527726520666f757220696e2069742c20696e2067656e6572616c2e2054687265652c20666f757220696e2069742e2057652073686f756c6420616c6c20626520696e2069742c20746861742773207468652070726f626c656d2e20596561682c20796561682e204920756e6465727374616e642c206275742e2e2e2049742773206861726420746f206d616e61676520746f2072616c6c792065766572796f6e65206174207468652073616d652074696d652c206275742069742073686f756c642062652e2049276d206f6e207468652073616d652063616d7075732061732068696d2c20736f2049207365652068696d20717569746520726567756c61726c792e20486520646f65736e277420736861726520776974682065766572796f6e652e20492068617665206e6577732061626f75742077686174206865277320646f696e6720616e6420696620686520616476616e636573206f6e207468652049502e2049742773206e6f7420696465616c2c206275742049207468696e6b206865206861642070726f626c656d7320666f72207468652049502e2800a4d7a7a402c6ab0102696401770c63656b64747a626163737a732800a4d7a7a402c6ab0106696e64656e74017d002800a4d7a7a402c6ab01036469720177046175746f87a4d7a7a402c6ab0103097061726167726170680700a4d7a7a402fcae01060400a4d7a7a402fdae01456869732061706172746d656e7420616e642077656c6c2c2068652773207369636b20627574204920736565206974206174206c656173742074776963652061207765656b2e2800a4d7a7a402fcae0102696401770c796d6265646162777763666d2800a4d7a7a402fcae0106696e64656e74017d002800a4d7a7a402fcae01036469720177046175746f87a4d7a7a402fcae0103097061726167726170680700a4d7a7a402c6af01060400a4d7a7a402c7af0181014f6b61792e204c6574277320686f706520697420646f65736e277420636f756e742e20536f20666f7220746865206e6578742074696d652c204920776f756c64207265616c6c79206c696b6520796f7520746f206f66666572206d6520616374696f6e20706c616e732e20536f2c206f6e20746865206f626a656374697665732e2800a4d7a7a402c6af0102696401770c66696b6371737970736671622800a4d7a7a402c6af0106696e64656e74017d002800a4d7a7a402c6af01036469720177046175746f87a4d7a7a402c6af0103097061726167726170680700a4d7a7a402ccb001060400a4d7a7a402cdb0010f6f6b6179205468616e6b20796f752e2800a4d7a7a402ccb00102696401770c6f6a7766636b716b7573747a2800a4d7a7a402ccb00106696e64656e74017d002800a4d7a7a402ccb001036469720177046175746f87a4d7a7a402ccb00103097061726167726170680700a4d7a7a402e0b001060400a4d7a7a402e1b0012c416e64206d61796265206120706f696e74206f6e20796f757220776f726b206f7267616e697a6174696f6e3f2800a4d7a7a402e0b00102696401770c787077686e6e787074736b762800a4d7a7a402e0b00106696e64656e74017d002800a4d7a7a402e0b001036469720177046175746f87a4d7a7a402e0b00103097061726167726170680700a4d7a7a40291b101060400a4d7a7a40292b10127536f2c20746f206265206d6f726520707265636973652c20686f7720646f20776520776f726b3f2800a4d7a7a40291b10102696401770c666b726a6f7766736f6967672800a4d7a7a40291b10106696e64656e74017d002800a4d7a7a40291b101036469720177046175746f87a4d7a7a40291b10103097061726167726170680700a4d7a7a402bdb101060400a4d7a7a402beb101d503596561682c206c657427732073617920796f7520616e73776572206d65206265636175736520796f7520736179206966204920646f6e277420616e737765722c206865277320676f696e6720746f206c65617665206576657279207765656b656e642c20746861742773206e6963652c206275742e2e2e204920646f6e277420686176652074686520696d7072657373696f6e207468617420746865726520697320612e2e2e205768656e2077652061726520616c6c20617420612064697374616e63652c206974206973207265616c6c7920696d706f7274616e7420746f20686176652061206672616d65776f726b206f6620776f726b20746861742069732061206c6974746c65206d6f7265207269676964207468616e207768656e207765207365652065616368206f746865722e205768656e207765207365652065616368206f746865722c2077652063616e2072656d656d6265722065616368206f746865722e20486d6d2e204966204920646563696465206e6f7420746f2068616e67207570206f7220696620666f72206578616d706c65206120766964656f20636f6e66204920646f206e6f7420707574206d792063616d65726120492063616e20646f2061206c6f74206f66207468696e67732e2800a4d7a7a402bdb10102696401770c666b7a666f646c70667a63692800a4d7a7a402bdb10106696e64656e74017d002800a4d7a7a402bdb101036469720177046175746f87a4d7a7a402bdb10103097061726167726170680700a4d7a7a40297b501060400a4d7a7a40298b501d603496620492073686f757420617420796f7520796f752063616e207475726e20646f776e2074686520736f756e642c206574632e2049742773206e6f74207468652073616d65206173207768656e20796f752073656520796f757273656c6620696e207265616c206c6966652e2049662077652061726520696e206120726f6f6d20616e64204920737461727420746f2068697420796f7520686172642c20796f752077696c6c206665656c2076657279204974277320646966666572656e742066726f6d20696620796f75277265206f6e20612073637265656e20616e6420796f7527726520726f6c6c696e67206f6e2069742e2057656c6c2c2069742773207468652073616d6520666f7220796f752c2061637475616c6c792e2049742773207468652073616d65206265747765656e20796f752e20536f2c20696e2061206c657373657220657874656e742c2062757420796f75206665656c206c6573732070726573737572652c2074686572652077696c6c20616c7761797320626520736f6d657468696e67206d6f726520696d706f7274616e74206f72206d6f726520696e746572657374696e6720746f20646f207468616e207468652049502c207768696368206973207175697465206e6f726d616c2e2800a4d7a7a40297b50102696401770c746968676c757267796b616c2800a4d7a7a40297b50106696e64656e74017d002800a4d7a7a40297b501036469720177046175746f87a4d7a7a40297b50103097061726167726170680700a4d7a7a402f2b801060400a4d7a7a402f3b801fa01536f206974277320696d706f7274616e7420746f2072656d656d626572207665727920726567756c61726c79207468617420796f75206861766520746f20646f207468652049502c206b6e6f77696e672074686174206974206973206e6f7420746865206d6f737420696d706f7274616e74207468696e6720696e2061206c6966652e20546861742773206e6f7420776861742049276d20736179696e672e204f6620636f757273652c20627574206974206861732069747320696d706f7274616e636520616e6420736f206974277320696d706f7274616e7420746f2072656d656d62657220697420726567756c61726c792c206f6b61793f2800a4d7a7a402f2b80102696401770c77627a76687477686f7173702800a4d7a7a402f2b80106696e64656e74017d002800a4d7a7a402f2b801036469720177046175746f87a4d7a7a402f2b80103097061726167726170680700a4d7a7a402f1ba01060400a4d7a7a402f2ba01054f6b61792e2800a4d7a7a402f1ba0102696401770c777679626c647571667572622800a4d7a7a402f1ba0106696e64656e74017d002800a4d7a7a402f1ba01036469720177046175746f87a4d7a7a402f1ba0103097061726167726170680700a4d7a7a402fbba01060400a4d7a7a402fcba01125468616e6b20796f752e20566f696cc3a02e2800a4d7a7a402fbba0102696401770c626e616673756d78766d7a672800a4d7a7a402fbba0106696e64656e74017d002800a4d7a7a402fbba01036469720177046175746f87a4d7a7a402fbba0103097061726167726170680700a4d7a7a40291bb01060400a4d7a7a40292bb01054f6b61792e2800a4d7a7a40291bb0102696401770c716770666c6b66706875696f2800a4d7a7a40291bb0106696e64656e74017d002800a4d7a7a40291bb01036469720177046175746f87a4d7a7a40291bb0103097061726167726170680700a4d7a7a4029bbb01060400a4d7a7a4029cbb016a546f207468652062657374206f66207468656972206162696c6974792c206f6e636520616761696e2e2049742773206e6f7420746865206d6f737420696d706f7274616e74207468696e6720696e2061206c6966652c20627574206974277320696d706f7274616e742e2800a4d7a7a4029bbb0102696401770c66706a6262717266626163772800a4d7a7a4029bbb0106696e64656e74017d002800a4d7a7a4029bbb01036469720177046175746f87a4d7a7a4029bbb0103097061726167726170680700a4d7a7a4028abc01060400a4d7a7a4028bbc01fa015468616e6b20796f752e20536f2c204920776f756c64206c696b65206120706f696e74206f6e20796f757220776f726b207363686564756c652061206c6974746c65206d6f72652070726f76696465642c206f6b61793f205468616e6b20796f752e204e6f2c207369722e20497420776f726b732c207765277265206e6f742062616420686572652e20416e64207468656e2061626f766520616c6c2c204920696e736973742c20616e20616374696f6e20706c616e206f6e20746865206f626a656374697665732c206120636c65617220766973696f6e2e204d69636861656c3f20576865726520646f2077652077616e7420746f20676f3f2800a4d7a7a4028abc0102696401770c6f7a786d766b6c75677265632800a4d7a7a4028abc0106696e64656e74017d002800a4d7a7a4028abc01036469720177046175746f87a4d7a7a4028abc0103097061726167726170680700a4d7a7a40289be01060400a4d7a7a4028abe01054f6b61792e2800a4d7a7a40289be0102696401770c617a7877667577676366656b2800a4d7a7a40289be0106696e64656e74017d002800a4d7a7a40289be01036469720177046175746f87a4d7a7a40289be0103097061726167726170680700a4d7a7a40293be01060400a4d7a7a40294be0149486f7720646f2077652077616e7420746f20646f2069743f20416e64207768656e3f2057652077696c6c20646f2069742e204368656572732e204f6b61792e204f4b2e20596561682e2800a4d7a7a40293be0102696401770c767077746d716561617862622800a4d7a7a40293be0106696e64656e74017d002800a4d7a7a40293be01036469720177046175746f87a4d7a7a40293be0103097061726167726170680700a4d7a7a402e1be01060400a4d7a7a402e2be01054f6b61793f2800a4d7a7a402e1be0102696401770c66796b76737379706b6b68762800a4d7a7a402e1be0106696e64656e74017d002800a4d7a7a402e1be01036469720177046175746f87a4d7a7a402e1be0103097061726167726170680700a4d7a7a402ebbe01060400a4d7a7a402ecbe0105596561682e2800a4d7a7a402ebbe0102696401770c716e686961687873717367692800a4d7a7a402ebbe0106696e64656e74017d002800a4d7a7a402ebbe01036469720177046175746f87a4d7a7a402ebbe0103097061726167726170680700a4d7a7a402f5be01060400a4d7a7a402f6be014d446f20796f75206861766520616e79207175657374696f6e733f20436f6d706c61696e74732c20636f6d6d656e74732c2063726974696369736d732c20646f206e6f742068657369746174652e2800a4d7a7a402f5be0102696401770c677a6371626b6a6d6d6e64752800a4d7a7a402f5be0106696e64656e74017d002800a4d7a7a402f5be01036469720177046175746f87a4d7a7a402f5be0103097061726167726170680700a4d7a7a402c7bf01060400a4d7a7a402c8bf01d9014e6f2c20736f2e2e2e204920646f6e277420686176652074686174206d616e7920636f6d706c61696e74732e204f6e2074686520636f6e74726172792c2049206c696b6520746865206661637420746861742074686174207468696e67732061726520736169642073756464656e6c79206265636175736520697420616c6c6f777320757320746f206d6f766520666f7277617264206d6f7265207468616e207765207468696e6b2c207768696368206973206e6f7420676f696e67206469726563746c792e20492070726566657220746f2073657276652e2800a4d7a7a402c7bf0102696401770c67626975707477637a6c79672800a4d7a7a402c7bf0106696e64656e74017d002800a4d7a7a402c7bf01036469720177046175746f87a4d7a7a402c7bf0103097061726167726170680700a4d7a7a402a5c101060400a4d7a7a402a6c101f701536f207468652062696720696e74657265737420697320746861742049276d206a757374206865726520746f2068656c7020796f752e20536f2e2e2e2057652063616e2074656c6c2065616368206f74686572207468696e67732e204920776f6e277420777269746520796f7520646f776e2e2054686572652773206e6f206e6f74652e20536f2c2077652063616e20736179207468696e677320746f2065616368206f746865722e204f6e2074686520636f6e74726172792e204974277320746865206d61696e207468696e672e204f6b61793f204d7920676f616c206973207468617420796f7520646f20796f757220626573742e2800a4d7a7a402a5c10102696401770c6f627a64696e757864786b672800a4d7a7a402a5c10106696e64656e74017d002800a4d7a7a402a5c101036469720177046175746f87a4d7a7a402a5c10103097061726167726170680700a4d7a7a402a1c301060400a4d7a7a402a2c3010a5468616e6b20796f752e2800a4d7a7a402a1c30102696401770c64666364686b6b747068706c2800a4d7a7a402a1c30106696e64656e74017d002800a4d7a7a402a1c301036469720177046175746f87a4d7a7a402a1c30103097061726167726170680700a4d7a7a402b0c301060400a4d7a7a402b1c301115468616e6b20796f7520616e797761792e2800a4d7a7a402b0c30102696401770c676763677864786562706a672800a4d7a7a402b0c30106696e64656e74017d002800a4d7a7a402b0c301036469720177046175746f87a4d7a7a402b0c30103097061726167726170680700a4d7a7a402c6c301060400a4d7a7a402c7c301de014f6b61792c20746861742773206d79206f6e6c7920676f616c2e204f6b61792e20536f20796f7520646f2061206c6f6f70206f6e20616c6c20746865206f626a6563746976657320496620796f75206e6565642c20796f752063616e2073656e64206d652061206d6573736167652066726f6d2074696d6520746f2074696d6520746f2074656c6c206d653a202257652073617720746869732c207768617420646f20796f75207468696e6b2061626f75742069743f2220497420646f65736e2774206361757365206d6520616e792070726f626c656d2e204f6b61792e2800a4d7a7a402c6c30102696401770c787478766276726d657565642800a4d7a7a402c6c30106696e64656e74017d002800a4d7a7a402c6c301036469720177046175746f87a4d7a7a402c6c30103097061726167726170680700a4d7a7a402a9c501060400a4d7a7a402aac501104f6e2074686973206368616e6e656c3f2800a4d7a7a402a9c50102696401770c776c79756b716e6b746f646a2800a4d7a7a402a9c50106696e64656e74017d002800a4d7a7a402a9c501036469720177046175746f87a4d7a7a402a9c50103097061726167726170680700a4d7a7a402bec501060400a4d7a7a402bfc5018a015965732c206f6e2074686973206368616e6e656c2e205765206b656570207468697320726f6f6d2c20736f207765206861766520616c6c2074686520686973746f72792074686572652e2049662077652073746172742074616c6b696e672035206f7220362074696d65732c2077652063616e277420676574206f7574206f662069742e204f6b61793f2800a4d7a7a402bec50102696401770c6d65636b616b72697367647a2800a4d7a7a402bec50106696e64656e74017d002800a4d7a7a402bec501036469720177046175746f87a4d7a7a402bec50103097061726167726170680700a4d7a7a402cdc601060400a4d7a7a402cec601054f6b61792e2800a4d7a7a402cdc60102696401770c6a636478716c6d697a6b716e2800a4d7a7a402cdc60106696e64656e74017d002800a4d7a7a402cdc601036469720177046175746f87a4d7a7a402cdc60103097061726167726170680700a4d7a7a402d7c601060400a4d7a7a402d8c601054f6b61792e2800a4d7a7a402d7c60102696401770c6461796e766e6c70616c737a2800a4d7a7a402d7c60106696e64656e74017d002800a4d7a7a402d7c601036469720177046175746f87a4d7a7a402d7c60103097061726167726170680700a4d7a7a402e1c601060400a4d7a7a402e2c6010e4f6b61792c20706572666563742e2800a4d7a7a402e1c60102696401770c716b677569706e6a75706d6e2800a4d7a7a402e1c60106696e64656e74017d002800a4d7a7a402e1c601036469720177046175746f87a4d7a7a402e1c60103097061726167726170680700a4d7a7a402f4c601060400a4d7a7a402f5c60140496620796f7520646f6e2774206861766520616e79206f74686572207175657374696f6e732c2074686174277320676f6f6420666f72206d652e204f6b61792e2800a4d7a7a402f4c60102696401770c6861726e756e6e687462676f2800a4d7a7a402f4c60106696e64656e74017d002800a4d7a7a402f4c601036469720177046175746f87a4d7a7a402f4c60103097061726167726170680700a4d7a7a402b9c701060400a4d7a7a402bac701154920646f6e2774207468696e6b2077652063616e2e2800a4d7a7a402b9c70102696401770c6271706a6878616d6d76696e2800a4d7a7a402b9c70106696e64656e74017d002800a4d7a7a402b9c701036469720177046175746f87a4d7a7a402b9c70103097061726167726170680700a4d7a7a402d3c701060400a4d7a7a402d4c7010e5765276c6c20706c616e2069742e2800a4d7a7a402d3c70102696401770c7a7a6f627176766c686f62762800a4d7a7a402d3c70106696e64656e74017d002800a4d7a7a402d3c701036469720177046175746f87a4d7a7a402d3c70103097061726167726170680700a4d7a7a402e6c701060400a4d7a7a402e7c701494f6b61792c20697420776f726b732e205468616e6b20796f752e20416e64206f6620636f757273652c20646f6e27742068657369746174652e2072696768745468616e6b20796f752e2800a4d7a7a402e6c70102696401770c6b72786269726d676e76657a2800a4d7a7a402e6c70106696e64656e74017d002800a4d7a7a402e6c701036469720177046175746f87a4d7a7a402e6c701030a62756c6c65744c6973740700a4d7a7a402b4c80103086c6973744974656d0700a4d7a7a402b5c80103097061726167726170682800a4d7a7a402b6c80102696401770c707665636677677668666f762800a4d7a7a402b6c80106696e64656e74017d002800a4d7a7a402b6c801036469720177046175746f2800a4d7a7a402b5c801036469720177046175746f2800a4d7a7a402b4c801036469720177046175746f87a4d7a7a402b4c80103097061726167726170680700a4d7a7a402bcc801060400a4d7a7a402bdc8011f48617665206120676f6f64206461792e205468616e6b20796f752e20796f752800a4d7a7a402bcc80102696401770c7478647a6d697979767074682800a4d7a7a402bcc80106696e64656e74017d002800a4d7a7a402bcc801036469720177046175746f47a4d7a7a40200030768656164696e670700a4d7a7a402e0c801060400a4d7a7a402e1c8010753756d6d6172792800a4d7a7a402e0c80102696401770c6e736161766476717562666e2800a4d7a7a402e0c80106696e64656e74017d002800a4d7a7a402e0c801036469720177046175746f2800a4d7a7a402e0c801056c6576656c017d01c7a4d7a7a402e521a4d7a7a402ef21030768656164696e670700a4d7a7a402edc801060400a4d7a7a402eec8010a5472616e7363726970742800a4d7a7a402edc80102696401770c7672726f71747073736165732800a4d7a7a402edc80106696e64656e74017d002800a4d7a7a402edc801036469720177046175746f2800a4d7a7a402edc801056c6576656c017d0146a4d7a7a402efc80104626f6c64027b7d86a4d7a7a402f8c80104626f6c64046e756c6c02a993a781030201010a04a4d7a7a40202000ce52119	Summary\n\nAction Items\n\n Team to read the Student Guide objectives carefully and know them precisely before the next meeting\n\n Team to prepare a clear action plan on each TRAC objective (what, how, when) for the next meeting\n\n Team to prepare a more detailed work schedule/organization overview for the next meeting\n\n Team to organize Veille Techno: dedicate ~1 hour/week per person to research, test tracks via POC, and document results\n\n Team to produce structured documentation (architecture diagrams, CI/CD, test plans, etc.) targeting different audiences (users, admins, researchers)\n\n Team to measure, analyze, and iterate on performance — not just measure once\n\n Team to ensure all members attend the weekly synchro point, not just 3–4\n\n Team to identify and document the project's "hard point" for Mandatory Objective 1\n\n Team to prepare the meeting document (as done last time) for the next session\n\n Next meeting scheduled for Friday, October 16 (moved up from week of Oct 19 due to exam period)\n\nProject Overview\n\nProject name: Consoré — aimed at helping neurotypical people navigate digital life and achieve digital autonomy\n\nThree main components: Backend (API foundation), Dashboard (web interface for helpers), and Launcher (managed by Elias)\n\nTask management: Using Jira (chosen over GitHub Projects based on prior project management experience, approved by DPR)\n\nTeam locations: Sweden (Elias), Berlin (Enzo), Dublin/Ireland (Lucas, Alexandre), Canada/Quebec (one member), with home schools in Montpellier and Paris\n\nAttendance\n\nIbrahim was absent\n\nAlexandre was absent due to illness (uncertain if attending at all)\n\nAngel/Angèle arrived late\n\nProgress Update\n\nAll installation and minor corrections from the previous session have been completed\n\nCurrent goal: build a solid foundation for each component — somewhere between a POC and MVP — before moving to sprints\n\nCode is being documented incrementally via PRs\n\nTwo complementary secondary tracks defined: Track A (secure technical environment) and Track D (measure, test, and optimize performance)\n\nObjectives Review (Student Guide)\n\nThe supervisor noted the team was not sufficiently familiar with their formal TRAC objectives and stressed the need to know them precisely\n\nMandatory Objective 1: Organize and conduct a technological watch (Veille Techno) to identify and address the project's "hard point" — due end of October\n\nTeam has not yet clearly identified the hard point\n\nApproach: weekly research sessions → test tracks (POC) → document outcomes → determine if/how they integrate into the project\n\nDocuments must be produced and ready to justify the Veille Techno at the go/no-go\n\nMandatory Objective 2: Structured, documented, and reliable architecture — includes architecture diagrams, CI/CD, test plans\n\nDocumentation must be purpose-aware: distinguish between docs for users, admins, and researchers\n\nComplementary Objectives (A & D): Match the two secondary tracks already chosen; for Track D, measurement must lead to analysis, modification, and re-measurement — not just a one-time metric\n\nThe Student Guide also contains a list of required deliverables — team was reminded to consult it\n\nWorking Methods & Team Organization\n\nTeam works asynchronously with assigned tasks; code reviews are done by peers\n\nOccasional joint Discord work sessions are held; working hours are shared so others can join\n\nA weekly weekend synchro point already exists, but only 3–4 members typically attend\n\nSupervisor emphasized the importance of a more rigid work framework given the fully remote, multi-country setup, and the natural tendency to deprioritize the project\n\nSupervisor Feedback & Next Steps\n\nThe team jumped into tools (Jira) before explaining goals and direction — the supervisor asked for a clearer narrative: objective → approach → implementation\n\nFor the next meeting, the team should present: action plans per objective, a clearer work schedule, and demonstrate they know their objectives\n\nThe supervisor is available for async questions via the existing Discord channel\n\nTranscript\n\nHello? Can you hear me?\n\nI would have taken it off Discord. Oh wow, wait, why? Ah yes, you have to take it off Discord for that.\n\nHello. Hello.\n\nUp.\n\nKavaizhu! Very well, thank you. Yes, I may have been connected a little early, you may have wanted to discuss before I arrived. No, but tell me. There's no problem, I'll take it quite well.\n\nNo, you're about to do it.\n\nDon't worry. I saw that you sent me the document. In the conversation, the little preparation there? Thank you very much. It's very good, it allowed me to start filling things up.\n\nYes, that's it.\n\nLet's see.\n\nIt will save us a lot of time.\n\nThank you. Is the others here?\n\nThey haven't answered yet.\n\nOkay. That's perfect.\n\nFor now, there are only four. There's no Ibrahim, Angel... And Alexandra.\n\nSo Alexandre is busy. So, Alexandre, will you come back? No, Alexandre is not sure because he's sick. We don't know if he's coming or not. We're a bit waiting for it.\n\nI'll let you know, and if he comes, you'll let me know.\n\nOkay.\n\nAngel Angèle will arrive in a minute.\n\nIbrahim won't arrive.\n\nBrahim, I won't see you. Okay.\n\nI take this opportunity to make the adjustments. Oh, Boop, boop, boop. I think Ibrahim already liked it.\n\nYeah. It's very possible.\n\nMy camera is not detected on Ubuntu, so I think I'll have to restart my computer.\n\nGo ahead, we have time while I take care of that. So, indeed, Ibrahim, I don't have it. I have Elia, Sanjo, Angel, Lucas and Alexandre. OK. Well, Ibrahim, are we going to take it out of the meeting?\n\nThis is Shri Mataji: Sh Okay.\n\nSorry, I'm back with you. So where is Alexandre Paula? C'est tout. Okay. Great. So, we only miss Alexandre, since Angel is here. What I propose is that you start by reminding me in one sentence your project. the goal of the project, so that it allows us to be sure, to remember to remind me of your project and then talk about your progress and then we will work on the objectives. Is everyone okay?\n\nIt's perfect.\n\nWhere's the bucket?\n\nWait.\n\nOkay, great. Wait, just a second.\n\nYou just woke up, Angel. you It's 7:30, Pity. I went to bed at 3 or 4 o'clock.\n\nGo ahead, I'm listening. Hello? I look at my loss. Great. Yeah, not very strong, but... Wow.\n\nIs it better like that?\n\nYes, much better. Perfect.\n\n-Let's see it again soon.\n\nNo.\n\nIf you want, I can do it.\n\nRight. So, "Consoré" is a project aimed at helping neurotypical people We are going to have a sort of introduction to everything that is digital life. and all that is around us, rather digital autonomy. In a sentence...\n\nOkay.\n\nSo, tell me about your progress.\n\nto allow everyone to follow what everyone is doing. What else? People can addWe have the development of the backend, we have the development of the frontend, I don't know if Elias already started. We have the loader, I don't know. des jours. Do you have something to add?\n\nThank you.\n\nyou I will define it again, on the Jira side, we have finished all the installation and minor corrections that there were compared to the last time.\n\nYour SUI seems really well prepared. I don't know, people, is there anything to add? Put yourself in my shoes, I just want to go do something else.\n\nBut wait, we were talking about Jira, but maybe we should put it back in context.\n\nJira, what is it for? Why? Where is your project? I have a little trouble understanding.\n\nI will let Angèle talk about Jiraz, he is the one who is mainly busy.\n\nyou Is this. Is it possible to share the screen so you can see better?\n\nYes, of course.\n\nSo I'll do that for you. But if you want, before talking to me about Jira, It would be nice to talk a little bit about what you have done, your goals, where you are going, to structure a little bit. I mean, you remind me of a guy who builds a car and you're explaining to me that you grind rubber but at the end of the day I understand that you want to make a tire. Okay.\n\nSo, we started with the technical work, as you know, and the last time, two weeks ago, we didn't really have any secondary tracks yet. We defined our two secondary tracks, A and D, We found it consistent with the technical treatment. a more secure technical environment, so to protect and ensure that this environment So, it's the secondary track A. and the D secondary track which is measure, test and optimize the performance of our in the project.\n\nWe did these two tracks in secondary school because we found it quite common with a technical project. And for the other tracks, maybe we can work on it too. We'll see because it's often communication tracks that we've seen. It's something that we'll have to come up with later. But for now, we don't find it really important to do the follow-up every two weeks. We preferred to take these tracks. So to do this, we use a follow-up tool called Jira.\n\nWe didn't choose GitHub Project because Personally, I preferred to use Jira. It's a tool that I used a lot during my training in management of projects and others. That's why we started on Gira on this project and it was approved by our DPR. I'll show you what it looks like.\n\nSo the giraffe is for the... It's for the complementary objective number 1.\n\nYou It was about identifying the problem and it was about defining the architecture and having a sort of reliable architecture.\n\nAlso, that's it. But it's a kind of management tool, just for task development. It's quite basic. It's a bit like a GitHub project. Disqcc is a ticketing tool that allows you to organize yourself in a group. They can't worry about San Lucas.\n\nyou Okay.\n\nI'll quickly show you what it looks like.\n\nI imagine you know me, but that's it. No, Lizzie. What matters to me is to understand that it's not so much the tool itself, Hmm? What matters to me is What have you done? Where are you going? What are the working methods? What are your objectives? How do you work? I don't care if you use Jira, GitHub, whatever you want. But today, we didn't even talk about where you're going, you're throwing Jira at me. Thank you. You see what I mean?\n\nI think the first thing would be to say, well, here we are, we have such an objective to achieve. To achieve this objective, we have to do this, this, this and that. To do this, this and that, we are going to organize ourselves in such and such a way. And that's what we're going to put in place. Okay. So, you chose to help, that's good. It seems to me, given your project, it doesn't seem like a big deal.\n\nThen, actually, explain why. Well, very well. And then say, OK, now that we've chosen that, what are we going to put in place to meet the objectives? Thank you.\n\n. For now, we haven't decided to go by a sprint system because we plan to go by sprints, but the current one, the one that will probably come soon. But personally, and even for the whole, we chose to do that because we all arrived in our country, settled in, we started classes and all. We don't all necessarily have the same availability and other things. And so, what we did was to have a The main task is to create a solid foundation.\n\nA technical project, so at least having a MVP on each side, not necessarily a MVP, between the POC and the MVP, that is to say, something that works right to left everywhere a solid base is enough on each on for each part, so on the backend, the dashboard, the launcher, all these parts? Once this is done, during the coming month, we will set up sprints to work on it and then we will have a more regular follow-up on that.\n\nSo everyone must build a baseThat's it.\n\nBetween POC and MVP, MVP is pretty good, I think. But it's a bit between the two.\n\nNo, go ahead. So, that means you identified the parties? This is her. So what are these parties?\n\nSo, we have some parts. We have the basin, so here there will be uh all our... like API and others, so it's kind of our foundation. And this... We have the dashboard, which is more superficial, it's the web part where the helpers will connect. It's a slightly separate part, whether it's a track or a backing track. Then we have the launcher, Elias is taking care of it for now. um, For now, it's three big parties that connect to each other.\n\nAnd then there might be other things that will come over it, but that's not right now. So, that's it. We're going to say that's three big parts for now.\n\nBackend, Dashboard and Launcher. That's right. Oh That works. Okay. For now, on the mandatory objectives, you have advanced?\n\nuh We continue when everyone works on our side, we document our part of the code. We try to make some PR issues, but each time the part of the code is a little documented at least. And we're trying to document it as best we can for now.\n\nWait, we may not have understood. What are the mandatory objectives for you?\n\nthe So Um But I don't.\n\nmoi j'ai pas ce qui me dérange c'est là comment dira the approximate number of your answers I mean, the objectives of TRAC, mandatory, complementary and so on, it must be something precise. You don't have to tell me, I think the objectives are about that. I mean, tonight, the French team at the Stade de France, they know where they have to score the goal. yeah the wall foot rebound maybe we have to move the ball forward towards the oh shit You have a document Student Guide, okay?\n\nIn which there are objectives and you are told if you don't have the objective, you won't have your IP. You have to read them, know them. I tell you, what is your objective that we can... mandatory number one, you tell me, yeah, that's it. You should know it and you should have already started working on it. Okay? Huh? Knowing that the last time I made you notice that you hadn't read the guide and that you absolutely had to read it.\n\nOkay. Anyway. I'm a little annoying you there because if there is no one who moves you, you understand what I mean. We have to read together the objectives, that you are very clear with that and that you realize them. Do you have the document under your eyes? Uh, we. So it's Student Guide. So share it so that we can all agree on what we read.\n\nAllez-y.\n\nYou can do it. Go ahead.\n\nOh you I don't know how to do it.\n\nI'll be right back while you share. I'm coming. Go ahead, go ahead.\n\nI was thereYeah.\n\nIt's just that...\n\nYeah, for the screen.\n\nSo that's not it.\n\nThat's the second one.\n\nPerfect. What? That's the first objective. What?\n\nAnd so... Before the end of October, we had the problem characterization. Yeah, hard point.\n\nThat's it. In French, the number one objective is to organize your technological wave and exploit it to lift the hard point. project Okay. What?\n\nPut it here.\n\nKey.\n\nHello.\n\nDo you have an idea of what could be the hard part of your project today? Do you have an idea of how to make the Veil Techno?\n\nNo, not really.\n\nI'm sorry. It's complicated to define. There's a visualizer There's a visualizer Okay, we're all...\n\nSo, for the hard point, I can't help you. I could, but I don't want to. First, it's up to you to do it. Oh. Organizing this technology Thank you. Oh. To organize the technical day, what I advise youYeah. See? But You ask the questions. As usual, it's the old technology. How are we going to do it? How much time will we spend on it? What do we want to get out of it? How will she be able to help us in the project? Okay? Where does it integrate, etc.\n\nSo the idea is to say you are five, You will say, "OK, per week, everyone spends an hour of Veille Techno." During this hour, we do research. At the end of this hour, Identify the tracks. Yes, we remove the track, we test it, we do a POC. Yes, it works. No, it doesn't work. We don't remember the track, we don't remember it for this reason. After the POC, is it useful? Is it not? If it's useful, where will it go in the project?\n\nAll of this must be consigned, make documents Produce these documents because that's what we're asking you for. We're going to ask you to justify your technological advance. We're not going to ask you to do it, we're going to ask you to justify it.\n\nSo, these documents, for example, Did they get you to do it?\n\nAll the weeks? We just keep them on the side to prove it.\n\nAh no, I mean, yes, we will discuss it together, that's the goal of our meetings, okay? So you can give them to us in advance and so on, that's the goal of our rendezvous. But above all, we're going to have to produce them on the day of the go-no-go. Thank you.\n\nOK, so that's how you have to lead your your techno watch. You have to produce. Searching. Verify. Considere. Okay.\n\nOkay.\n\nLet's go.\n\nto And for the second objective, which was also supposed to be at the end of October, So, the search for setups.\n\nSo that in my opinion is not the second objective. You mix everything, you have to be super precise when you talk. That's not the second objective, we're still in the first one. What? Yes, if you tell me second objective, I think of second objective of TRAC. Your second goal is to Structured, documented, and reliable. Okay? So that's going to be everything that is architecture diagrams. documentation, CI/CD, test plan, etc.\n\nChip. Okay. When we do doc, we ask ourselves why we did it, what we do, how we did it.\n\nOkay.\n\nOkay? It's not the same as doing A tutorial? for a user, to do a man for an administrator or to do an article for a researcher. No doubt.\n\nLook at that guy.\n\nSo you think aboutYou think about the different types of docs. different types of people and how it matches.\n\nOkay, that works.\n\nIs that good for you? -Same thing, on the complementary objectives, the two there. Measure, test, optimize. Okay. Same thing, reflection on What do we set up? What do we want to measure? Once we have measured it, we analyze it.\n\nI got it.\n\nwe modify and we reanalyze. It's not just that we measured it, we're happy. 1.12 meters, great. No. We measure something, we deduce performance problems or not, we say, "Here, we're going to modify this thing" and we measure again.\n\nThere we go.\n\nOkay, is that good for you?\n\nSo So What the...\n\nWait what? Once again, you have to read the objectives and then tell yourself what to expect, what to expect as an output, what to do. For whom should I do it? Thank you. um In this document, you have the list of supplies to supply. Think about looking at it. Okay. Do you have any organization problems in the group? Given the distance, where are you currently?\n\nWe have one in Germany, in Berlin, two in Ireland. Dukas and Alexandre are not there, in Germany we have Enzo, in Sweden we have Elias and I am in Canada.\n\nYes, that's it: Sweden, Berlin, Dublin and Quebec. And you are Epitech Montpellier?\n\nMontpellier, in Paris.\n\nYeah. Yeah, Montpellier, Paris, that's it?\n\nAlexandre, he comes from Paris. That works.\n\nOK. Before I forget, do you have an idea for the next meeting? So, theoretically, it should be the week of October 19th.\n\nI'm so serious. Ms. Exxon. We're all starting to have our final moments. In any case, this is the case for Alexandre-Emer. We are beginning to have our time for the definitive. And on October 19, It's not a test period for me, so I'll have a lot of free time. Okay. I would like to do less this week, because it's a week of exams, of mid-sessions. Thank you. I have an exam every day on this week.\n\nSo if we do Friday 16th, It's been two weeks instead of three. Hmm.\n\nBut I haven't done anything this week. I don't mind. Friday, 16, I'm fine. I'm fine with that too.\n\nPokemon was it?\n\nYes, there is no problem.\n\nWhat?\n\nYes, I think so.\n\nWe plan the arrival. Do you prepare the thing like last time? Thank you. Okay. Are you preparing for the meeting?\n\nIt works.\n\nThe guest and everything, that's good?\n\nIt's good, we invite you both.\n\nWhat is it?\n\nIt works, great. Okay, okay, okay. -Uh... Tuk, tuk, tuk. Okay. I would like to come back to your working methods. but How are you currently working together?\n\nWe all feel a bit at home, we have our tasks, we are assigned, we work on them. And then we do the reviews that are not done by other people. Or sometimes we do sessions together in We have a Discord and we get into it. We work from 2 to 3, and then he comes when he wants to work. Sometimes we do sessions like that.\n\nWe talked about it with Lucas to complete what he said. We try to put together mandatory meetings but most of the time we give our working hours that we are going to do and we try to see with people who can come etc.\n\nIt's to motivate. But then there are people who will have to work together because they will do similar tasks or in the same field. And in this case, we will try to send messages, either on Discord or even on WhatsApp to try to organize and find a time frame in which we will be able to work together.\n\nThank you. Ok, we should add a synchro point, an abdominal one, I think. At the beginning. Hm? That is to say, Once a week, even if it's only 15 minutes, 20 minutes, half an hour, the whole group meets to say: "This is what we did this week on the OIB." Not necessarily work sessions, but at least synchro points.\n\nYeah, we already have one per week. We already know what to do.\n\nYeah, no, but do you hold on to it?\n\nYes, we do it on weekends. I'm so convinced by the... Thank you. We are all available, so we can do it.\n\nSo there you have a synchro point. You have a synchro point, Hebdo? Bye.\n\nWe're not all in it. We're four in it, in general. Three, four in it. We should all be in it, that's the problem. Yeah, yeah. I understand, but... It's hard to manage to rally everyone at the same time, but it should be. I'm on the same campus as him, so I see him quite regularly. He doesn't share with everyone. I have news about what he's doing and if he advances on the IP. It's not ideal, but I think he had problems for the IP.\n\nhis apartment and well, he's sick but I see it at least twice a week.\n\nOkay. Let's hope it doesn't count. So for the next time, I would really like you to offer me action plans. So, on the objectives.\n\nokay Thank you.\n\nAnd maybe a point on your work organization?\n\nSo, to be more precise, how do we work?\n\nYeah, let's say you answer me because you say if I don't answer, he's going to leave every weekend, that's nice, but... I don't have the impression that there is a... When we are all at a distance, it is really important to have a framework of work that is a little more rigid than when we see each other. When we see each other, we can remember each other. Hmm. If I decide not to hang up or if for example a video conf I do not put my camera I can do a lot of things.\n\nIf I shout at you you can turn down the sound, etc. It's not the same as when you see yourself in real life. If we are in a room and I start to hit you hard, you will feel very It's different from if you're on a screen and you're rolling on it. Well, it's the same for you, actually. It's the same between you. So, in a lesser extent, but you feel less pressure, there will always be something more important or more interesting to do than the IP, which is quite normal.\n\nSo it's important to remember very regularly that you have to do the IP, knowing that it is not the most important thing in a life. That's not what I'm saying. Of course, but it has its importance and so it's important to remember it regularly, okay?\n\nOkay.\n\nThank you. Voilà.\n\nOkay.\n\nTo the best of their ability, once again. It's not the most important thing in a life, but it's important.\n\nThank you. So, I would like a point on your work schedule a little more provided, okay? Thank you. No, sir. It works, we're not bad here. And then above all, I insist, an action plan on the objectives, a clear vision. Michael? Where do we want to go?\n\nOkay.\n\nHow do we want to do it? And when? We will do it. Cheers. Okay. OK. Yeah.\n\nOkay?\n\nYeah.\n\nDo you have any questions? Complaints, comments, criticisms, do not hesitate.\n\nNo, so... I don't have that many complaints. On the contrary, I like the fact that that things are said suddenly because it allows us to move forward more than we think, which is not going directly. I prefer to serve.\n\nSo the big interest is that I'm just here to help you. So... We can tell each other things. I won't write you down. There's no note. So, we can say things to each other. On the contrary. It's the main thing. Okay? My goal is that you do your best.\n\nThank you.\n\nThank you anyway.\n\nOkay, that's my only goal. Okay. So you do a loop on all the objectives If you need, you can send me a message from time to time to tell me: "We saw this, what do you think about it?" It doesn't cause me any problem. Okay.\n\nOn this channel?\n\nYes, on this channel. We keep this room, so we have all the history there. If we start talking 5 or 6 times, we can't get out of it. Okay?\n\nOkay.\n\nOkay.\n\nOkay, perfect.\n\nIf you don't have any other questions, that's good for me. Okay.\n\nI don't think we can.\n\nWe'll plan it.\n\nOkay, it works. Thank you. And of course, don't hesitate. rightThank you.\n\nHave a good day. Thank you. you\n\n	'-4':117B,514B '1':62B,131B,337B,1607B '1.12':3318B '15':3922B '16':152B,3627B '16th':3604B '19':159B,3550B '19th':3510B '2':4A,400B,3768B '20':3924B '2026':5A '3':116B,513B,1018B,3770B '30':1011B '4':1020B '5':4708B '6':4710B '7':1010B 'abdomin':3902B 'abil':4437B 'abl':2820B,3888B 'aboutyou':3239B 'absent':236B,239B 'absolut':2501B 'achiev':178B,1799B,1801B 'action':7B,30B,577B,4146B,4489B 'actual':1867B,4340B 'add':1159B,1204B,3897B 'address':349B 'addw':1122B 'adjust':831B 'admin':90B,423B 'administr':3221B 'advanc':2254B,2954B,3025B,4092B 'advis':2777B 'ago':1380B 'agre':2571B 'ah':620B,2999B 'ahead':865B,1024B,2096B,2584B,2607B,2609B 'ai':2327B 'aim':169B,1070B 'alexandr':222B,237B,756B,760B,766B,890B,919B,930B,3438B,3481B,3535B 'alexandra':754B 'alexandre-em':3534B 'allez':2577B 'allez-i':2576B 'allow':705B,958B,1110B,1663B,4559B 'alreadi':435B,509B,839B,1142B,2475B,3956B,3962B 'also':460B,1629B,3091B 'alway':4359B 'analysi':444B 'analyz':95B,3297B 'angel':752B,806B,807B,887B,932B,1006B,1253B 'angel/angele':248B 'annoy':2512B 'answer':736B,2343B,4177B,4186B 'anyth':1202B,3619B 'anyway':2507B,4636B 'apart':4110B 'api':185B,2130B 'approach':368B,567B 'approv':211B,1582B 'approxim':2339B 'architectur':80B,405B,407B,1621B,1628B,3174B 'around':1094B 'arriv':249B,656B,809B,816B,1942B,3653B 'articl':3226B 'ask':561B,2782B,2941B,2948B,2960B,2969B,3188B 'assign':481B,3731B 'async':596B 'asynchron':479B 'attend':109B,233B,245B,517B 'audienc':88B 'autonomi':180B,1098B 'avail':594B,1961B,3993B 'awar':417B 'back':764B,913B,1231B,2173B,2599B,3706B 'backend':184B,1128B,2030B,2235B 'bad':4480B 'ball':2405B 'base':205B,2018B 'basethat':2073B 'basic':1648B 'basin':2120B 'bed':1016B 'begin':3539B,3908B 'berlin':218B,3432B,3462B 'best':2300B,4434B,4631B 'better':1043B,1048B,1279B 'big':1864B,2194B,2231B,4579B 'bit':787B,1308B,1324B,1652B,2090B,3722B 'boop':833B,834B,835B 'brahim':817B 'bucket':994B 'build':267B,1334B,2071B 'busi':758B,1264B 'bye':4012B 'c':921B,2333B 'call':1536B 'camera':848B,4267B 'campus':4066B 'canada':3456B 'canada/quebec':223B 'car':1336B 'care':16B,872B,1746B,2183B 'case':3528B,3532B,3860B 'caus':4681B 'ce':2329B 'channel':602B,4688B,4692B 'character':2650B 'cheer':4518B 'chip':3181B 'choos':1541B 'chose':1845B,1935B 'chosen':201B,436B,1881B 'ci/cd':82B,409B,3177B 'class':1950B 'clear':29B,363B,2540B,4495B 'clearer':564B,582B 'clock':1022B 'code':284B,483B,2270B,2285B 'come':763B,781B,799B,1496B,1925B,2044B,2210B,2605B,3483B,3705B,3774B,3829B 'comment':2336B,4530B 'common':1458B 'communic':1482B 'compar':1184B 'complaint':4529B,4543B 'complementari':292B,426B,1604B,2351B,3267B 'complet':264B,3793B 'complic':2721B 'compon':183B,273B 'compt':1A 'comput':863B 'conduct':340B 'conf':4261B 'connect':644B,2159B,2197B 'consider':3077B 'consign':2929B 'consist':1402B 'consor':168B,1066B 'consult':471B 'contain':461B 'context':1233B 'continu':2257B 'contrari':4546B,4617B 'convers':691B 'convinc':3985B 'correct':257B,1180B 'could':2692B,2747B 'count':4132B 'countri':534B,1945B 'cours':1282B,4411B,4755B 'creat':1979B 'critic':4531B 'current':265B,1918B,3425B,3715B 'd':303B,429B,439B,1398B,1429B 'dashboard':187B,2032B,2145B,2236B 'day':1353B,2774B,3049B,3595B,4764B 'de':2383B 'deal':1865B 'decid':1902B,4250B 'dedic':61B 'deduc':3326B 'defin':295B,1165B,1391B,1619B,2723B 'definit':3546B 'deliver':466B 'demonstr':586B 'depriorit':541B 'derang':2332B 'des':1152B 'detail':48B 'detect':851B 'determin':377B 'develop':1125B,1132B,1644B 'diagram':81B,408B,3175B 'didn':1382B,1539B,1758B 'differ':87B,3243B,3247B,4319B 'digit':175B,179B,1088B,1097B 'dira':2337B 'direct':558B,4572B 'discord':491B,601B,615B,628B,3759B,3869B 'discuss':653B,3006B 'disqcc':1657B 'distanc':3421B,4214B 'distinguish':418B 'doc':420B,3186B,3246B 'document':73B,79B,122B,137B,287B,375B,384B,402B,412B,688B,2265B,2289B,2297B,2414B,2552B,2931B,2934B,2976B,3161B,3176B,3395B 'doesn':1859B,2887B,4076B,4130B,4679B 'done':139B,486B,1313B,1725B,2041B,3618B,3745B 'doubt':3231B 'dpr':213B,1585B 'dublin':3463B 'dublin/ireland':220B 'due':160B,240B,355B 'duka':3436B 'earli':647B 'either':3867B 'elia':196B,217B,885B,1141B,2180B,3451B 'els':1119B,1217B 'emer':3536B 'emphas':519B 'end':356B,1350B,2643B,2863B,3097B 'enough':2020B 'ensur':106B,1416B 'environ':300B,1411B,1419B 'enzo':219B,3446B 'epitech':3469B 'est':922B,2334B 'etc':85B,2832B,3180B,3830B,4286B 'even':1760B,1930B,3871B,3917B 'everi':1516B,3594B,4192B 'everyon':986B,1111B,1115B,2069B,2259B,2848B,4052B,4080B 'everyth':1085B,3117B,3171B,3676B 'everywher':2015B 'exam':162B,3583B,3593B 'exampl':2978B,4258B 'exist':510B,600B 'expect':3374B,3377B 'experi':210B 'explain':555B,1340B,1868B 'exploit':2670B 'extent':4351B 'exxon':3516B 'eye':2555B 'fact':4550B 'familiar':321B 'feedback':545B 'feel':3720B,4315B,4354B 'field':3856B 'fill':709B 'final':3524B 'find':1506B,3879B 'fine':3630B,3633B 'finish':1174B 'first':1783B,2636B,2754B,3138B 'five':2841B 'follow':1113B,1514B,1533B,2064B 'follow-up':1513B,1532B,2063B 'foot':2397B 'forget':3491B 'formal':324B 'forward':2406B,4563B 'found':1400B,1455B 'foundat':186B,270B,1982B,2139B 'four':747B,4021B,4027B 'frame':3882B 'framework':527B,4222B 'franc':2384B 'free':3566B 'french':2378B,2658B 'friday':150B,3603B,3626B 'frontend':1135B 'fulli':530B 'general':4025B 'germani':3430B,3443B 'get':2812B,2981B,3762B,4715B 'gira':1575B 'giraff':1596B 'github':203B,1542B,1655B,1751B 'give':3020B,3810B 'given':528B,1855B,3419B 'go':864B,896B,1023B,1077B,1214B,1319B,1729B,1766B,1821B,1837B,1886B,1904B,1913B,2095B,2225B,2583B,2606B,2608B,2795B,2920B,2946B,2958B,2967B,3041B,3053B,3055B,3082B,3168B,3336B,3347B,3817B,4189B,4503B,4571B 'go-no-go':3052B 'go/no-go':397B 'goal':266B,556B,951B,1315B,2393B,3012B,3032B,3157B,4625B,4642B 'good':703B,1850B,2083B,3260B,3351B,3679B,3682B,4734B,4763B 'got':3300B 'great':925B,997B,1034B,3320B,3692B 'grind':1345B 'group':1670B,3418B,3931B 'guest':3674B 'guid':14B,312B,459B,2416B,2497B,2562B 'guy':1332B,3235B 'hadn':2493B 'half':3926B 'hang':4253B 'happi':3317B 'hard':126B,353B,366B,2652B,2675B,2695B,2739B,4047B,4312B 'haven':734B,1900B,3616B 'hear':607B 'hebdo':4011B 'held':495B 'hello':604B,631B,632B,1028B,2684B 'help':171B,1072B,1847B,2744B,2822B,4588B 'helper':191B,2157B 'hesit':4534B,4758B 'histori':4702B 'hit':4310B 'hm':3909B 'hmm':1716B,3613B,4247B 'hold':3972B 'home':227B,3724B 'hope':4128B 'hour':497B,2851B,2857B,2866B,3813B,3928B 'hour/week':63B 'huh':2481B 'ibrahim':234B,751B,813B,838B,877B,893B 'idea':2689B,2705B,2835B,3496B 'ideal':4099B 'identifi':120B,347B,364B,1612B,2101B,2867B 'if/how':378B 'ill':242B 'imagin':1690B 'implement':568B 'import':521B,1509B,4218B,4363B,4379B,4398B,4416B,4421B,4445B,4453B 'impress':4203B 'includ':406B 'increment':288B 'inde':876B 'insist':4487B 'instal':254B,1177B 'instead':3610B 'integr':380B,2831B 'interest':4366B,4580B 'interfac':189B 'introduct':1083B 'invit':3684B 'ip':2439B,4095B,4108B,4371B,4390B 'ireland':3435B 'issu':2277B 'item':8B 'iter':97B 'j':2326B 'jira':200B,553B,1170B,1224B,1234B,1299B,1537B,1550B,1750B,1770B 'jiraz':1256B 'join':503B 'joint':490B 'jour':1153B 'jump':550B 'justifi':391B,2951B,2972B 'kavaizhu':634B 'keep':2991B,4694B 'key':2683B 'kind':1637B,2136B 'know':18B,332B,588B,777B,795B,804B,1139B,1151B,1198B,1373B,1692B,2386B,2445B,2469B,2482B,2590B,3963B,4391B 'la':2335B 'last':140B,1187B,1376B,2485B,3660B 'late':250B 'later':1499B 'launcher':193B,2034B,2179B,2238B 'lead':442B,3066B 'least':1988B,2291B,3951B,4121B 'leav':4191B 'left':2014B 'less':3574B,4355B 'lesser':4350B 'let':716B,793B,802B,1050B,1252B,3080B,4126B,4173B 'life':176B,1089B,4299B,4402B,4449B 'lift':2673B 'like':840B,1044B,1593B,1653B,1688B,1862B,2129B,3571B,3659B,3703B,3784B,4141B,4459B,4548B 'list':463B,3399B 'listen':1027B 'littl':646B,693B,1247B,1307B,1323B,2288B,2511B,4228B,4467B 'lizzi':1699B 'll':666B,792B,801B,858B,1285B,1476B,1493B,1587B,1681B,2596B,3561B,4745B 'loader':1147B 'locat':215B 'look':1030B,1592B,1687B,3232B,3406B 'loop':4648B 'loss':1033B 'lot':724B,1559B,3564B,4272B 'luca':221B,888B,1677B,3791B 'm':912B,1026B,2509B,2604B,2717B,3512B,3629B,3632B,3983B,4062B,4408B,4584B 'made':2488B 'main':182B,1263B,1975B,4621B 'make':829B,1360B,2274B,2709B,2930B 'man':3218B 'manag':194B,198B,209B,1564B,1639B,4049B 'mandatori':129B,335B,398B,2250B,2314B,2350B,2457B,3802B 'mani':4542B 'mataji':907B 'match':430B,3254B 'matter':1701B,1718B 'may':641B,649B,2307B 'mayb':1226B,1468B,2399B,4156B 'mean':1326B,1779B,2099B,2345B,2375B,2528B,3002B 'measur':94B,102B,304B,440B,449B,1434B,3272B,3290B,3294B,3313B,3323B,3343B 'meet':24B,42B,55B,136B,147B,572B,903B,1892B,3015B,3500B,3670B,3803B,3932B 'member':108B,225B,515B 'messag':3866B,4661B 'meter':3319B 'method':474B,1734B,3710B 'metric':456B 'michael':4497B 'mid':3586B 'mid-sess':3585B 'might':2204B 'mind':3625B 'minor':256B,1179B 'minut':812B,3923B,3925B 'miss':929B 'mix':3116B 'modif':445B 'modifi':3303B,3338B 'moi':2325B 'moment':3525B 'month':2045B 'montpelli':230B,3470B,3471B,3476B 'motiv':3834B 'move':153B,281B,2403B,2522B,4562B 'ms':3515B 'much':699B,1047B,1712B,2800B 'multi':533B 'multi-countri':532B 'must':385B,413B,441B,2070B,2356B,2927B 'mvp':279B,1991B,1998B,2004B,2079B,2080B 'name':167B 'narrat':565B 'natur':538B 'navig':174B 'necessarili':1957B,1996B,3946B 'need':330B,4655B 'neurotyp':172B,1073B 'news':4083B 'next':23B,41B,54B,144B,146B,546B,571B,3499B,4136B 'nice':1303B,4196B 'normal':4375B 'note':315B,4606B 'notic':2490B 'number':1606B,2340B,2458B,2660B 'o':1021B 'object':15B,35B,130B,309B,326B,336B,399B,427B,566B,580B,590B,984B,1605B,1738B,1797B,1803B,1894B,2251B,2315B,2347B,2370B,2422B,2433B,2453B,2535B,2637B,2662B,3088B,3114B,3132B,3147B,3152B,3268B,3367B,4151B,4493B,4652B 'occasion':489B 'oct':158B 'octob':151B,358B,2645B,3099B,3509B,3549B 'octobr':3A 'offer':4144B 'often':1481B 'oh':616B,832B,2242B,2409B,2585B,2763B,2769B 'oib':3944B 'ok':891B,1876B,2845B,3058B,3488B,3894B,4520B 'okay':738B,805B,823B,909B,924B,987B,996B,1102B,1363B,1679B,1842B,2245B,2417B,2480B,2506B,2678B,2732B,2827B,3016B,3078B,3079B,3164B,3182B,3201B,3202B,3255B,3275B,3348B,3409B,3568B,3664B,3693B,3694B,3695B,3700B,4125B,4152B,4426B,4427B,4431B,4470B,4504B,4519B,4522B,4623B,4637B,4643B,4685B,4719B,4720B,4721B,4722B,4737B,4748B 'old':2790B 'one':224B,454B,946B,1260B,1919B,1921B,2459B,2520B,2630B,2661B,3139B,3428B,3903B,3958B 'one-tim':453B 'opinion':3109B 'opportun':827B 'optim':307B,1437B,3274B 'organ':58B,338B,476B,1666B,1823B,2665B,2764B,2771B,3414B,3877B,4162B 'other':501B,731B,1568B,2132B 'outcom':376B 'output':3380B 'overview':51B,165B 'pari':232B,3473B,3477B,3485B 'part':2026B,2037B,2116B,2154B,2165B,2232B,2267B,2282B,2696B 'parti':2103B,2111B,2195B 'pas':2328B 'paula':920B 'peer':488B 'peopl':173B,1074B,1120B,1199B,3250B,3748B,3826B,3839B 'per':64B,579B,2846B,3959B 'perfect':741B,990B,1049B,2631B,4723B 'perform':99B,308B,1439B,3327B 'period':163B,3556B 'person':65B,1545B,1928B 'piti':1012B 'place':1841B,1890B 'plan':31B,84B,411B,578B,1911B,3179B,3651B,4147B,4490B,4746B 'poc':71B,277B,374B,2001B,2077B,2881B,2906B 'point':113B,127B,354B,367B,508B,2653B,2676B,2740B,3900B,3953B,4005B,4010B,4158B,4461B 'pokemon':3637B 'possibl':846B,1270B 'pr':2276B 'precis':20B,334B,2359B,3123B,4167B 'prefer':1520B,1547B,4574B 'prepar':27B,45B,134B,694B,1194B,3656B,3667B 'present':576B 'pressur':4356B 'pretti':2082B 'previous':260B 'prior':207B 'probabl':1924B 'problem':664B,1614B,2649B,3328B,3415B,3644B,4039B,4105B,4684B 'produc':77B,387B,2932B,3045B,3074B 'progress':251B,976B,1108B 'project':124B,164B,166B,204B,208B,351B,383B,543B,949B,954B,970B,1069B,1243B,1444B,1462B,1543B,1566B,1578B,1656B,1857B,1985B,2677B,2699B,2826B,2923B 'propos':937B 'protect':1414B 'prove':2997B 'provid':4469B 'prs':290B 'purpos':416B 'purpose-awar':415B 'put':1205B,1229B,1839B,1888B,2680B,3800B,4265B 'quebec':3465B 'question':597B,2784B,4528B,4731B 'qui':2330B 'quick':1682B 'quit':669B,1457B,1647B,4073B,4374B 'ralli':4051B 'rather':1096B 're':448B,673B,785B,1339B,1765B,1768B,1836B,2224B,2294B,2734B,2940B,2945B,2956B,2966B,3040B,3134B,3316B,3335B,3518B,4014B,4020B,4323B,4329B,4478B 're-measur':447B 'read':11B,2443B,2495B,2504B,2532B,2575B,3365B 'readi':389B 'real':4298B 'realiz':2546B 'realli':1192B,1384B,1508B,2715B,4140B,4217B 'reanalyz':3306B 'reason':2903B 'rebound':2398B 'reflect':3278B 'regular':2062B,4074B,4383B,4425B 'reliabl':404B,1627B,3163B 'rememb':964B,2893B,2899B,4244B,4381B,4423B 'remind':469B,943B,966B,1328B 'remot':531B 'remov':2872B 'rendezv':3035B 'rendu':2A 'requir':465B 'research':67B,91B,370B,425B,2860B,3229B 'restart':861B 'result':74B 'review':310B,484B,3741B 'right':1064B,2012B,2217B,2241B,2598B 'rightthank':4759B 'rigid':525B,4230B 'roll':4330B 'room':4305B,4696B 'rubber':1346B 'said':3796B,4555B 'san':1676B 'sanjo':886B 'save':721B 'saw':682B,4670B 'say':1788B,1875B,2008B,2227B,2838B,2844B,3332B,3913B,3934B,4175B,4181B,4409B,4610B 'schedul':148B,584B,4465B 'schedule/organization':50B 'school':228B,1452B 'score':2391B 'screen':1274B,2620B,4326B 'search':3075B,3102B 'second':1001B,2629B,3087B,3113B,3131B,3146B,3151B,3156B 'secondari':293B,433B,1387B,1394B,1424B,1430B,1451B 'secur':298B,1409B 'see':718B,821B,1052B,1278B,1477B,1776B,2779B,3824B,4071B,4118B,4234B,4239B,4295B 'seem':1191B,1852B,1861B 'seen':1487B 'send':3865B,4658B 'sent':685B 'sentenc':947B,1101B 'separ':2164B 'serious':3514B 'serv':4576B 'session':145B,261B,371B,493B,3587B,3753B,3783B,3948B 'set':2048B,3283B 'settl':1946B 'setup':535B,3104B 'sh':908B 'share':499B,1272B,2564B,2602B,4078B 'shit':2410B 'shoe':1209B 'shout':4277B 'show':1588B,1683B 'shri':906B 'sick':773B,4115B 'side':1171B,1994B,2263B,2995B 'similar':3850B 'sinc':931B 'sir':4474B 'slight':2163B 'solid':269B,1981B,2017B 'someth':1157B,1216B,1490B,2009B,2358B,3324B,4361B 'sometim':3750B,3780B 'somewher':274B 'soon':1055B,1926B 'sorri':910B,2718B 'sort':1081B,1625B 'sound':4285B 'spend':2804B,2849B 'sprint':283B,1907B,1915B,2050B 'stade':2382B 'start':708B,941B,1143B,1366B,1573B,1949B,2476B,3520B,4308B,4706B 'step':547B 'still':3135B 'stress':328B 'strong':1038B 'structur':78B,401B,1321B,3160B 'student':13B,311B,458B,2415B,2561B 'sudden':4556B 'suffici':320B 'sui':1190B 'summari':6B 'super':3122B 'superfici':2149B 'supervisor':314B,518B,544B,560B,592B 'suppli':3401B,3403B 'suppos':3092B 'sure':769B,962B 'sweden':216B,3448B,3461B 'synchro':112B,507B,3899B,3952B,4004B,4009B 'system':1908B 'take':625B,667B,825B,871B,898B,1522B,2182B 'taken':612B 'talk':973B,1222B,1254B,1295B,1305B,1761B,3126B,3787B,4707B 'target':86B 'task':197B,482B,1643B,1976B,3728B,3851B 'team':9B,25B,43B,56B,75B,92B,104B,118B,132B,214B,317B,359B,467B,475B,477B,549B,574B,2379B 'technic':299B,1369B,1405B,1410B,1461B,1984B,2773B 'techno':60B,345B,394B,2712B,2854B,3069B 'technolog':342B,2667B,2766B,2791B,2953B 'tell':659B,1104B,2365B,2448B,2461B,3144B,3370B,4593B,4667B 'tendenc':539B 'test':68B,83B,305B,372B,410B,1435B,2876B,3178B,3273B,3555B 'thank':637B,696B,727B,1160B,1773B,1895B,2767B,3056B,3390B,3588B,3662B,3892B,3988B,4153B,4428B,4454B,4471B,4632B,4634B,4751B,4765B 'theoret':3502B 'thereyeah':2612B 'thing':710B,1784B,1964B,2207B,3264B,3277B,3340B,3658B,4274B,4399B,4446B,4553B,4596B,4611B,4622B 'think':837B,856B,1781B,2085B,2368B,3149B,3238B,3240B,3404B,3648B,3905B,4102B,4567B,4675B,4741B 'three':181B,2193B,2230B,3612B,4026B 'throw':1769B 'ticket':1660B 'time':141B,455B,726B,868B,1188B,1377B,2280B,2486B,2801B,3543B,3567B,3661B,3808B,3881B,4056B,4137B,4663B,4665B,4711B 'tire':1362B 'today':1756B,2700B 'togeth':2533B,3008B,3717B,3754B,3801B,3845B,3891B 'told':2426B 'tonight':2376B 'tool':552B,1535B,1554B,1640B,1661B,1714B 'tout':923B 'toward':2407B 'trac':34B,325B,2349B,3154B 'track':69B,294B,296B,302B,373B,434B,438B,1388B,1395B,1425B,1431B,1449B,1467B,1483B,1524B,2170B,2174B,2869B,2874B,2895B 'train':1562B 'transcript':603B 'treatment':1406B 'tri':2272B,2295B,3798B,3822B,3863B,3875B 'troubl':1248B 'tuk':3697B,3698B,3699B 'turn':4282B 'tutori':3211B 'twice':4122B 'two':291B,432B,1378B,1393B,1448B,1517B,2093B,3270B,3433B,3608B 'type':3244B,3248B 'typic':516B 'ubuntu':853B 'uh':2126B,2255B,2556B,3696B 'um':2188B,2320B,3392B 'uncertain':243B 'understand':1249B,1355B,1706B,2525B,4043B 'understood':2310B 'updat':252B 'us':722B,959B,1095B,2823B,3023B,4560B 'use':199B,1530B,1549B,1557B,1749B,2909B,2916B 'user':89B,422B,3214B 'usual':2786B 've':1486B,1880B 'veil':2711B 'veill':59B,344B,393B,2853B 'verifi':3076B 'via':70B,289B,598B 'video':4260B 'vision':4496B 'visual':2727B,2731B 'voila':4430B 'wait':618B,788B,995B,998B,1219B,2305B,3358B 'wall':2396B 'want':651B,1059B,1212B,1293B,1358B,1754B,2752B,2810B,3288B,3777B,4501B,4508B 'watch':343B,3070B 'wave':2668B 'way':1830B 'web':188B,2153B 'week':111B,156B,369B,505B,1379B,1518B,2847B,2988B,3507B,3576B,3581B,3598B,3609B,3621B,3916B,3941B,3960B,4124B 'weekend':506B,3981B,4193B 'well':636B,670B,892B,1193B,1789B,1870B,1872B,4112B,4333B 'went':1014B 'whatev':1752B 'whatsapp':3873B 'whether':2166B 'whole':1933B,3930B 'woke':1004B 'won':814B,819B,2435B,4598B 'work':49B,473B,478B,492B,496B,526B,583B,981B,1370B,1471B,1733B,1742B,2011B,2052B,2244B,2260B,2477B,2884B,2889B,3257B,3487B,3672B,3691B,3709B,3716B,3733B,3766B,3779B,3812B,3844B,3890B,3947B,4161B,4171B,4224B,4464B,4476B,4750B 'worri':680B,1674B 'would':610B,1301B,1785B,3570B,3702B,4139B,4458B 'wow':617B,1040B 'write':4600B 'y':2578B 'yeah':842B,1035B,2394B,2463B,2617B,2651B,3474B,3475B,3954B,3967B,4040B,4041B,4172B,4521B,4523B 'yes':621B,639B,712B,1046B,1280B,2870B,2882B,3003B,3141B,3457B,3640B,3646B,3976B,4689B 'yet':362B,737B,1389B 'youyeah':2778B	\N	01a12cf1-0bd0-70e9-87f3-436c4e3a4023	01a12cf1-0bd0-70e9-87f3-436c4e3a4023	\N	01a12d28-97bc-7e08-89d5-3b6f4a7a6d57	01a12cf1-0bd3-7a42-96f8-8cedaf38cf22	f	2026-10-11 22:51:10.011997+00	2026-10-11 22:54:32.768+00	\N	{01a12cf1-0bd0-70e9-87f3-436c4e3a4023}	f	0
01a12d25-a137-7221-8b5a-68b64c236dad	LCtyLDvbWy	Organisation en fonction du type de donnée	\N	\N	a08vN	{"type": "doc", "content": [{"type": "heading", "attrs": {"id": "igtthhgsebxd", "dir": "auto", "level": 3, "indent": 0}, "content": [{"text": "Plus d’utilisation de Miro ou Notion", "type": "text", "marks": [{"type": "underline", "attrs": {}}]}]}, {"type": "table", "attrs": {"dir": "auto"}, "content": [{"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableHeader", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "zmbscurmupcd", "dir": "auto", "indent": 0}, "content": [{"text": "Quoi", "type": "text"}]}]}, {"type": "tableHeader", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "xzxqexdkbnxq", "dir": "auto", "indent": 0}, "content": [{"text": "Où", "type": "text"}]}]}]}, {"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "prfpvdpubnbt", "dir": "auto", "indent": 0}, "content": [{"text": "Notes du track (point dur, veille, état de l’art, décisions)", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "fkutidchhhrg", "dir": "auto", "indent": 0}, "content": [{"text": "Docmost", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}]}]}]}, {"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "dgkteoajmwzq", "dir": "auto", "indent": 0}, "content": [{"text": "Comptes rendus de réunion, transcriptions", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "lobjjselfpnr", "dir": "auto", "indent": 0}, "content": [{"text": "Docmost", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}]}]}]}, {"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "exsdsjttoikm", "dir": "auto", "indent": 0}, "content": [{"text": "Journal de veille, notes de lecture, lexique", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "nbesiwzubiwn", "dir": "auto", "indent": 0}, "content": [{"text": "Docmost", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}]}]}]}, {"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "xrffgrqascmm", "dir": "auto", "indent": 0}, "content": [{"text": "Schémas, diagrammes, brainstorms", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "shlkzotgakhc", "dir": "auto", "indent": 0}, "content": [{"text": "Docmost", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}]}]}]}, {"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "wkvriwdbvjpp", "dir": "auto", "indent": 0}, "content": [{"text": "README, documentation d’API, documentation d’exploitation", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "crvgnlifmpfk", "dir": "auto", "indent": 0}, "content": [{"text": "Git", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}]}]}]}, {"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "bolaxswsskjt", "dir": "auto", "indent": 0}, "content": [{"text": "ADR (décisions d’architecture)", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "cazgtjqpbdhu", "dir": "auto", "indent": 0}, "content": [{"text": "Git", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}]}]}]}, {"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "hwghccsfotch", "dir": "auto", "indent": 0}, "content": [{"text": "Protocoles de mesure, scripts, fixtures", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "anawgkpxphcz", "dir": "auto", "indent": 0}, "content": [{"text": "Git", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}]}]}]}, {"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "lnqznyhouxoz", "dir": "auto", "indent": 0}, "content": [{"text": "Code", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "kpfszpsisupv", "dir": "auto", "indent": 0}, "content": [{"text": "Git", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}]}]}]}, {"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "beczdrmdkxfr", "dir": "auto", "indent": 0}, "content": [{"text": "Tâches", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "rfchzbufwnbj", "dir": "auto", "indent": 0}, "content": [{"text": "Jira", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}]}]}]}, {"type": "tableRow", "attrs": {"dir": "auto"}, "content": [{"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "zdgzknyyzdck", "dir": "auto", "indent": 0}, "content": [{"text": "Discussion", "type": "text"}]}]}, {"type": "tableCell", "attrs": {"dir": "auto", "colspan": 1, "rowspan": 1}, "content": [{"type": "paragraph", "attrs": {"id": "kfrhfqzpnvgr", "dir": "auto", "indent": 0}, "content": [{"text": "Discord", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}]}]}]}]}, {"type": "blockquote", "attrs": {"dir": "ltr"}, "content": [{"type": "paragraph", "attrs": {"id": "ctryvbqnbclh", "dir": "ltr", "indent": 0}, "content": [{"text": "Si ça vit à côté du code, c’est dans Git. Si c’est rédigé et relu par des humains, c’est dans Docmost.", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}]}]}, {"type": "paragraph", "attrs": {"id": "sbbxsrkqpspy", "dir": "auto", "indent": 0}, "content": []}]}	\\x01b902bad5c797070001010764656661756c7401000a41bad5c79707000100c50581bad5c797070001000ac1bad5c797070bbad5c7970700010039c7bad5c7970700bad5c79707d10503097061726167726170682100bad5c797079606026964012800bad5c79707960606696e64656e74017d002800bad5c797079606036469720177046175746f003ba1bad5c79707970601c1bad5c797079606bad5c79707d1050100030700bad5c797079606060100bad5c79707da060281bad5c79707dc0601c1bad5c79707dc06bad5c79707dd0602a1bad5c79707d5060147bad5c797070b030768656164696e670700bad5c79707e106060100bad5c79707e206282800bad5c79707e10602696401770c6967747468686773656278642800bad5c79707e10606696e64656e74017d002800bad5c79707e106036469720177046175746f2800bad5c79707e106056c6576656c017d03c1bad5c79707e106bad5c797070b0100ed04c1bad5c79707e106bad5c797078f0701002ac7bad5c79707fd0bbad5c797078f0703057461626c650700bad5c79707a80c03087461626c65526f770700bad5c79707a90c030b7461626c654865616465720700bad5c79707aa0c03097061726167726170680700bad5c79707ab0c060400bad5c79707ac0c0451756f692800bad5c79707ab0c02696401770c7a6d62736375726d757063642800bad5c79707ab0c06696e64656e74017d002800bad5c79707ab0c036469720177046175746f2800bad5c79707aa0c036469720177046175746f2800bad5c79707aa0c07636f6c7370616e017d012800bad5c79707aa0c07726f777370616e017d0187bad5c79707aa0c030b7461626c654865616465720700bad5c79707b70c03097061726167726170680700bad5c79707b80c060400bad5c79707b90c034fc3b92800bad5c79707b80c02696401770c787a78716578646b626e78712800bad5c79707b80c06696e64656e74017d002800bad5c79707b80c036469720177046175746f2800bad5c79707b70c036469720177046175746f2800bad5c79707b70c07636f6c7370616e017d012800bad5c79707b70c07726f777370616e017d012800bad5c79707a90c036469720177046175746f87bad5c79707a90c03087461626c65526f770700bad5c79707c30c03097461626c6543656c6c0700bad5c79707c40c03097061726167726170680700bad5c79707c50c060400bad5c79707c60c404e6f74657320647520747261636b2028706f696e74206475722c207665696c6c652c20c3a9746174206465206ce280996172742c2064c3a9636973696f6e73292800bad5c79707c50c02696401770c7072667076647075626e62742800bad5c79707c50c06696e64656e74017d002800bad5c79707c50c036469720177046175746f2800bad5c79707c40c036469720177046175746f2800bad5c79707c40c07636f6c7370616e017d012800bad5c79707c40c07726f777370616e017d0187bad5c79707c40c03097461626c6543656c6c0700bad5c79707890d03097061726167726170680700bad5c797078a0d060600bad5c797078b0d04626f6c64027b7d84bad5c797078c0d07446f636d6f737486bad5c79707930d04626f6c64046e756c6c2800bad5c797078a0d02696401770c666b757469646368686872672800bad5c797078a0d06696e64656e74017d002800bad5c797078a0d036469720177046175746f2800bad5c79707890d036469720177046175746f2800bad5c79707890d07636f6c7370616e017d012800bad5c79707890d07726f777370616e017d012800bad5c79707c30c036469720177046175746f87bad5c79707c30c03087461626c65526f770700bad5c797079c0d03097461626c6543656c6c0700bad5c797079d0d03097061726167726170680700bad5c797079e0d060400bad5c797079f0d2a436f6d707465732072656e6475732064652072c3a9756e696f6e2c207472616e736372697074696f6e732800bad5c797079e0d02696401770c64676b74656f616a6d777a712800bad5c797079e0d06696e64656e74017d002800bad5c797079e0d036469720177046175746f2800bad5c797079d0d036469720177046175746f2800bad5c797079d0d07636f6c7370616e017d012800bad5c797079d0d07726f777370616e017d0187bad5c797079d0d03097461626c6543656c6c0700bad5c79707cf0d03097061726167726170680700bad5c79707d00d060600bad5c79707d10d04626f6c64027b7d84bad5c79707d20d07446f636d6f737486bad5c79707d90d04626f6c64046e756c6c2800bad5c79707d00d02696401770c6c6f626a6a73656c66706e722800bad5c79707d00d06696e64656e74017d002800bad5c79707d00d036469720177046175746f2800bad5c79707cf0d036469720177046175746f2800bad5c79707cf0d07636f6c7370616e017d012800bad5c79707cf0d07726f777370616e017d012800bad5c797079c0d036469720177046175746f87bad5c797079c0d03087461626c65526f770700bad5c79707e20d03097461626c6543656c6c0700bad5c79707e30d03097061726167726170680700bad5c79707e40d060400bad5c79707e50d2c4a6f75726e616c206465207665696c6c652c206e6f746573206465206c6563747572652c206c6578697175652800bad5c79707e40d02696401770c65787364736a74746f696b6d2800bad5c79707e40d06696e64656e74017d002800bad5c79707e40d036469720177046175746f2800bad5c79707e30d036469720177046175746f2800bad5c79707e30d07636f6c7370616e017d012800bad5c79707e30d07726f777370616e017d0187bad5c79707e30d03097461626c6543656c6c0700bad5c79707980e03097061726167726170680700bad5c79707990e060600bad5c797079a0e04626f6c64027b7d84bad5c797079b0e07446f636d6f737486bad5c79707a20e04626f6c64046e756c6c2800bad5c79707990e02696401770c6e62657369777a756269776e2800bad5c79707990e06696e64656e74017d002800bad5c79707990e036469720177046175746f2800bad5c79707980e036469720177046175746f2800bad5c79707980e07636f6c7370616e017d012800bad5c79707980e07726f777370616e017d012800bad5c79707e20d036469720177046175746f87bad5c79707e20d03087461626c65526f770700bad5c79707ab0e03097461626c6543656c6c0700bad5c79707ac0e03097061726167726170680700bad5c79707ad0e060400bad5c79707ae0e21536368c3a96d61732c206469616772616d6d65732c20627261696e73746f726d732800bad5c79707ad0e02696401770c787266666772716173636d6d2800bad5c79707ad0e06696e64656e74017d002800bad5c79707ad0e036469720177046175746f2800bad5c79707ac0e036469720177046175746f2800bad5c79707ac0e07636f6c7370616e017d012800bad5c79707ac0e07726f777370616e017d0187bad5c79707ac0e03097461626c6543656c6c0700bad5c79707d50e03097061726167726170680700bad5c79707d60e060600bad5c79707d70e04626f6c64027b7d84bad5c79707d80e07446f636d6f737486bad5c79707df0e04626f6c64046e756c6c2800bad5c79707d60e02696401770c73686c6b7a6f7467616b68632800bad5c79707d60e06696e64656e74017d002800bad5c79707d60e036469720177046175746f2800bad5c79707d50e036469720177046175746f2800bad5c79707d50e07636f6c7370616e017d012800bad5c79707d50e07726f777370616e017d012800bad5c79707ab0e036469720177046175746f87bad5c79707ab0e03087461626c65526f770700bad5c79707e80e03097461626c6543656c6c0700bad5c79707e90e03097061726167726170680700bad5c79707ea0e060400bad5c79707eb0e3d524541444d452c20646f63756d656e746174696f6e2064e280994150492c20646f63756d656e746174696f6e2064e280996578706c6f69746174696f6e2800bad5c79707ea0e02696401770c776b767269776462766a70702800bad5c79707ea0e06696e64656e74017d002800bad5c79707ea0e036469720177046175746f2800bad5c79707e90e036469720177046175746f2800bad5c79707e90e07636f6c7370616e017d012800bad5c79707e90e07726f777370616e017d0187bad5c79707e90e03097461626c6543656c6c0700bad5c79707ab0f03097061726167726170680700bad5c79707ac0f060600bad5c79707ad0f04626f6c64027b7d84bad5c79707ae0f0347697486bad5c79707b10f04626f6c64046e756c6c2800bad5c79707ac0f02696401770c637276676e6c69666d70666b2800bad5c79707ac0f06696e64656e74017d002800bad5c79707ac0f036469720177046175746f2800bad5c79707ab0f036469720177046175746f2800bad5c79707ab0f07636f6c7370616e017d012800bad5c79707ab0f07726f777370616e017d012800bad5c79707e80e036469720177046175746f87bad5c79707e80e03087461626c65526f770700bad5c79707ba0f03097461626c6543656c6c0700bad5c79707bb0f03097061726167726170680700bad5c79707bc0f060400bad5c79707bd0f21414452202864c3a9636973696f6e732064e28099617263686974656374757265292800bad5c79707bc0f02696401770c626f6c6178737773736b6a742800bad5c79707bc0f06696e64656e74017d002800bad5c79707bc0f036469720177046175746f2800bad5c79707bb0f036469720177046175746f2800bad5c79707bb0f07636f6c7370616e017d012800bad5c79707bb0f07726f777370616e017d0187bad5c79707bb0f03097461626c6543656c6c0700bad5c79707e20f03097061726167726170680700bad5c79707e30f060600bad5c79707e40f04626f6c64027b7d84bad5c79707e50f0347697486bad5c79707e80f04626f6c64046e756c6c2800bad5c79707e30f02696401770c63617a67746a7170626468752800bad5c79707e30f06696e64656e74017d002800bad5c79707e30f036469720177046175746f2800bad5c79707e20f036469720177046175746f2800bad5c79707e20f07636f6c7370616e017d012800bad5c79707e20f07726f777370616e017d012800bad5c79707ba0f036469720177046175746f87bad5c79707ba0f03087461626c65526f770700bad5c79707f10f03097461626c6543656c6c0700bad5c79707f20f03097061726167726170680700bad5c79707f30f060400bad5c79707f40f2750726f746f636f6c6573206465206d65737572652c20736372697074732c2066697874757265732800bad5c79707f30f02696401770c68776768636373666f7463682800bad5c79707f30f06696e64656e74017d002800bad5c79707f30f036469720177046175746f2800bad5c79707f20f036469720177046175746f2800bad5c79707f20f07636f6c7370616e017d012800bad5c79707f20f07726f777370616e017d0187bad5c79707f20f03097461626c6543656c6c0700bad5c79707a21003097061726167726170680700bad5c79707a310060600bad5c79707a41004626f6c64027b7d84bad5c79707a5100347697486bad5c79707a81004626f6c64046e756c6c2800bad5c79707a31002696401770c616e6177676b70787068637a2800bad5c79707a31006696e64656e74017d002800bad5c79707a310036469720177046175746f2800bad5c79707a210036469720177046175746f2800bad5c79707a21007636f6c7370616e017d012800bad5c79707a21007726f777370616e017d012800bad5c79707f10f036469720177046175746f87bad5c79707f10f03087461626c65526f770700bad5c79707b11003097461626c6543656c6c0700bad5c79707b21003097061726167726170680700bad5c79707b310060400bad5c79707b41004436f64652800bad5c79707b31002696401770c6c6e717a6e79686f75786f7a2800bad5c79707b31006696e64656e74017d002800bad5c79707b310036469720177046175746f2800bad5c79707b210036469720177046175746f2800bad5c79707b21007636f6c7370616e017d012800bad5c79707b21007726f777370616e017d0187bad5c79707b21003097461626c6543656c6c0700bad5c79707bf1003097061726167726170680700bad5c79707c010060600bad5c79707c11004626f6c64027b7d84bad5c79707c2100347697486bad5c79707c51004626f6c64046e756c6c2800bad5c79707c01002696401770c6b7066737a707369737570762800bad5c79707c01006696e64656e74017d002800bad5c79707c010036469720177046175746f2800bad5c79707bf10036469720177046175746f2800bad5c79707bf1007636f6c7370616e017d012800bad5c79707bf1007726f777370616e017d012800bad5c79707b110036469720177046175746f87bad5c79707b11003087461626c65526f770700bad5c79707ce1003097461626c6543656c6c0700bad5c79707cf1003097061726167726170680700bad5c79707d010060400bad5c79707d1100754c3a2636865732800bad5c79707d01002696401770c6265637a64726d646b7866722800bad5c79707d01006696e64656e74017d002800bad5c79707d010036469720177046175746f2800bad5c79707cf10036469720177046175746f2800bad5c79707cf1007636f6c7370616e017d012800bad5c79707cf1007726f777370616e017d0187bad5c79707cf1003097461626c6543656c6c0700bad5c79707de1003097061726167726170680700bad5c79707df10060600bad5c79707e01004626f6c64027b7d84bad5c79707e110044a69726186bad5c79707e51004626f6c64046e756c6c2800bad5c79707df1002696401770c726663687a627566776e626a2800bad5c79707df1006696e64656e74017d002800bad5c79707df10036469720177046175746f2800bad5c79707de10036469720177046175746f2800bad5c79707de1007636f6c7370616e017d012800bad5c79707de1007726f777370616e017d012800bad5c79707ce10036469720177046175746f87bad5c79707ce1003087461626c65526f770700bad5c79707ee1003097461626c6543656c6c0700bad5c79707ef1003097061726167726170680700bad5c79707f010060400bad5c79707f1100a44697363757373696f6e2800bad5c79707f01002696401770c7a64677a6b6e79797a64636b2800bad5c79707f01006696e64656e74017d002800bad5c79707f010036469720177046175746f2800bad5c79707ef10036469720177046175746f2800bad5c79707ef1007636f6c7370616e017d012800bad5c79707ef1007726f777370616e017d0187bad5c79707ef1003097461626c6543656c6c0700bad5c79707821103097061726167726170680700bad5c797078311060600bad5c79707841104626f6c64027b7d84bad5c79707851107446973636f726486bad5c797078c1104626f6c64046e756c6c2800bad5c79707831102696401770c6b66726866717a706e7667722800bad5c79707831106696e64656e74017d002800bad5c797078311036469720177046175746f2800bad5c797078211036469720177046175746f2800bad5c79707821107636f6c7370616e017d012800bad5c79707821107726f777370616e017d012800bad5c79707ee10036469720177046175746f2800bad5c79707a80c036469720177046175746f0002c1bad5c79707fd0bbad5c79707a80c01000384bad5c797078a0726506c75732064e280997574696c69736174696f6e206465204d69726f206f75204e6f74696f6ec6bad5c797078a07bad5c797079c1109756e6465726c696e65027b7d86bad5c79707bf1109756e6465726c696e65046e756c6ca8bad5c79707e00601770c7362627873726b7170737079c7bad5c79707a80cbad5c797078f07030a626c6f636b71756f74650700bad5c79707c31103097061726167726170680700bad5c79707c411060600bad5c79707c51104626f6c64027b7d84bad5c79707c61172536920c3a7612076697420c3a02063c3b474c3a920647520636f64652c2063e280996573742064616e73204769742e2053692063e280996573742072c3a9646967c3a92065742072656c7520706172206465732068756d61696e732c2063e280996573742064616e7320446f636d6f73742e86bad5c79707ac1204626f6c64046e756c6c2800bad5c79707c41102696401770c637472797662716e62636c682800bad5c79707c41106696e64656e74017d002800bad5c79707c411036469720177036c74722800bad5c79707c311036469720177036c747201bad5c79707070096069706019a0640db0606e306288f079905961106	Plus d’utilisation de Miro ou Notion\n\nQuoi\n\nOù\n\nNotes du track (point dur, veille, état de l’art, décisions)\n\nDocmost\n\nComptes rendus de réunion, transcriptions\n\nDocmost\n\nJournal de veille, notes de lecture, lexique\n\nDocmost\n\nSchémas, diagrammes, brainstorms\n\nDocmost\n\nREADME, documentation d’API, documentation d’exploitation\n\nGit\n\nADR (décisions d’architecture)\n\nGit\n\nProtocoles de mesure, scripts, fixtures\n\nGit\n\nCode\n\nGit\n\nTâches\n\nJira\n\nDiscussion\n\nDiscord\n\nSi ça vit à côté du code, c’est dans Git. Si c’est rédigé et relu par des humains, c’est dans Docmost.\n\n	'adr':55B 'api':50B 'architectur':58B 'art':26B 'brainstorm':45B 'c':79B,84B,92B 'ca':73B 'code':66B,78B 'compt':29B 'cote':76B 'd':9B,49B,52B,57B 'dan':81B,94B 'de':6A,11B,24B,31B,36B,39B,61B 'decis':27B,56B 'des':90B 'diagramm':44B 'discord':71B 'discuss':70B 'docmost':28B,34B,42B,46B,95B 'document':48B,51B 'donne':7A 'du':4A,18B,77B 'dur':21B 'en':2A 'est':80B,85B,93B 'et':87B 'etat':23B 'exploit':53B 'fixtur':64B 'fonction':3A 'git':54B,59B,65B,67B,82B 'humain':91B 'jira':69B 'journal':35B 'l':25B 'lectur':40B 'lexiqu':41B 'mesur':62B 'miro':12B 'note':17B,38B 'notion':14B 'organis':1A 'ou':13B,16B 'par':89B 'plus':8B 'point':20B 'protocol':60B 'quoi':15B 'readm':47B 'redig':86B 'relu':88B 'rendus':30B 'reunion':32B 'schema':43B 'script':63B 'si':72B,83B 'tach':68B 'track':19B 'transcript':33B 'type':5A 'utilis':10B 'veill':22B,37B 'vit':74B	\N	01a12cf1-0bd0-70e9-87f3-436c4e3a4023	01a12cf1-0bd0-70e9-87f3-436c4e3a4023	\N	01a12d14-ccca-79ae-806d-a787dc9cf7f8	01a12cf1-0bd3-7a42-96f8-8cedaf38cf22	f	2026-10-11 22:46:43.251912+00	2026-10-11 22:49:46.273+00	\N	{01a12cf1-0bd0-70e9-87f3-436c4e3a4023}	f	0
01a12d3a-1fe1-756d-8198-216ad9c34fa6	0z6l68bwhG	Dispositif de veille technologique	\N	\N	a28C5	{"type": "doc", "content": [{"type": "paragraph", "attrs": {"id": "advhmwtcyntv", "dir": "auto", "indent": 0}}]}	\\x0104e1ed839a0f0007010764656661756c7403097061726167726170682800e1ed839a0f0002696401770c616476686d777463796e74762800e1ed839a0f0006696e64656e74017d002800e1ed839a0f00036469720177046175746f00		'de':2A 'dispositif':1A 'technologiqu':4A 'veill':3A	\N	01a12cf1-0bd0-70e9-87f3-436c4e3a4023	01a12cf1-0bd0-70e9-87f3-436c4e3a4023	\N	01a12cf1-0bdd-72b8-9465-6c1e33f4a9c9	01a12cf1-0bd3-7a42-96f8-8cedaf38cf22	f	2026-10-11 23:09:06.400732+00	2026-10-11 23:09:53.473+00	\N	{01a12cf1-0bd0-70e9-87f3-436c4e3a4023}	f	0
01a12d3d-5791-724e-b806-eff94b764e78	sXNWvhvlC2	[test-roundtrip] 1791760357232	\N	\N	a17Qa	{"type": "doc", "content": [{"type": "heading", "attrs": {"id": "evxgawasuvtg", "dir": "auto", "level": 1, "indent": 0}, "content": [{"text": "Titre test", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "nkzkjdmrwylu", "dir": "auto", "indent": 0}, "content": [{"text": "Paragraphe ", "type": "text"}, {"text": "gras", "type": "text", "marks": [{"type": "bold", "attrs": {}}]}, {"text": " et ", "type": "text"}, {"text": "italique", "type": "text", "marks": [{"type": "italic", "attrs": {}}]}, {"text": ".", "type": "text"}]}, {"type": "codeBlock", "attrs": {"dir": "auto", "language": "js"}, "content": [{"text": "console.log('hello');", "type": "text"}]}, {"type": "heading", "attrs": {"id": "xnblackbmhpl", "dir": "auto", "level": 2, "indent": 0}, "content": [{"text": "Section ajoutée", "type": "text"}]}, {"type": "paragraph", "attrs": {"id": "snhiqcdjflwd", "dir": "auto", "indent": 0}, "content": [{"text": "Contenu supplémentaire.", "type": "text"}]}]}	\\x020da1b6aaed0d0087c9ceaab30635030768656164696e670700a1b6aaed0d00060400a1b6aaed0d011053656374696f6e20616a6f7574c3a9652800a1b6aaed0d0002696401770c786e626c61636b626d68706c2800a1b6aaed0d0006696e64656e74017d002800a1b6aaed0d00036469720177046175746f2800a1b6aaed0d00056c6576656c017d0287a1b6aaed0d0003097061726167726170680700a1b6aaed0d15060400a1b6aaed0d1618436f6e74656e7520737570706cc3a96d656e74616972652e2800a1b6aaed0d1502696401770c736e68697163646a666c77642800a1b6aaed0d1506696e64656e74017d002800a1b6aaed0d15036469720177046175746f1ac9ceaab3060007010764656661756c74030768656164696e670700c9ceaab30600060400c9ceaab306010a546974726520746573742800c9ceaab3060002696401770c6576786761776173757674672800c9ceaab3060006696e64656e74017d002800c9ceaab30600036469720177046175746f2800c9ceaab30600056c6576656c017d0187c9ceaab3060003097061726167726170680700c9ceaab30610060400c9ceaab306110b506172616772617068652086c9ceaab3061c04626f6c64027b7d84c9ceaab3061d046772617386c9ceaab3062104626f6c64046e756c6c84c9ceaab30622042065742086c9ceaab30626066974616c6963027b7d84c9ceaab30627086974616c6971756586c9ceaab3062f066974616c6963046e756c6c84c9ceaab30630012e2800c9ceaab3061002696401770c6e6b7a6b6a646d7277796c752800c9ceaab3061006696e64656e74017d002800c9ceaab30610036469720177046175746f87c9ceaab306100309636f6465426c6f636b0700c9ceaab30635060400c9ceaab3063615636f6e736f6c652e6c6f67282768656c6c6f27293b2800c9ceaab30635036469720177046175746f2800c9ceaab30635086c616e67756167650177026a7300	Titre test\n\nParagraphe gras et italique.\n\nconsole.log('hello');\n\nSection ajoutée\n\nContenu supplémentaire.	'1791760357232':4A 'ajoute':14B 'console.log':11B 'contenu':15B 'et':9B 'gras':8B 'hello':12B 'italiqu':10B 'paragraph':7B 'roundtrip':3A 'section':13B 'supplementair':16B 'test':2A,6B 'test-roundtrip':1A 'titr':5B	\N	01a12cf1-0bd0-70e9-87f3-436c4e3a4023	01a12cf1-0bd0-70e9-87f3-436c4e3a4023	01a12cf1-0bd0-70e9-87f3-436c4e3a4023	01a12d28-97bc-7e08-89d5-3b6f4a7a6d57	01a12cf1-0bd3-7a42-96f8-8cedaf38cf22	f	2026-10-11 23:12:37.264585+00	2026-10-11 23:12:37.763+00	2026-10-11 23:12:37.983+00	{01a12cf1-0bd0-70e9-87f3-436c4e3a4023}	f	0
\.


--
-- Data for Name: public_spaces; Type: TABLE DATA; Schema: public; Owner: docmost
--

COPY public.public_spaces (id, space_id, workspace_id, enabled, search_indexing, settings, creator_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: scim_tokens; Type: TABLE DATA; Schema: public; Owner: docmost
--

COPY public.scim_tokens (id, name, token_hash, token_last_four, last_used_at, is_enabled, creator_id, workspace_id, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: shares; Type: TABLE DATA; Schema: public; Owner: docmost
--

COPY public.shares (id, key, page_id, include_sub_pages, search_indexing, creator_id, space_id, workspace_id, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: siem_destinations; Type: TABLE DATA; Schema: public; Owner: docmost
--

COPY public.siem_destinations (id, workspace_id, name, type, enabled, config, secrets, cursor_created_at, cursor_id, cursor_snapshot, version, status, consecutive_failures, next_attempt_at, last_delivered_at, last_error, last_error_at, failing_since, creator_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: space_members; Type: TABLE DATA; Schema: public; Owner: docmost
--

COPY public.space_members (id, user_id, group_id, space_id, role, added_by_id, created_at, updated_at, deleted_at) FROM stdin;
01a12cf1-0bde-7b50-883e-6e38ef9a3a6c	01a12cf1-0bd0-70e9-87f3-436c4e3a4023	\N	01a12cf1-0bdd-72b8-9465-6c1e33f4a9c9	admin	\N	2026-10-11 21:49:16.853587+00	2026-10-11 21:49:16.853587+00	\N
01a12cf1-0be0-773f-8df4-972808c31f35	\N	01a12cf1-0bd6-70e1-9230-cec6bb016d1b	01a12cf1-0bdd-72b8-9465-6c1e33f4a9c9	admin	\N	2026-10-11 21:49:16.853587+00	2026-10-11 21:49:16.853587+00	\N
01a12d14-cccd-77aa-89a9-ff79b4be83f7	01a12cf1-0bd0-70e9-87f3-436c4e3a4023	\N	01a12d14-ccca-79ae-806d-a787dc9cf7f8	admin	\N	2026-10-11 22:28:20.29637+00	2026-10-11 22:28:20.29637+00	\N
01a12d28-97be-76bc-a9b4-ce1ed8b40859	01a12cf1-0bd0-70e9-87f3-436c4e3a4023	\N	01a12d28-97bc-7e08-89d5-3b6f4a7a6d57	admin	\N	2026-10-11 22:49:57.434465+00	2026-10-11 22:49:57.434465+00	\N
01a12d29-3a98-7642-a16e-1f4c44b7d8d0	01a12cf1-0bd0-70e9-87f3-436c4e3a4023	\N	01a12d29-3a97-7210-ac78-1927a95f2edd	admin	\N	2026-10-11 22:50:39.125315+00	2026-10-11 22:50:39.125315+00	\N
\.


--
-- Data for Name: spaces; Type: TABLE DATA; Schema: public; Owner: docmost
--

COPY public.spaces (id, name, description, slug, logo, visibility, default_role, creator_id, workspace_id, created_at, updated_at, deleted_at, settings, is_personal) FROM stdin;
01a12cf1-0bdd-72b8-9465-6c1e33f4a9c9	Documents Epitech	Les documents demandés par Epitech	epitech	ef5bb71d-1146-4a56-b22b-82d01b9b1014.png	private	writer	01a12cf1-0bd0-70e9-87f3-436c4e3a4023	01a12cf1-0bd3-7a42-96f8-8cedaf38cf22	2026-10-11 21:49:16.853587+00	2026-10-11 22:23:11.527+00	\N	\N	f
01a12d14-ccca-79ae-806d-a787dc9cf7f8	Documentation KansOS		doc	f749a1ee-5be2-499e-a223-2a3c0285f69d.png	private	writer	01a12cf1-0bd0-70e9-87f3-436c4e3a4023	01a12cf1-0bd3-7a42-96f8-8cedaf38cf22	2026-10-11 22:28:20.29637+00	2026-10-11 22:28:28.33+00	\N	\N	f
01a12d28-97bc-7e08-89d5-3b6f4a7a6d57	Comptes rendus		comptes-rendus	de7738bb-ecd0-4ac6-9864-eda67a2bcd64.png	private	writer	01a12cf1-0bd0-70e9-87f3-436c4e3a4023	01a12cf1-0bd3-7a42-96f8-8cedaf38cf22	2026-10-11 22:49:57.434465+00	2026-10-11 22:50:20.372+00	\N	\N	f
01a12d29-3a97-7210-ac78-1927a95f2edd	Veille Techno		VT	98ed8e59-4d69-4ab7-80a4-d22bf714d631.png	private	writer	01a12cf1-0bd0-70e9-87f3-436c4e3a4023	01a12cf1-0bd3-7a42-96f8-8cedaf38cf22	2026-10-11 22:50:39.125315+00	2026-10-11 22:50:56.432+00	\N	\N	f
\.


--
-- Data for Name: templates; Type: TABLE DATA; Schema: public; Owner: docmost
--

COPY public.templates (id, title, description, content, ydoc, icon, space_id, workspace_id, creator_id, last_updated_by_id, collaborator_ids, text_content, tsv, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: user_mfa; Type: TABLE DATA; Schema: public; Owner: docmost
--

COPY public.user_mfa (id, user_id, method, secret, is_enabled, backup_codes, workspace_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_sessions; Type: TABLE DATA; Schema: public; Owner: docmost
--

COPY public.user_sessions (id, user_id, workspace_id, device_name, user_agent, ip_address, geo_location, last_active_at, expires_at, metadata, revoked_at, created_at) FROM stdin;
01a12d13-45f5-73f8-b271-8a157c655e8f	01a12cf1-0bd0-70e9-87f3-436c4e3a4023	01a12cf1-0bd3-7a42-96f8-8cedaf38cf22	\N	\N	146.66.237.141	\N	2026-10-11 22:26:40.42+00	2027-01-09 22:26:40.244+00	\N	\N	2026-10-11 22:26:40.244631+00
01a12d13-dcad-7608-b7d8-14b35de96b44	01a12cf1-0bd0-70e9-87f3-436c4e3a4023	01a12cf1-0bd3-7a42-96f8-8cedaf38cf22	\N	\N	146.66.237.141	\N	2026-10-11 22:27:18.961+00	2027-01-09 22:27:18.828+00	\N	\N	2026-10-11 22:27:18.828731+00
01a12d14-d793-7ec9-bf86-46b28a7a7aab	01a12cf1-0bd0-70e9-87f3-436c4e3a4023	01a12cf1-0bd3-7a42-96f8-8cedaf38cf22	\N	\N	146.66.237.141	\N	2026-10-11 22:28:23.205+00	2027-01-09 22:28:23.058+00	\N	\N	2026-10-11 22:28:23.059219+00
01a12d16-d957-71b6-90e9-69b9622f279c	01a12cf1-0bd0-70e9-87f3-436c4e3a4023	01a12cf1-0bd3-7a42-96f8-8cedaf38cf22	\N	\N	146.66.237.141	\N	2026-10-11 22:30:34.582631+00	2027-01-09 22:30:34.582+00	\N	\N	2026-10-11 22:30:34.582631+00
01a12d16-dc42-7077-ae6e-90945698da0f	01a12cf1-0bd0-70e9-87f3-436c4e3a4023	01a12cf1-0bd3-7a42-96f8-8cedaf38cf22	\N	\N	146.66.237.141	\N	2026-10-11 22:30:35.329431+00	2027-01-09 22:30:35.328+00	\N	\N	2026-10-11 22:30:35.329431+00
01a12d16-d94c-7b60-abe2-5247c4c70139	01a12cf1-0bd0-70e9-87f3-436c4e3a4023	01a12cf1-0bd3-7a42-96f8-8cedaf38cf22	\N	\N	146.66.237.141	\N	2026-10-11 22:30:54.852+00	2027-01-09 22:30:34.571+00	\N	\N	2026-10-11 22:30:34.571916+00
01a12d17-fe34-7b71-ac00-6c9df5556da4	01a12cf1-0bd0-70e9-87f3-436c4e3a4023	01a12cf1-0bd3-7a42-96f8-8cedaf38cf22	\N	\N	146.66.237.141	\N	2026-10-11 22:31:49.696+00	2027-01-09 22:31:49.555+00	\N	\N	2026-10-11 22:31:49.556113+00
01a12d1a-f6bb-71c7-a4d0-e926ab70f35a	01a12cf1-0bd0-70e9-87f3-436c4e3a4023	01a12cf1-0bd3-7a42-96f8-8cedaf38cf22	\N	\N	146.66.237.141	\N	2026-10-11 22:35:04.397+00	2027-01-09 22:35:04.249+00	\N	\N	2026-10-11 22:35:04.250235+00
01a12d33-993c-7a7b-938e-41c39b970e4f	01a12cf1-0bd0-70e9-87f3-436c4e3a4023	01a12cf1-0bd3-7a42-96f8-8cedaf38cf22	\N	\N	146.66.237.141	\N	2026-10-11 23:01:58.715792+00	2027-01-09 23:01:58.715+00	\N	\N	2026-10-11 23:01:58.715792+00
01a12d33-9c97-7d50-bb25-a08115269125	01a12cf1-0bd0-70e9-87f3-436c4e3a4023	01a12cf1-0bd3-7a42-96f8-8cedaf38cf22	\N	\N	146.66.237.141	\N	2026-10-11 23:01:59.574951+00	2027-01-09 23:01:59.574+00	\N	\N	2026-10-11 23:01:59.574951+00
01a12d33-99dd-79ae-a147-073a2e965f9f	01a12cf1-0bd0-70e9-87f3-436c4e3a4023	01a12cf1-0bd3-7a42-96f8-8cedaf38cf22	\N	\N	146.66.237.141	\N	2026-10-11 23:02:17.238+00	2027-01-09 23:01:58.876+00	\N	\N	2026-10-11 23:01:58.876873+00
01a12d35-b67e-794c-a36b-1f0edb68bd80	01a12cf1-0bd0-70e9-87f3-436c4e3a4023	01a12cf1-0bd3-7a42-96f8-8cedaf38cf22	\N	\N	146.66.237.141	\N	2026-10-11 23:04:17.27784+00	2027-01-09 23:04:17.277+00	\N	\N	2026-10-11 23:04:17.27784+00
01a12d35-de17-7185-a7b4-d3d360e0ec85	01a12cf1-0bd0-70e9-87f3-436c4e3a4023	01a12cf1-0bd3-7a42-96f8-8cedaf38cf22	\N	\N	146.66.237.141	\N	2026-10-11 23:04:27.414316+00	2027-01-09 23:04:27.413+00	\N	\N	2026-10-11 23:04:27.414316+00
01a12d37-5bb7-7760-96c7-dd7a7c389502	01a12cf1-0bd0-70e9-87f3-436c4e3a4023	01a12cf1-0bd3-7a42-96f8-8cedaf38cf22	\N	\N	146.66.237.141	\N	2026-10-11 23:06:05.110593+00	2027-01-09 23:06:05.109+00	\N	\N	2026-10-11 23:06:05.110593+00
01a12d38-b8a1-7b3b-a3b9-01a08aa78a34	01a12cf1-0bd0-70e9-87f3-436c4e3a4023	01a12cf1-0bd3-7a42-96f8-8cedaf38cf22	\N	\N	146.66.237.141	\N	2026-10-11 23:07:34.432702+00	2027-01-09 23:07:34.431+00	\N	\N	2026-10-11 23:07:34.432702+00
01a12d38-bae2-76d5-abbe-c0e7f45788bd	01a12cf1-0bd0-70e9-87f3-436c4e3a4023	01a12cf1-0bd3-7a42-96f8-8cedaf38cf22	\N	\N	146.66.237.141	\N	2026-10-11 23:07:35.009742+00	2027-01-09 23:07:35.009+00	\N	\N	2026-10-11 23:07:35.009742+00
01a12d38-b8a2-7c1d-b9f9-7f0df76ca3d2	01a12cf1-0bd0-70e9-87f3-436c4e3a4023	01a12cf1-0bd3-7a42-96f8-8cedaf38cf22	\N	\N	146.66.237.141	\N	2026-10-11 23:07:59.924+00	2027-01-09 23:07:34.432+00	\N	\N	2026-10-11 23:07:34.433008+00
01a12d3d-56b1-7f2b-a541-a2bb42ef49d4	01a12cf1-0bd0-70e9-87f3-436c4e3a4023	01a12cf1-0bd3-7a42-96f8-8cedaf38cf22	\N	\N	146.66.237.141	\N	2026-10-11 23:12:37.195+00	2027-01-09 23:12:37.04+00	\N	\N	2026-10-11 23:12:37.040989+00
01a12d3d-f693-7fdb-b2b1-e894f7f8ba37	01a12cf1-0bd0-70e9-87f3-436c4e3a4023	01a12cf1-0bd3-7a42-96f8-8cedaf38cf22	\N	\N	146.66.237.141	\N	2026-10-11 23:13:17.968388+00	2027-01-09 23:13:17.967+00	\N	\N	2026-10-11 23:13:17.968388+00
01a12d3d-f938-726a-8e7c-559bcb685438	01a12cf1-0bd0-70e9-87f3-436c4e3a4023	01a12cf1-0bd3-7a42-96f8-8cedaf38cf22	\N	\N	146.66.237.141	\N	2026-10-11 23:13:18.647459+00	2027-01-09 23:13:18.646+00	\N	\N	2026-10-11 23:13:18.647459+00
01a12d3d-f6db-77c7-8150-969b1b2e8fa2	01a12cf1-0bd0-70e9-87f3-436c4e3a4023	01a12cf1-0bd3-7a42-96f8-8cedaf38cf22	\N	\N	146.66.237.141	\N	2026-10-11 23:13:30.386+00	2027-01-09 23:13:18.042+00	\N	\N	2026-10-11 23:13:18.042802+00
01a131fd-540e-7517-93e4-8c8e232c53c4	01a12cf1-0bd0-70e9-87f3-436c4e3a4023	01a12cf1-0bd3-7a42-96f8-8cedaf38cf22	\N	\N	146.66.237.141	\N	2026-10-12 21:20:48.138338+00	2027-01-10 21:20:48.137+00	\N	\N	2026-10-12 21:20:48.138338+00
01a131fd-54d8-7db2-80cb-821bf9139be1	01a12cf1-0bd0-70e9-87f3-436c4e3a4023	01a12cf1-0bd3-7a42-96f8-8cedaf38cf22	\N	\N	146.66.237.141	\N	2026-10-12 21:20:48.344331+00	2027-01-10 21:20:48.343+00	\N	\N	2026-10-12 21:20:48.344331+00
01a131fd-570d-78c9-8eed-4456196fb093	01a12cf1-0bd0-70e9-87f3-436c4e3a4023	01a12cf1-0bd3-7a42-96f8-8cedaf38cf22	\N	\N	146.66.237.141	\N	2026-10-12 21:20:48.909044+00	2027-01-10 21:20:48.908+00	\N	\N	2026-10-12 21:20:48.909044+00
01a12cf1-0be7-7b85-8ea9-b9bcb14b3836	01a12cf1-0bd0-70e9-87f3-436c4e3a4023	01a12cf1-0bd3-7a42-96f8-8cedaf38cf22	\N	\N	\N	\N	2026-10-12 21:52:01.213+00	2027-01-09 21:49:17.156+00	\N	\N	2026-10-11 21:49:17.157049+00
\.


--
-- Data for Name: user_tokens; Type: TABLE DATA; Schema: public; Owner: docmost
--

COPY public.user_tokens (id, token, type, user_id, workspace_id, expires_at, used_at, created_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: docmost
--

COPY public.users (id, name, email, email_verified_at, password, avatar_url, role, invited_by_id, workspace_id, locale, timezone, settings, last_active_at, last_login_at, deactivated_at, created_at, updated_at, deleted_at, has_generated_password, scim_external_id) FROM stdin;
01a12cf1-0bd0-70e9-87f3-436c4e3a4023	Elias Josué HAJJAR LLAUQUEN	heliasjosue@protonmail.com	2026-10-11 21:49:16.853+00	$2b$12$VMsmtrqRs6gRlIUarBtx7.SqemLsbyB9CwBFcgDU3hoLSiLIh00z6	\N	owner	\N	01a12cf1-0bd3-7a42-96f8-8cedaf38cf22	en-US	\N	\N	2026-10-12 21:52:01.214+00	2026-10-12 21:20:48.911+00	\N	2026-10-11 21:49:16.853587+00	2026-10-12 21:52:01.214+00	\N	f	\N
\.


--
-- Data for Name: watchers; Type: TABLE DATA; Schema: public; Owner: docmost
--

COPY public.watchers (id, user_id, page_id, space_id, workspace_id, type, added_by_id, muted_at, created_at) FROM stdin;
01a12d10-e30f-7c3d-8293-737903be64c1	01a12cf1-0bd0-70e9-87f3-436c4e3a4023	01a12d10-e301-772b-b847-6b22997917de	01a12cf1-0bdd-72b8-9465-6c1e33f4a9c9	01a12cf1-0bd3-7a42-96f8-8cedaf38cf22	page	01a12cf1-0bd0-70e9-87f3-436c4e3a4023	\N	2026-10-11 22:24:03.853469+00
01a12d16-3fe0-7c83-b8c5-49c766303b0e	01a12cf1-0bd0-70e9-87f3-436c4e3a4023	01a12d16-3fd6-74cd-9bbc-0c82d20f72bb	01a12cf1-0bdd-72b8-9465-6c1e33f4a9c9	01a12cf1-0bd3-7a42-96f8-8cedaf38cf22	page	01a12cf1-0bd0-70e9-87f3-436c4e3a4023	\N	2026-10-11 22:29:55.294295+00
01a12d25-a146-7958-af9c-1ccd2a4554b0	01a12cf1-0bd0-70e9-87f3-436c4e3a4023	01a12d25-a137-7221-8b5a-68b64c236dad	01a12d14-ccca-79ae-806d-a787dc9cf7f8	01a12cf1-0bd3-7a42-96f8-8cedaf38cf22	page	01a12cf1-0bd0-70e9-87f3-436c4e3a4023	\N	2026-10-11 22:46:43.266374+00
01a12d29-b342-7ab8-93ad-7c5ac0824e57	01a12cf1-0bd0-70e9-87f3-436c4e3a4023	01a12d29-b33c-7771-a510-a4f4d1590e6d	01a12d28-97bc-7e08-89d5-3b6f4a7a6d57	01a12cf1-0bd3-7a42-96f8-8cedaf38cf22	page	01a12cf1-0bd0-70e9-87f3-436c4e3a4023	\N	2026-10-11 22:51:10.017547+00
01a12d3a-1fe6-7ee5-9144-f3b6e0fd3897	01a12cf1-0bd0-70e9-87f3-436c4e3a4023	01a12d3a-1fe1-756d-8198-216ad9c34fa6	01a12cf1-0bdd-72b8-9465-6c1e33f4a9c9	01a12cf1-0bd3-7a42-96f8-8cedaf38cf22	page	01a12cf1-0bd0-70e9-87f3-436c4e3a4023	\N	2026-10-11 23:09:06.406473+00
01a12d3d-5799-75ec-865e-c1adbcb75ba7	01a12cf1-0bd0-70e9-87f3-436c4e3a4023	01a12d3d-5791-724e-b806-eff94b764e78	01a12d28-97bc-7e08-89d5-3b6f4a7a6d57	01a12cf1-0bd3-7a42-96f8-8cedaf38cf22	page	01a12cf1-0bd0-70e9-87f3-436c4e3a4023	\N	2026-10-11 23:12:37.270456+00
01a12d3e-a06b-7991-ad5f-bde92bcba29e	01a12cf1-0bd0-70e9-87f3-436c4e3a4023	01a12d3e-a064-7971-b3f5-23da8d8c0bab	01a12d29-3a97-7210-ac78-1927a95f2edd	01a12cf1-0bd3-7a42-96f8-8cedaf38cf22	page	01a12cf1-0bd0-70e9-87f3-436c4e3a4023	\N	2026-10-11 23:14:01.450655+00
\.


--
-- Data for Name: workspace_invitations; Type: TABLE DATA; Schema: public; Owner: docmost
--

COPY public.workspace_invitations (id, email, role, token, group_ids, invited_by_id, workspace_id, created_at, updated_at) FROM stdin;
01a12cf5-7867-79a6-885d-b187fa897b9b	alexandre.odrisolo@epitech.eu	admin	47358owcno1l1n3t	{01a12cf3-c1db-748f-9dc6-0218709264ca}	01a12cf1-0bd0-70e9-87f3-436c4e3a4023	01a12cf1-0bd3-7a42-96f8-8cedaf38cf22	2026-10-11 21:54:07.071863+00	2026-10-11 21:54:07.071863+00
01a12cf5-7868-7c46-af6b-4f0305f067a6	enzo.lobato-coutinho@epitech.eu	admin	mxae3hgqlgr0hmqm	{01a12cf3-c1db-748f-9dc6-0218709264ca}	01a12cf1-0bd0-70e9-87f3-436c4e3a4023	01a12cf1-0bd3-7a42-96f8-8cedaf38cf22	2026-10-11 21:54:07.071863+00	2026-10-11 21:54:07.071863+00
01a12cf5-7868-7d5c-b211-0a6e0cd0933c	lucas.carre@epitech.eu	admin	qq9xidqk3o2qs1og	{01a12cf3-c1db-748f-9dc6-0218709264ca}	01a12cf1-0bd0-70e9-87f3-436c4e3a4023	01a12cf1-0bd3-7a42-96f8-8cedaf38cf22	2026-10-11 21:54:07.071863+00	2026-10-11 21:54:07.071863+00
01a12cf5-7868-7e6a-86e5-2aeff074a2a4	angel.severan@epitech.eu	admin	6vdw4q34h4qw6wpz	{01a12cf3-c1db-748f-9dc6-0218709264ca}	01a12cf1-0bd0-70e9-87f3-436c4e3a4023	01a12cf1-0bd3-7a42-96f8-8cedaf38cf22	2026-10-11 21:54:07.071863+00	2026-10-11 21:54:07.071863+00
\.


--
-- Data for Name: workspaces; Type: TABLE DATA; Schema: public; Owner: docmost
--

COPY public.workspaces (id, name, description, logo, hostname, custom_domain, settings, default_role, email_domains, default_space_id, created_at, updated_at, deleted_at, stripe_customer_id, status, plan, billing_email, trial_end_at, enforce_sso, license_key, enforce_mfa, audit_retention_days, trash_retention_days, is_scim_enabled) FROM stdin;
01a12cf1-0bd3-7a42-96f8-8cedaf38cf22	KansOS Documentation	\N	bcae10a6-af97-4afd-bf94-8d8798c267cf.png	\N	\N	\N	member	{}	01a12cf1-0bdd-72b8-9465-6c1e33f4a9c9	2026-10-11 21:49:16.853587+00	2026-10-11 21:55:06.85+00	\N	\N	\N	\N	\N	\N	f	\N	f	\N	\N	f
\.


--
-- Name: ai_chat_messages ai_chat_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.ai_chat_messages
    ADD CONSTRAINT ai_chat_messages_pkey PRIMARY KEY (id);


--
-- Name: ai_chats ai_chats_pkey; Type: CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.ai_chats
    ADD CONSTRAINT ai_chats_pkey PRIMARY KEY (id);


--
-- Name: api_keys api_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_pkey PRIMARY KEY (id);


--
-- Name: attachments attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.attachments
    ADD CONSTRAINT attachments_pkey PRIMARY KEY (id);


--
-- Name: audit audit_pkey; Type: CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.audit
    ADD CONSTRAINT audit_pkey PRIMARY KEY (id);


--
-- Name: auth_accounts auth_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.auth_accounts
    ADD CONSTRAINT auth_accounts_pkey PRIMARY KEY (id);


--
-- Name: auth_accounts auth_accounts_user_id_auth_provider_id_unique; Type: CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.auth_accounts
    ADD CONSTRAINT auth_accounts_user_id_auth_provider_id_unique UNIQUE (user_id, auth_provider_id);


--
-- Name: auth_providers auth_providers_pkey; Type: CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.auth_providers
    ADD CONSTRAINT auth_providers_pkey PRIMARY KEY (id);


--
-- Name: backlinks backlinks_pkey; Type: CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.backlinks
    ADD CONSTRAINT backlinks_pkey PRIMARY KEY (id);


--
-- Name: backlinks backlinks_source_page_id_target_page_id_unique; Type: CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.backlinks
    ADD CONSTRAINT backlinks_source_page_id_target_page_id_unique UNIQUE (source_page_id, target_page_id);


--
-- Name: base_properties base_properties_pkey; Type: CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.base_properties
    ADD CONSTRAINT base_properties_pkey PRIMARY KEY (page_id, id);


--
-- Name: base_rows base_rows_pkey; Type: CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.base_rows
    ADD CONSTRAINT base_rows_pkey PRIMARY KEY (id);


--
-- Name: base_views base_views_pkey; Type: CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.base_views
    ADD CONSTRAINT base_views_pkey PRIMARY KEY (id);


--
-- Name: billing billing_pkey; Type: CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.billing
    ADD CONSTRAINT billing_pkey PRIMARY KEY (id);


--
-- Name: billing billing_stripe_subscription_id_unique; Type: CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.billing
    ADD CONSTRAINT billing_stripe_subscription_id_unique UNIQUE (stripe_subscription_id);


--
-- Name: comments comments_pkey; Type: CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_pkey PRIMARY KEY (id);


--
-- Name: favorites favorites_pkey; Type: CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.favorites
    ADD CONSTRAINT favorites_pkey PRIMARY KEY (id);


--
-- Name: file_tasks file_tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.file_tasks
    ADD CONSTRAINT file_tasks_pkey PRIMARY KEY (id);


--
-- Name: group_users group_users_group_id_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.group_users
    ADD CONSTRAINT group_users_group_id_user_id_unique UNIQUE (group_id, user_id);


--
-- Name: group_users group_users_pkey; Type: CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.group_users
    ADD CONSTRAINT group_users_pkey PRIMARY KEY (id);


--
-- Name: groups groups_name_workspace_id_unique; Type: CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.groups
    ADD CONSTRAINT groups_name_workspace_id_unique UNIQUE (name, workspace_id);


--
-- Name: groups groups_pkey; Type: CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.groups
    ADD CONSTRAINT groups_pkey PRIMARY KEY (id);


--
-- Name: workspace_invitations invitations_email_workspace_id_unique; Type: CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.workspace_invitations
    ADD CONSTRAINT invitations_email_workspace_id_unique UNIQUE (email, workspace_id);


--
-- Name: kysely_migration_lock kysely_migration_lock_pkey; Type: CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.kysely_migration_lock
    ADD CONSTRAINT kysely_migration_lock_pkey PRIMARY KEY (id);


--
-- Name: kysely_migration kysely_migration_pkey; Type: CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.kysely_migration
    ADD CONSTRAINT kysely_migration_pkey PRIMARY KEY (name);


--
-- Name: labels labels_pkey; Type: CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.labels
    ADD CONSTRAINT labels_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: oauth_authorization_codes oauth_authorization_codes_code_hash_key; Type: CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.oauth_authorization_codes
    ADD CONSTRAINT oauth_authorization_codes_code_hash_key UNIQUE (code_hash);


--
-- Name: oauth_authorization_codes oauth_authorization_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.oauth_authorization_codes
    ADD CONSTRAINT oauth_authorization_codes_pkey PRIMARY KEY (id);


--
-- Name: oauth_clients oauth_clients_pkey; Type: CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.oauth_clients
    ADD CONSTRAINT oauth_clients_pkey PRIMARY KEY (id);


--
-- Name: oauth_grants oauth_grants_pkey; Type: CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.oauth_grants
    ADD CONSTRAINT oauth_grants_pkey PRIMARY KEY (id);


--
-- Name: oauth_grants oauth_grants_user_client_unique; Type: CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.oauth_grants
    ADD CONSTRAINT oauth_grants_user_client_unique UNIQUE (user_id, client_id);


--
-- Name: oauth_tokens oauth_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.oauth_tokens
    ADD CONSTRAINT oauth_tokens_pkey PRIMARY KEY (id);


--
-- Name: oauth_tokens oauth_tokens_refresh_token_hash_key; Type: CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.oauth_tokens
    ADD CONSTRAINT oauth_tokens_refresh_token_hash_key UNIQUE (refresh_token_hash);


--
-- Name: page_permissions page_access_group_unique; Type: CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.page_permissions
    ADD CONSTRAINT page_access_group_unique UNIQUE (page_access_id, group_id);


--
-- Name: page_access page_access_page_id_key; Type: CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.page_access
    ADD CONSTRAINT page_access_page_id_key UNIQUE (page_id);


--
-- Name: page_access page_access_pkey; Type: CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.page_access
    ADD CONSTRAINT page_access_pkey PRIMARY KEY (id);


--
-- Name: page_permissions page_access_user_unique; Type: CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.page_permissions
    ADD CONSTRAINT page_access_user_unique UNIQUE (page_access_id, user_id);


--
-- Name: page_history page_history_pkey; Type: CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.page_history
    ADD CONSTRAINT page_history_pkey PRIMARY KEY (id);


--
-- Name: page_labels page_labels_page_id_label_id_unique; Type: CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.page_labels
    ADD CONSTRAINT page_labels_page_id_label_id_unique UNIQUE (page_id, label_id);


--
-- Name: page_labels page_labels_pkey; Type: CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.page_labels
    ADD CONSTRAINT page_labels_pkey PRIMARY KEY (id);


--
-- Name: page_permissions page_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.page_permissions
    ADD CONSTRAINT page_permissions_pkey PRIMARY KEY (id);


--
-- Name: page_transclusion_references page_transclusion_references_pkey; Type: CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.page_transclusion_references
    ADD CONSTRAINT page_transclusion_references_pkey PRIMARY KEY (id);


--
-- Name: page_transclusion_references page_transclusion_references_unique; Type: CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.page_transclusion_references
    ADD CONSTRAINT page_transclusion_references_unique UNIQUE (reference_page_id, source_page_id, transclusion_id);


--
-- Name: page_transclusions page_transclusions_page_transclusion_unique; Type: CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.page_transclusions
    ADD CONSTRAINT page_transclusions_page_transclusion_unique UNIQUE (page_id, transclusion_id);


--
-- Name: page_transclusions page_transclusions_pkey; Type: CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.page_transclusions
    ADD CONSTRAINT page_transclusions_pkey PRIMARY KEY (id);


--
-- Name: page_verifications page_verifications_page_id_key; Type: CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.page_verifications
    ADD CONSTRAINT page_verifications_page_id_key UNIQUE (page_id);


--
-- Name: page_verifications page_verifications_pkey; Type: CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.page_verifications
    ADD CONSTRAINT page_verifications_pkey PRIMARY KEY (id);


--
-- Name: page_verifiers page_verifiers_pkey; Type: CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.page_verifiers
    ADD CONSTRAINT page_verifiers_pkey PRIMARY KEY (id);


--
-- Name: page_verifiers page_verifiers_verification_user_unique; Type: CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.page_verifiers
    ADD CONSTRAINT page_verifiers_verification_user_unique UNIQUE (page_verification_id, user_id);


--
-- Name: pages pages_pkey; Type: CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT pages_pkey PRIMARY KEY (id);


--
-- Name: pages pages_slug_id_unique; Type: CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT pages_slug_id_unique UNIQUE (slug_id);


--
-- Name: public_spaces public_spaces_pkey; Type: CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.public_spaces
    ADD CONSTRAINT public_spaces_pkey PRIMARY KEY (id);


--
-- Name: public_spaces public_spaces_space_id_key; Type: CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.public_spaces
    ADD CONSTRAINT public_spaces_space_id_key UNIQUE (space_id);


--
-- Name: scim_tokens scim_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.scim_tokens
    ADD CONSTRAINT scim_tokens_pkey PRIMARY KEY (id);


--
-- Name: shares shares_key_workspace_id_unique; Type: CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.shares
    ADD CONSTRAINT shares_key_workspace_id_unique UNIQUE (key, workspace_id);


--
-- Name: shares shares_pkey; Type: CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.shares
    ADD CONSTRAINT shares_pkey PRIMARY KEY (id);


--
-- Name: siem_destinations siem_destinations_pkey; Type: CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.siem_destinations
    ADD CONSTRAINT siem_destinations_pkey PRIMARY KEY (id);


--
-- Name: space_members space_members_pkey; Type: CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.space_members
    ADD CONSTRAINT space_members_pkey PRIMARY KEY (id);


--
-- Name: space_members space_members_space_id_group_id_unique; Type: CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.space_members
    ADD CONSTRAINT space_members_space_id_group_id_unique UNIQUE (space_id, group_id);


--
-- Name: space_members space_members_space_id_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.space_members
    ADD CONSTRAINT space_members_space_id_user_id_unique UNIQUE (space_id, user_id);


--
-- Name: spaces spaces_pkey; Type: CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.spaces
    ADD CONSTRAINT spaces_pkey PRIMARY KEY (id);


--
-- Name: spaces spaces_slug_workspace_id_unique; Type: CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.spaces
    ADD CONSTRAINT spaces_slug_workspace_id_unique UNIQUE (slug, workspace_id);


--
-- Name: templates templates_pkey; Type: CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.templates
    ADD CONSTRAINT templates_pkey PRIMARY KEY (id);


--
-- Name: user_mfa user_mfa_pkey; Type: CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.user_mfa
    ADD CONSTRAINT user_mfa_pkey PRIMARY KEY (id);


--
-- Name: user_mfa user_mfa_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.user_mfa
    ADD CONSTRAINT user_mfa_user_id_unique UNIQUE (user_id);


--
-- Name: user_sessions user_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_pkey PRIMARY KEY (id);


--
-- Name: user_tokens user_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.user_tokens
    ADD CONSTRAINT user_tokens_pkey PRIMARY KEY (id);


--
-- Name: users users_email_workspace_id_unique; Type: CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_workspace_id_unique UNIQUE (email, workspace_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: watchers watchers_pkey; Type: CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.watchers
    ADD CONSTRAINT watchers_pkey PRIMARY KEY (id);


--
-- Name: workspace_invitations workspace_invitations_pkey; Type: CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.workspace_invitations
    ADD CONSTRAINT workspace_invitations_pkey PRIMARY KEY (id);


--
-- Name: workspaces workspaces_custom_domain_unique; Type: CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.workspaces
    ADD CONSTRAINT workspaces_custom_domain_unique UNIQUE (custom_domain);


--
-- Name: workspaces workspaces_hostname_unique; Type: CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.workspaces
    ADD CONSTRAINT workspaces_hostname_unique UNIQUE (hostname);


--
-- Name: workspaces workspaces_pkey; Type: CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.workspaces
    ADD CONSTRAINT workspaces_pkey PRIMARY KEY (id);


--
-- Name: workspaces workspaces_stripe_customer_id_unique; Type: CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.workspaces
    ADD CONSTRAINT workspaces_stripe_customer_id_unique UNIQUE (stripe_customer_id);


--
-- Name: attachments_file_name_trgm_idx; Type: INDEX; Schema: public; Owner: docmost
--

CREATE INDEX attachments_file_name_trgm_idx ON public.attachments USING gin (lower(translate((file_name)::text, '_.-'::text, '   '::text)) public.gin_trgm_ops);


--
-- Name: attachments_tsv_idx; Type: INDEX; Schema: public; Owner: docmost
--

CREATE INDEX attachments_tsv_idx ON public.attachments USING gin (tsv);


--
-- Name: base_properties_page_name_alive_unique; Type: INDEX; Schema: public; Owner: docmost
--

CREATE UNIQUE INDEX base_properties_page_name_alive_unique ON public.base_properties USING btree (page_id, lower(TRIM(BOTH FROM name))) WHERE (deleted_at IS NULL);


--
-- Name: idx_ai_chat_messages_chat_id; Type: INDEX; Schema: public; Owner: docmost
--

CREATE INDEX idx_ai_chat_messages_chat_id ON public.ai_chat_messages USING btree (chat_id, id);


--
-- Name: idx_ai_chat_messages_tsv; Type: INDEX; Schema: public; Owner: docmost
--

CREATE INDEX idx_ai_chat_messages_tsv ON public.ai_chat_messages USING gin (tsv);


--
-- Name: idx_ai_chats_workspace_creator; Type: INDEX; Schema: public; Owner: docmost
--

CREATE INDEX idx_ai_chats_workspace_creator ON public.ai_chats USING btree (workspace_id, creator_id, id);


--
-- Name: idx_api_keys_workspace_id; Type: INDEX; Schema: public; Owner: docmost
--

CREATE INDEX idx_api_keys_workspace_id ON public.api_keys USING btree (workspace_id);


--
-- Name: idx_attachments_ai_chat_id; Type: INDEX; Schema: public; Owner: docmost
--

CREATE INDEX idx_attachments_ai_chat_id ON public.attachments USING btree (ai_chat_id);


--
-- Name: idx_attachments_page_id; Type: INDEX; Schema: public; Owner: docmost
--

CREATE INDEX idx_attachments_page_id ON public.attachments USING btree (page_id);


--
-- Name: idx_attachments_space_id; Type: INDEX; Schema: public; Owner: docmost
--

CREATE INDEX idx_attachments_space_id ON public.attachments USING btree (space_id);


--
-- Name: idx_attachments_workspace_id; Type: INDEX; Schema: public; Owner: docmost
--

CREATE INDEX idx_attachments_workspace_id ON public.attachments USING btree (workspace_id);


--
-- Name: idx_audit_workspace_id; Type: INDEX; Schema: public; Owner: docmost
--

CREATE INDEX idx_audit_workspace_id ON public.audit USING btree (workspace_id, id DESC);


--
-- Name: idx_auth_accounts_provider_user_id; Type: INDEX; Schema: public; Owner: docmost
--

CREATE INDEX idx_auth_accounts_provider_user_id ON public.auth_accounts USING btree (provider_user_id, auth_provider_id);


--
-- Name: idx_auth_providers_workspace_id; Type: INDEX; Schema: public; Owner: docmost
--

CREATE INDEX idx_auth_providers_workspace_id ON public.auth_providers USING btree (workspace_id);


--
-- Name: idx_backlinks_target_page_id; Type: INDEX; Schema: public; Owner: docmost
--

CREATE INDEX idx_backlinks_target_page_id ON public.backlinks USING btree (target_page_id);


--
-- Name: idx_base_properties_page_alive; Type: INDEX; Schema: public; Owner: docmost
--

CREATE INDEX idx_base_properties_page_alive ON public.base_properties USING btree (page_id, "position" COLLATE "C", id) WHERE (deleted_at IS NULL);


--
-- Name: idx_base_properties_page_id; Type: INDEX; Schema: public; Owner: docmost
--

CREATE INDEX idx_base_properties_page_id ON public.base_properties USING btree (page_id);


--
-- Name: idx_base_rows_page_alive; Type: INDEX; Schema: public; Owner: docmost
--

CREATE INDEX idx_base_rows_page_alive ON public.base_rows USING btree (page_id, "position" COLLATE "C", id) WHERE (deleted_at IS NULL);


--
-- Name: idx_base_rows_page_created; Type: INDEX; Schema: public; Owner: docmost
--

CREATE INDEX idx_base_rows_page_created ON public.base_rows USING btree (page_id, created_at DESC) WHERE (deleted_at IS NULL);


--
-- Name: idx_base_rows_page_updated; Type: INDEX; Schema: public; Owner: docmost
--

CREATE INDEX idx_base_rows_page_updated ON public.base_rows USING btree (page_id, updated_at DESC) WHERE (deleted_at IS NULL);


--
-- Name: idx_base_views_page_id; Type: INDEX; Schema: public; Owner: docmost
--

CREATE INDEX idx_base_views_page_id ON public.base_views USING btree (page_id);


--
-- Name: idx_comments_page_id; Type: INDEX; Schema: public; Owner: docmost
--

CREATE INDEX idx_comments_page_id ON public.comments USING btree (page_id);


--
-- Name: idx_comments_parent_comment_id; Type: INDEX; Schema: public; Owner: docmost
--

CREATE INDEX idx_comments_parent_comment_id ON public.comments USING btree (parent_comment_id);


--
-- Name: idx_favorites_user_page; Type: INDEX; Schema: public; Owner: docmost
--

CREATE UNIQUE INDEX idx_favorites_user_page ON public.favorites USING btree (user_id, page_id) WHERE (page_id IS NOT NULL);


--
-- Name: idx_favorites_user_space; Type: INDEX; Schema: public; Owner: docmost
--

CREATE UNIQUE INDEX idx_favorites_user_space ON public.favorites USING btree (user_id, space_id) WHERE (space_id IS NOT NULL);


--
-- Name: idx_favorites_user_template; Type: INDEX; Schema: public; Owner: docmost
--

CREATE UNIQUE INDEX idx_favorites_user_template ON public.favorites USING btree (user_id, template_id) WHERE (template_id IS NOT NULL);


--
-- Name: idx_favorites_user_workspace_type; Type: INDEX; Schema: public; Owner: docmost
--

CREATE INDEX idx_favorites_user_workspace_type ON public.favorites USING btree (user_id, workspace_id, type);


--
-- Name: idx_file_tasks_page_export; Type: INDEX; Schema: public; Owner: docmost
--

CREATE INDEX idx_file_tasks_page_export ON public.file_tasks USING btree (page_id, workspace_id) WHERE (((type)::text = 'export'::text) AND (deleted_at IS NULL));


--
-- Name: idx_group_users_user_id; Type: INDEX; Schema: public; Owner: docmost
--

CREATE INDEX idx_group_users_user_id ON public.group_users USING btree (user_id);


--
-- Name: idx_groups_name_lower_workspace; Type: INDEX; Schema: public; Owner: docmost
--

CREATE UNIQUE INDEX idx_groups_name_lower_workspace ON public.groups USING btree (lower((name)::text), workspace_id);


--
-- Name: idx_groups_workspace_id; Type: INDEX; Schema: public; Owner: docmost
--

CREATE INDEX idx_groups_workspace_id ON public.groups USING btree (workspace_id);


--
-- Name: idx_groups_workspace_scim_external_id; Type: INDEX; Schema: public; Owner: docmost
--

CREATE UNIQUE INDEX idx_groups_workspace_scim_external_id ON public.groups USING btree (workspace_id, scim_external_id) WHERE (scim_external_id IS NOT NULL);


--
-- Name: idx_notifications_comment_id; Type: INDEX; Schema: public; Owner: docmost
--

CREATE INDEX idx_notifications_comment_id ON public.notifications USING btree (comment_id);


--
-- Name: idx_notifications_page_id; Type: INDEX; Schema: public; Owner: docmost
--

CREATE INDEX idx_notifications_page_id ON public.notifications USING btree (page_id);


--
-- Name: idx_notifications_space_id; Type: INDEX; Schema: public; Owner: docmost
--

CREATE INDEX idx_notifications_space_id ON public.notifications USING btree (space_id);


--
-- Name: idx_notifications_user_id; Type: INDEX; Schema: public; Owner: docmost
--

CREATE INDEX idx_notifications_user_id ON public.notifications USING btree (user_id, id DESC);


--
-- Name: idx_notifications_user_unread; Type: INDEX; Schema: public; Owner: docmost
--

CREATE INDEX idx_notifications_user_unread ON public.notifications USING btree (user_id) WHERE (read_at IS NULL);


--
-- Name: idx_page_access_space; Type: INDEX; Schema: public; Owner: docmost
--

CREATE INDEX idx_page_access_space ON public.page_access USING btree (space_id);


--
-- Name: idx_page_history_page_created; Type: INDEX; Schema: public; Owner: docmost
--

CREATE INDEX idx_page_history_page_created ON public.page_history USING btree (page_id, created_at DESC);


--
-- Name: idx_page_permissions_group; Type: INDEX; Schema: public; Owner: docmost
--

CREATE INDEX idx_page_permissions_group ON public.page_permissions USING btree (group_id);


--
-- Name: idx_page_permissions_user; Type: INDEX; Schema: public; Owner: docmost
--

CREATE INDEX idx_page_permissions_user ON public.page_permissions USING btree (user_id);


--
-- Name: idx_page_transclusion_references_source; Type: INDEX; Schema: public; Owner: docmost
--

CREATE INDEX idx_page_transclusion_references_source ON public.page_transclusion_references USING btree (source_page_id, transclusion_id);


--
-- Name: idx_page_transclusion_references_workspace; Type: INDEX; Schema: public; Owner: docmost
--

CREATE INDEX idx_page_transclusion_references_workspace ON public.page_transclusion_references USING btree (workspace_id);


--
-- Name: idx_page_transclusions_workspace; Type: INDEX; Schema: public; Owner: docmost
--

CREATE INDEX idx_page_transclusions_workspace ON public.page_transclusions USING btree (workspace_id);


--
-- Name: idx_page_verifications_expires_at; Type: INDEX; Schema: public; Owner: docmost
--

CREATE INDEX idx_page_verifications_expires_at ON public.page_verifications USING btree (expires_at) WHERE (expires_at IS NOT NULL);


--
-- Name: idx_page_verifications_space_id; Type: INDEX; Schema: public; Owner: docmost
--

CREATE INDEX idx_page_verifications_space_id ON public.page_verifications USING btree (space_id);


--
-- Name: idx_page_verifications_workspace_id_id; Type: INDEX; Schema: public; Owner: docmost
--

CREATE INDEX idx_page_verifications_workspace_id_id ON public.page_verifications USING btree (workspace_id, id DESC);


--
-- Name: idx_page_verifiers_user_id; Type: INDEX; Schema: public; Owner: docmost
--

CREATE INDEX idx_page_verifiers_user_id ON public.page_verifiers USING btree (user_id);


--
-- Name: idx_pages_creator_id; Type: INDEX; Schema: public; Owner: docmost
--

CREATE INDEX idx_pages_creator_id ON public.pages USING btree (creator_id);


--
-- Name: idx_pages_is_base; Type: INDEX; Schema: public; Owner: docmost
--

CREATE INDEX idx_pages_is_base ON public.pages USING btree (space_id, "position" COLLATE "C") WHERE ((is_base = true) AND (deleted_at IS NULL));


--
-- Name: idx_pages_parent_page_id; Type: INDEX; Schema: public; Owner: docmost
--

CREATE INDEX idx_pages_parent_page_id ON public.pages USING btree (parent_page_id) WHERE (deleted_at IS NULL);


--
-- Name: idx_pages_space_deleted; Type: INDEX; Schema: public; Owner: docmost
--

CREATE INDEX idx_pages_space_deleted ON public.pages USING btree (space_id, deleted_at DESC) WHERE (deleted_at IS NOT NULL);


--
-- Name: idx_pages_space_parent_position; Type: INDEX; Schema: public; Owner: docmost
--

CREATE INDEX idx_pages_space_parent_position ON public.pages USING btree (space_id, parent_page_id, "position" COLLATE "C") WHERE (deleted_at IS NULL);


--
-- Name: idx_pages_space_updated; Type: INDEX; Schema: public; Owner: docmost
--

CREATE INDEX idx_pages_space_updated ON public.pages USING btree (space_id, updated_at DESC) WHERE (deleted_at IS NULL);


--
-- Name: idx_pages_workspace_id; Type: INDEX; Schema: public; Owner: docmost
--

CREATE INDEX idx_pages_workspace_id ON public.pages USING btree (workspace_id);


--
-- Name: idx_scim_tokens_token_hash; Type: INDEX; Schema: public; Owner: docmost
--

CREATE INDEX idx_scim_tokens_token_hash ON public.scim_tokens USING btree (token_hash);


--
-- Name: idx_scim_tokens_workspace_id; Type: INDEX; Schema: public; Owner: docmost
--

CREATE INDEX idx_scim_tokens_workspace_id ON public.scim_tokens USING btree (workspace_id);


--
-- Name: idx_shares_page_id; Type: INDEX; Schema: public; Owner: docmost
--

CREATE INDEX idx_shares_page_id ON public.shares USING btree (page_id);


--
-- Name: idx_siem_destinations_due; Type: INDEX; Schema: public; Owner: docmost
--

CREATE INDEX idx_siem_destinations_due ON public.siem_destinations USING btree (next_attempt_at) WHERE (enabled = true);


--
-- Name: idx_siem_destinations_workspace_id; Type: INDEX; Schema: public; Owner: docmost
--

CREATE INDEX idx_siem_destinations_workspace_id ON public.siem_destinations USING btree (workspace_id);


--
-- Name: idx_space_members_group_id; Type: INDEX; Schema: public; Owner: docmost
--

CREATE INDEX idx_space_members_group_id ON public.space_members USING btree (group_id);


--
-- Name: idx_space_members_user_id; Type: INDEX; Schema: public; Owner: docmost
--

CREATE INDEX idx_space_members_user_id ON public.space_members USING btree (user_id);


--
-- Name: idx_spaces_slug_lower_workspace; Type: INDEX; Schema: public; Owner: docmost
--

CREATE UNIQUE INDEX idx_spaces_slug_lower_workspace ON public.spaces USING btree (lower((slug)::text), workspace_id);


--
-- Name: idx_spaces_workspace_id; Type: INDEX; Schema: public; Owner: docmost
--

CREATE INDEX idx_spaces_workspace_id ON public.spaces USING btree (workspace_id);


--
-- Name: idx_templates_space_id; Type: INDEX; Schema: public; Owner: docmost
--

CREATE INDEX idx_templates_space_id ON public.templates USING btree (space_id);


--
-- Name: idx_templates_workspace_id; Type: INDEX; Schema: public; Owner: docmost
--

CREATE INDEX idx_templates_workspace_id ON public.templates USING btree (workspace_id);


--
-- Name: idx_user_sessions_active; Type: INDEX; Schema: public; Owner: docmost
--

CREATE INDEX idx_user_sessions_active ON public.user_sessions USING btree (user_id, workspace_id, last_active_at DESC) WHERE (revoked_at IS NULL);


--
-- Name: idx_user_sessions_revoked; Type: INDEX; Schema: public; Owner: docmost
--

CREATE INDEX idx_user_sessions_revoked ON public.user_sessions USING btree (expires_at) WHERE (revoked_at IS NOT NULL);


--
-- Name: idx_user_sessions_user_workspace; Type: INDEX; Schema: public; Owner: docmost
--

CREATE INDEX idx_user_sessions_user_workspace ON public.user_sessions USING btree (user_id, workspace_id);


--
-- Name: idx_users_workspace_deleted; Type: INDEX; Schema: public; Owner: docmost
--

CREATE INDEX idx_users_workspace_deleted ON public.users USING btree (workspace_id, deleted_at);


--
-- Name: idx_users_workspace_scim_external_id; Type: INDEX; Schema: public; Owner: docmost
--

CREATE UNIQUE INDEX idx_users_workspace_scim_external_id ON public.users USING btree (workspace_id, scim_external_id) WHERE (scim_external_id IS NOT NULL);


--
-- Name: idx_watchers_page_id; Type: INDEX; Schema: public; Owner: docmost
--

CREATE INDEX idx_watchers_page_id ON public.watchers USING btree (page_id);


--
-- Name: idx_watchers_space_id; Type: INDEX; Schema: public; Owner: docmost
--

CREATE INDEX idx_watchers_space_id ON public.watchers USING btree (space_id);


--
-- Name: idx_watchers_user_page; Type: INDEX; Schema: public; Owner: docmost
--

CREATE UNIQUE INDEX idx_watchers_user_page ON public.watchers USING btree (user_id, page_id) WHERE (page_id IS NOT NULL);


--
-- Name: idx_watchers_user_space; Type: INDEX; Schema: public; Owner: docmost
--

CREATE UNIQUE INDEX idx_watchers_user_space ON public.watchers USING btree (user_id, space_id) WHERE (page_id IS NULL);


--
-- Name: idx_watchers_user_workspace; Type: INDEX; Schema: public; Owner: docmost
--

CREATE INDEX idx_watchers_user_workspace ON public.watchers USING btree (user_id, workspace_id);


--
-- Name: idx_workspace_invitations_workspace_id; Type: INDEX; Schema: public; Owner: docmost
--

CREATE INDEX idx_workspace_invitations_workspace_id ON public.workspace_invitations USING btree (workspace_id);


--
-- Name: idx_workspaces_created_at; Type: INDEX; Schema: public; Owner: docmost
--

CREATE INDEX idx_workspaces_created_at ON public.workspaces USING btree (created_at);


--
-- Name: idx_workspaces_hostname_lower; Type: INDEX; Schema: public; Owner: docmost
--

CREATE UNIQUE INDEX idx_workspaces_hostname_lower ON public.workspaces USING btree (lower((hostname)::text));


--
-- Name: labels_workspace_id_type_name_unique; Type: INDEX; Schema: public; Owner: docmost
--

CREATE UNIQUE INDEX labels_workspace_id_type_name_unique ON public.labels USING btree (workspace_id, type, name);


--
-- Name: oauth_authorization_codes_client_id_idx; Type: INDEX; Schema: public; Owner: docmost
--

CREATE INDEX oauth_authorization_codes_client_id_idx ON public.oauth_authorization_codes USING btree (client_id);


--
-- Name: oauth_authorization_codes_consumed_at_idx; Type: INDEX; Schema: public; Owner: docmost
--

CREATE INDEX oauth_authorization_codes_consumed_at_idx ON public.oauth_authorization_codes USING btree (consumed_at);


--
-- Name: oauth_authorization_codes_expires_at_idx; Type: INDEX; Schema: public; Owner: docmost
--

CREATE INDEX oauth_authorization_codes_expires_at_idx ON public.oauth_authorization_codes USING btree (expires_at);


--
-- Name: oauth_authorization_codes_user_id_idx; Type: INDEX; Schema: public; Owner: docmost
--

CREATE INDEX oauth_authorization_codes_user_id_idx ON public.oauth_authorization_codes USING btree (user_id);


--
-- Name: oauth_authorization_codes_workspace_id_idx; Type: INDEX; Schema: public; Owner: docmost
--

CREATE INDEX oauth_authorization_codes_workspace_id_idx ON public.oauth_authorization_codes USING btree (workspace_id);


--
-- Name: oauth_clients_workspace_id_idx; Type: INDEX; Schema: public; Owner: docmost
--

CREATE INDEX oauth_clients_workspace_id_idx ON public.oauth_clients USING btree (workspace_id);


--
-- Name: oauth_grants_client_id_idx; Type: INDEX; Schema: public; Owner: docmost
--

CREATE INDEX oauth_grants_client_id_idx ON public.oauth_grants USING btree (client_id);


--
-- Name: oauth_tokens_access_expires_at_idx; Type: INDEX; Schema: public; Owner: docmost
--

CREATE INDEX oauth_tokens_access_expires_at_idx ON public.oauth_tokens USING btree (access_expires_at);


--
-- Name: oauth_tokens_access_token_jti_idx; Type: INDEX; Schema: public; Owner: docmost
--

CREATE INDEX oauth_tokens_access_token_jti_idx ON public.oauth_tokens USING btree (workspace_id, access_token_jti);


--
-- Name: oauth_tokens_grant_id_idx; Type: INDEX; Schema: public; Owner: docmost
--

CREATE INDEX oauth_tokens_grant_id_idx ON public.oauth_tokens USING btree (grant_id);


--
-- Name: oauth_tokens_refresh_expires_at_idx; Type: INDEX; Schema: public; Owner: docmost
--

CREATE INDEX oauth_tokens_refresh_expires_at_idx ON public.oauth_tokens USING btree (refresh_expires_at);


--
-- Name: oauth_tokens_revoked_at_idx; Type: INDEX; Schema: public; Owner: docmost
--

CREATE INDEX oauth_tokens_revoked_at_idx ON public.oauth_tokens USING btree (revoked_at);


--
-- Name: page_labels_label_id_idx; Type: INDEX; Schema: public; Owner: docmost
--

CREATE INDEX page_labels_label_id_idx ON public.page_labels USING btree (label_id);


--
-- Name: pages_title_trgm_idx; Type: INDEX; Schema: public; Owner: docmost
--

CREATE INDEX pages_title_trgm_idx ON public.pages USING gin (lower((title)::text) public.gin_trgm_ops);


--
-- Name: pages_tsv_idx; Type: INDEX; Schema: public; Owner: docmost
--

CREATE INDEX pages_tsv_idx ON public.pages USING gin (tsv);


--
-- Name: public_spaces_workspace_id_idx; Type: INDEX; Schema: public; Owner: docmost
--

CREATE INDEX public_spaces_workspace_id_idx ON public.public_spaces USING btree (workspace_id);


--
-- Name: spaces_personal_creator_unique; Type: INDEX; Schema: public; Owner: docmost
--

CREATE UNIQUE INDEX spaces_personal_creator_unique ON public.spaces USING btree (creator_id) WHERE ((is_personal = true) AND (deleted_at IS NULL));


--
-- Name: templates_tsv_idx; Type: INDEX; Schema: public; Owner: docmost
--

CREATE INDEX templates_tsv_idx ON public.templates USING gin (tsv);


--
-- Name: ai_chat_messages ai_chat_messages_tsvector_update; Type: TRIGGER; Schema: public; Owner: docmost
--

CREATE TRIGGER ai_chat_messages_tsvector_update BEFORE INSERT OR UPDATE ON public.ai_chat_messages FOR EACH ROW EXECUTE FUNCTION public.ai_chat_messages_tsvector_trigger();


--
-- Name: pages pages_tsvector_update; Type: TRIGGER; Schema: public; Owner: docmost
--

CREATE TRIGGER pages_tsvector_update BEFORE INSERT OR UPDATE ON public.pages FOR EACH ROW EXECUTE FUNCTION public.pages_tsvector_trigger();


--
-- Name: templates templates_tsvector_update; Type: TRIGGER; Schema: public; Owner: docmost
--

CREATE TRIGGER templates_tsvector_update BEFORE INSERT OR UPDATE ON public.templates FOR EACH ROW EXECUTE FUNCTION public.templates_tsvector_trigger();


--
-- Name: ai_chat_messages ai_chat_messages_chat_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.ai_chat_messages
    ADD CONSTRAINT ai_chat_messages_chat_id_fkey FOREIGN KEY (chat_id) REFERENCES public.ai_chats(id) ON DELETE CASCADE;


--
-- Name: ai_chat_messages ai_chat_messages_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.ai_chat_messages
    ADD CONSTRAINT ai_chat_messages_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: ai_chat_messages ai_chat_messages_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.ai_chat_messages
    ADD CONSTRAINT ai_chat_messages_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: ai_chats ai_chats_creator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.ai_chats
    ADD CONSTRAINT ai_chats_creator_id_fkey FOREIGN KEY (creator_id) REFERENCES public.users(id);


--
-- Name: ai_chats ai_chats_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.ai_chats
    ADD CONSTRAINT ai_chats_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: api_keys api_keys_creator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_creator_id_fkey FOREIGN KEY (creator_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: api_keys api_keys_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: attachments attachments_creator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.attachments
    ADD CONSTRAINT attachments_creator_id_fkey FOREIGN KEY (creator_id) REFERENCES public.users(id);


--
-- Name: attachments attachments_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.attachments
    ADD CONSTRAINT attachments_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: audit audit_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.audit
    ADD CONSTRAINT audit_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: auth_accounts auth_accounts_auth_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.auth_accounts
    ADD CONSTRAINT auth_accounts_auth_provider_id_fkey FOREIGN KEY (auth_provider_id) REFERENCES public.auth_providers(id) ON DELETE CASCADE;


--
-- Name: auth_accounts auth_accounts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.auth_accounts
    ADD CONSTRAINT auth_accounts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: auth_accounts auth_accounts_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.auth_accounts
    ADD CONSTRAINT auth_accounts_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: auth_providers auth_providers_creator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.auth_providers
    ADD CONSTRAINT auth_providers_creator_id_fkey FOREIGN KEY (creator_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: auth_providers auth_providers_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.auth_providers
    ADD CONSTRAINT auth_providers_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: backlinks backlinks_source_page_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.backlinks
    ADD CONSTRAINT backlinks_source_page_id_fkey FOREIGN KEY (source_page_id) REFERENCES public.pages(id) ON DELETE CASCADE;


--
-- Name: backlinks backlinks_target_page_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.backlinks
    ADD CONSTRAINT backlinks_target_page_id_fkey FOREIGN KEY (target_page_id) REFERENCES public.pages(id) ON DELETE CASCADE;


--
-- Name: backlinks backlinks_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.backlinks
    ADD CONSTRAINT backlinks_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: base_properties base_properties_page_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.base_properties
    ADD CONSTRAINT base_properties_page_id_fkey FOREIGN KEY (page_id) REFERENCES public.pages(id) ON DELETE CASCADE;


--
-- Name: base_properties base_properties_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.base_properties
    ADD CONSTRAINT base_properties_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: base_rows base_rows_creator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.base_rows
    ADD CONSTRAINT base_rows_creator_id_fkey FOREIGN KEY (creator_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: base_rows base_rows_last_updated_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.base_rows
    ADD CONSTRAINT base_rows_last_updated_by_id_fkey FOREIGN KEY (last_updated_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: base_rows base_rows_page_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.base_rows
    ADD CONSTRAINT base_rows_page_id_fkey FOREIGN KEY (page_id) REFERENCES public.pages(id) ON DELETE CASCADE;


--
-- Name: base_rows base_rows_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.base_rows
    ADD CONSTRAINT base_rows_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: base_views base_views_creator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.base_views
    ADD CONSTRAINT base_views_creator_id_fkey FOREIGN KEY (creator_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: base_views base_views_page_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.base_views
    ADD CONSTRAINT base_views_page_id_fkey FOREIGN KEY (page_id) REFERENCES public.pages(id) ON DELETE CASCADE;


--
-- Name: base_views base_views_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.base_views
    ADD CONSTRAINT base_views_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: billing billing_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.billing
    ADD CONSTRAINT billing_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: comments comments_creator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_creator_id_fkey FOREIGN KEY (creator_id) REFERENCES public.users(id);


--
-- Name: comments comments_last_edited_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_last_edited_by_id_fkey FOREIGN KEY (last_edited_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: comments comments_page_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_page_id_fkey FOREIGN KEY (page_id) REFERENCES public.pages(id) ON DELETE CASCADE;


--
-- Name: comments comments_parent_comment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_parent_comment_id_fkey FOREIGN KEY (parent_comment_id) REFERENCES public.comments(id) ON DELETE CASCADE;


--
-- Name: comments comments_resolved_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_resolved_by_id_fkey FOREIGN KEY (resolved_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: comments comments_space_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_space_id_fkey FOREIGN KEY (space_id) REFERENCES public.spaces(id) ON DELETE CASCADE;


--
-- Name: comments comments_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id);


--
-- Name: favorites favorites_page_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.favorites
    ADD CONSTRAINT favorites_page_id_fkey FOREIGN KEY (page_id) REFERENCES public.pages(id) ON DELETE CASCADE;


--
-- Name: favorites favorites_space_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.favorites
    ADD CONSTRAINT favorites_space_id_fkey FOREIGN KEY (space_id) REFERENCES public.spaces(id) ON DELETE CASCADE;


--
-- Name: favorites favorites_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.favorites
    ADD CONSTRAINT favorites_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.templates(id) ON DELETE CASCADE;


--
-- Name: favorites favorites_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.favorites
    ADD CONSTRAINT favorites_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: favorites favorites_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.favorites
    ADD CONSTRAINT favorites_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: file_tasks file_tasks_creator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.file_tasks
    ADD CONSTRAINT file_tasks_creator_id_fkey FOREIGN KEY (creator_id) REFERENCES public.users(id);


--
-- Name: file_tasks file_tasks_page_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.file_tasks
    ADD CONSTRAINT file_tasks_page_id_fkey FOREIGN KEY (page_id) REFERENCES public.pages(id) ON DELETE SET NULL;


--
-- Name: file_tasks file_tasks_space_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.file_tasks
    ADD CONSTRAINT file_tasks_space_id_fkey FOREIGN KEY (space_id) REFERENCES public.spaces(id) ON DELETE CASCADE;


--
-- Name: file_tasks file_tasks_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.file_tasks
    ADD CONSTRAINT file_tasks_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: group_users group_users_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.group_users
    ADD CONSTRAINT group_users_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.groups(id) ON DELETE CASCADE;


--
-- Name: group_users group_users_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.group_users
    ADD CONSTRAINT group_users_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: groups groups_creator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.groups
    ADD CONSTRAINT groups_creator_id_fkey FOREIGN KEY (creator_id) REFERENCES public.users(id);


--
-- Name: groups groups_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.groups
    ADD CONSTRAINT groups_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: labels labels_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.labels
    ADD CONSTRAINT labels_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: notifications notifications_actor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_actor_id_fkey FOREIGN KEY (actor_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: notifications notifications_comment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_comment_id_fkey FOREIGN KEY (comment_id) REFERENCES public.comments(id) ON DELETE CASCADE;


--
-- Name: notifications notifications_page_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_page_id_fkey FOREIGN KEY (page_id) REFERENCES public.pages(id) ON DELETE CASCADE;


--
-- Name: notifications notifications_page_verification_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_page_verification_id_fkey FOREIGN KEY (page_verification_id) REFERENCES public.page_verifications(id) ON DELETE CASCADE;


--
-- Name: notifications notifications_space_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_space_id_fkey FOREIGN KEY (space_id) REFERENCES public.spaces(id) ON DELETE CASCADE;


--
-- Name: notifications notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: notifications notifications_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: oauth_authorization_codes oauth_authorization_codes_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.oauth_authorization_codes
    ADD CONSTRAINT oauth_authorization_codes_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.oauth_clients(id) ON DELETE CASCADE;


--
-- Name: oauth_authorization_codes oauth_authorization_codes_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.oauth_authorization_codes
    ADD CONSTRAINT oauth_authorization_codes_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: oauth_authorization_codes oauth_authorization_codes_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.oauth_authorization_codes
    ADD CONSTRAINT oauth_authorization_codes_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: oauth_clients oauth_clients_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.oauth_clients
    ADD CONSTRAINT oauth_clients_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: oauth_grants oauth_grants_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.oauth_grants
    ADD CONSTRAINT oauth_grants_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.oauth_clients(id) ON DELETE CASCADE;


--
-- Name: oauth_grants oauth_grants_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.oauth_grants
    ADD CONSTRAINT oauth_grants_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: oauth_grants oauth_grants_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.oauth_grants
    ADD CONSTRAINT oauth_grants_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: oauth_tokens oauth_tokens_grant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.oauth_tokens
    ADD CONSTRAINT oauth_tokens_grant_id_fkey FOREIGN KEY (grant_id) REFERENCES public.oauth_grants(id) ON DELETE CASCADE;


--
-- Name: oauth_tokens oauth_tokens_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.oauth_tokens
    ADD CONSTRAINT oauth_tokens_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: page_access page_access_creator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.page_access
    ADD CONSTRAINT page_access_creator_id_fkey FOREIGN KEY (creator_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: page_access page_access_page_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.page_access
    ADD CONSTRAINT page_access_page_id_fkey FOREIGN KEY (page_id) REFERENCES public.pages(id) ON DELETE CASCADE;


--
-- Name: page_access page_access_space_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.page_access
    ADD CONSTRAINT page_access_space_id_fkey FOREIGN KEY (space_id) REFERENCES public.spaces(id) ON DELETE CASCADE;


--
-- Name: page_access page_access_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.page_access
    ADD CONSTRAINT page_access_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: page_history page_history_last_updated_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.page_history
    ADD CONSTRAINT page_history_last_updated_by_id_fkey FOREIGN KEY (last_updated_by_id) REFERENCES public.users(id);


--
-- Name: page_history page_history_page_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.page_history
    ADD CONSTRAINT page_history_page_id_fkey FOREIGN KEY (page_id) REFERENCES public.pages(id) ON DELETE CASCADE;


--
-- Name: page_history page_history_space_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.page_history
    ADD CONSTRAINT page_history_space_id_fkey FOREIGN KEY (space_id) REFERENCES public.spaces(id) ON DELETE CASCADE;


--
-- Name: page_history page_history_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.page_history
    ADD CONSTRAINT page_history_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: page_labels page_labels_label_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.page_labels
    ADD CONSTRAINT page_labels_label_id_fkey FOREIGN KEY (label_id) REFERENCES public.labels(id) ON DELETE CASCADE;


--
-- Name: page_labels page_labels_page_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.page_labels
    ADD CONSTRAINT page_labels_page_id_fkey FOREIGN KEY (page_id) REFERENCES public.pages(id) ON DELETE CASCADE;


--
-- Name: page_permissions page_permissions_added_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.page_permissions
    ADD CONSTRAINT page_permissions_added_by_id_fkey FOREIGN KEY (added_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: page_permissions page_permissions_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.page_permissions
    ADD CONSTRAINT page_permissions_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.groups(id) ON DELETE CASCADE;


--
-- Name: page_permissions page_permissions_page_access_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.page_permissions
    ADD CONSTRAINT page_permissions_page_access_id_fkey FOREIGN KEY (page_access_id) REFERENCES public.page_access(id) ON DELETE CASCADE;


--
-- Name: page_permissions page_permissions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.page_permissions
    ADD CONSTRAINT page_permissions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: page_transclusion_references page_transclusion_references_reference_page_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.page_transclusion_references
    ADD CONSTRAINT page_transclusion_references_reference_page_id_fkey FOREIGN KEY (reference_page_id) REFERENCES public.pages(id) ON DELETE CASCADE;


--
-- Name: page_transclusion_references page_transclusion_references_source_page_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.page_transclusion_references
    ADD CONSTRAINT page_transclusion_references_source_page_id_fkey FOREIGN KEY (source_page_id) REFERENCES public.pages(id) ON DELETE CASCADE;


--
-- Name: page_transclusion_references page_transclusion_references_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.page_transclusion_references
    ADD CONSTRAINT page_transclusion_references_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: page_transclusions page_transclusions_page_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.page_transclusions
    ADD CONSTRAINT page_transclusions_page_id_fkey FOREIGN KEY (page_id) REFERENCES public.pages(id) ON DELETE CASCADE;


--
-- Name: page_transclusions page_transclusions_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.page_transclusions
    ADD CONSTRAINT page_transclusions_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: page_verifications page_verifications_creator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.page_verifications
    ADD CONSTRAINT page_verifications_creator_id_fkey FOREIGN KEY (creator_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: page_verifications page_verifications_page_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.page_verifications
    ADD CONSTRAINT page_verifications_page_id_fkey FOREIGN KEY (page_id) REFERENCES public.pages(id) ON DELETE CASCADE;


--
-- Name: page_verifications page_verifications_rejected_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.page_verifications
    ADD CONSTRAINT page_verifications_rejected_by_id_fkey FOREIGN KEY (rejected_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: page_verifications page_verifications_requested_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.page_verifications
    ADD CONSTRAINT page_verifications_requested_by_id_fkey FOREIGN KEY (requested_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: page_verifications page_verifications_space_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.page_verifications
    ADD CONSTRAINT page_verifications_space_id_fkey FOREIGN KEY (space_id) REFERENCES public.spaces(id) ON DELETE CASCADE;


--
-- Name: page_verifications page_verifications_verified_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.page_verifications
    ADD CONSTRAINT page_verifications_verified_by_id_fkey FOREIGN KEY (verified_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: page_verifications page_verifications_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.page_verifications
    ADD CONSTRAINT page_verifications_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: page_verifiers page_verifiers_added_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.page_verifiers
    ADD CONSTRAINT page_verifiers_added_by_id_fkey FOREIGN KEY (added_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: page_verifiers page_verifiers_page_verification_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.page_verifiers
    ADD CONSTRAINT page_verifiers_page_verification_id_fkey FOREIGN KEY (page_verification_id) REFERENCES public.page_verifications(id) ON DELETE CASCADE;


--
-- Name: page_verifiers page_verifiers_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.page_verifiers
    ADD CONSTRAINT page_verifiers_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: pages pages_creator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT pages_creator_id_fkey FOREIGN KEY (creator_id) REFERENCES public.users(id);


--
-- Name: pages pages_deleted_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT pages_deleted_by_id_fkey FOREIGN KEY (deleted_by_id) REFERENCES public.users(id);


--
-- Name: pages pages_last_updated_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT pages_last_updated_by_id_fkey FOREIGN KEY (last_updated_by_id) REFERENCES public.users(id);


--
-- Name: pages pages_parent_page_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT pages_parent_page_id_fkey FOREIGN KEY (parent_page_id) REFERENCES public.pages(id) ON DELETE CASCADE;


--
-- Name: pages pages_space_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT pages_space_id_fkey FOREIGN KEY (space_id) REFERENCES public.spaces(id) ON DELETE CASCADE;


--
-- Name: pages pages_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT pages_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: public_spaces public_spaces_creator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.public_spaces
    ADD CONSTRAINT public_spaces_creator_id_fkey FOREIGN KEY (creator_id) REFERENCES public.users(id);


--
-- Name: public_spaces public_spaces_space_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.public_spaces
    ADD CONSTRAINT public_spaces_space_id_fkey FOREIGN KEY (space_id) REFERENCES public.spaces(id) ON DELETE CASCADE;


--
-- Name: public_spaces public_spaces_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.public_spaces
    ADD CONSTRAINT public_spaces_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: scim_tokens scim_tokens_creator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.scim_tokens
    ADD CONSTRAINT scim_tokens_creator_id_fkey FOREIGN KEY (creator_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: scim_tokens scim_tokens_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.scim_tokens
    ADD CONSTRAINT scim_tokens_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: shares shares_creator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.shares
    ADD CONSTRAINT shares_creator_id_fkey FOREIGN KEY (creator_id) REFERENCES public.users(id);


--
-- Name: shares shares_page_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.shares
    ADD CONSTRAINT shares_page_id_fkey FOREIGN KEY (page_id) REFERENCES public.pages(id) ON DELETE CASCADE;


--
-- Name: shares shares_space_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.shares
    ADD CONSTRAINT shares_space_id_fkey FOREIGN KEY (space_id) REFERENCES public.spaces(id) ON DELETE CASCADE;


--
-- Name: shares shares_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.shares
    ADD CONSTRAINT shares_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: siem_destinations siem_destinations_creator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.siem_destinations
    ADD CONSTRAINT siem_destinations_creator_id_fkey FOREIGN KEY (creator_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: siem_destinations siem_destinations_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.siem_destinations
    ADD CONSTRAINT siem_destinations_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: space_members space_members_added_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.space_members
    ADD CONSTRAINT space_members_added_by_id_fkey FOREIGN KEY (added_by_id) REFERENCES public.users(id);


--
-- Name: space_members space_members_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.space_members
    ADD CONSTRAINT space_members_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.groups(id) ON DELETE CASCADE;


--
-- Name: space_members space_members_space_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.space_members
    ADD CONSTRAINT space_members_space_id_fkey FOREIGN KEY (space_id) REFERENCES public.spaces(id) ON DELETE CASCADE;


--
-- Name: space_members space_members_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.space_members
    ADD CONSTRAINT space_members_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: spaces spaces_creator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.spaces
    ADD CONSTRAINT spaces_creator_id_fkey FOREIGN KEY (creator_id) REFERENCES public.users(id);


--
-- Name: spaces spaces_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.spaces
    ADD CONSTRAINT spaces_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: templates templates_creator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.templates
    ADD CONSTRAINT templates_creator_id_fkey FOREIGN KEY (creator_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: templates templates_last_updated_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.templates
    ADD CONSTRAINT templates_last_updated_by_id_fkey FOREIGN KEY (last_updated_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: templates templates_space_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.templates
    ADD CONSTRAINT templates_space_id_fkey FOREIGN KEY (space_id) REFERENCES public.spaces(id) ON DELETE CASCADE;


--
-- Name: templates templates_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.templates
    ADD CONSTRAINT templates_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: user_mfa user_mfa_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.user_mfa
    ADD CONSTRAINT user_mfa_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_mfa user_mfa_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.user_mfa
    ADD CONSTRAINT user_mfa_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: user_sessions user_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_sessions user_sessions_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: user_tokens user_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.user_tokens
    ADD CONSTRAINT user_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_tokens user_tokens_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.user_tokens
    ADD CONSTRAINT user_tokens_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: users users_invited_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_invited_by_id_fkey FOREIGN KEY (invited_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: users users_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: watchers watchers_added_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.watchers
    ADD CONSTRAINT watchers_added_by_id_fkey FOREIGN KEY (added_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: watchers watchers_page_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.watchers
    ADD CONSTRAINT watchers_page_id_fkey FOREIGN KEY (page_id) REFERENCES public.pages(id) ON DELETE CASCADE;


--
-- Name: watchers watchers_space_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.watchers
    ADD CONSTRAINT watchers_space_id_fkey FOREIGN KEY (space_id) REFERENCES public.spaces(id) ON DELETE CASCADE;


--
-- Name: watchers watchers_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.watchers
    ADD CONSTRAINT watchers_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: watchers watchers_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.watchers
    ADD CONSTRAINT watchers_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: workspace_invitations workspace_invitations_invited_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.workspace_invitations
    ADD CONSTRAINT workspace_invitations_invited_by_id_fkey FOREIGN KEY (invited_by_id) REFERENCES public.users(id);


--
-- Name: workspace_invitations workspace_invitations_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.workspace_invitations
    ADD CONSTRAINT workspace_invitations_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: workspaces workspaces_default_space_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docmost
--

ALTER TABLE ONLY public.workspaces
    ADD CONSTRAINT workspaces_default_space_id_fkey FOREIGN KEY (default_space_id) REFERENCES public.spaces(id) ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict Ld9QI0th2hPofxCPfHEgbkATqwLT00wD4jJOsWsYKsk5Hbd8RZgkV2osb8yqjd4

